package calldial.be.loctracker.Compass.app.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;

import calldial.be.loctracker.Compass.util.AndroidUtilsCompass;
import calldial.be.loctracker.R;

/* loaded from: classes.dex */
public class CompassBackgroundViewCompass extends View {
    public static final float INNER_RADIUS = 0.24f;
    public static final float MIDDLE_RADIUS = 0.33f;
    public static final float OUTER_RADIUS = 0.43f;
    private Point CENTER;
    private float WIDTH;
    private Paint innerCirclePaint;
    private Paint middleCirclePaint;
    private Paint northMarkStaticPaint;
    private Paint outerCirclePaint;
    private Path staticNorthMarkPath = null;
    private boolean isSimple = false;

    public CompassBackgroundViewCompass(Context context) {
        super(context);
        init(context, null);
    }

    public CompassBackgroundViewCompass(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(context, attributeSet);
    }

    public CompassBackgroundViewCompass(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init(context, attributeSet);
    }

    private void init(Context context, AttributeSet attributeSet) {
        Resources resources = context.getResources();
        int color = resources.getColor(R.color.md_indigo_300);
        int color2 = resources.getColor(R.color.md_indigo_400x);
        int color3 = resources.getColor(R.color.md_indigo_500x);
        int color4 = resources.getColor(R.color.md_red_400);
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R.styleable.CompassBackgroundView);
            if (obtainStyledAttributes != null) {
                color = obtainStyledAttributes.getColor(3, resources.getColor(R.color.md_indigo_300));
                color2 = obtainStyledAttributes.getColor(1, resources.getColor(R.color.md_indigo_400x));
                color3 = obtainStyledAttributes.getColor(0, resources.getColor(R.color.md_indigo_500x));
                color4 = obtainStyledAttributes.getColor(2, resources.getColor(R.color.md_red_400));
                obtainStyledAttributes.recycle();
            }
        } else {
            TypedValue typedValue = new TypedValue();
            Resources.Theme theme = context.getTheme();
            theme.resolveAttribute(R.attr.outerCircleColor, typedValue, true);
            color = typedValue.data;
            theme.resolveAttribute(R.attr.middleCircleColor, typedValue, true);
            color2 = typedValue.data;
            theme.resolveAttribute(R.attr.innerCircleColor, typedValue, true);
            color3 = typedValue.data;
            theme.resolveAttribute(R.attr.northMarkColor, typedValue, true);
            color4 = typedValue.data;
        }
        this.CENTER = new Point(0, 0);
        Paint paint = new Paint(1);
        this.outerCirclePaint = paint;
        paint.setColor(color);
        this.outerCirclePaint.setStyle(Paint.Style.STROKE);
        this.outerCirclePaint.setStrokeWidth(AndroidUtilsCompass.dpToPx(1));
        Paint paint2 = new Paint(1);
        this.middleCirclePaint = paint2;
        paint2.setColor(color2);
        this.middleCirclePaint.setStyle(Paint.Style.STROKE);
        this.middleCirclePaint.setStrokeWidth(AndroidUtilsCompass.dpToPx(41));
        Paint paint3 = new Paint(1);
        this.innerCirclePaint = paint3;
        paint3.setColor(color3);
        this.innerCirclePaint.setStyle(Paint.Style.STROKE);
        this.innerCirclePaint.setStrokeWidth(AndroidUtilsCompass.dpToPx(34));
        Paint paint4 = new Paint(1);
        this.northMarkStaticPaint = paint4;
        paint4.setStyle(Paint.Style.FILL);
        this.northMarkStaticPaint.setColor(color4);
    }

    @Override // android.view.View
    protected void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        int size = MeasureSpec.getSize(i);
        int size2 = MeasureSpec.getSize(i2);
        if (size > size2) {
            size = size2;
        }
        setMeasuredDimension(resolveSize(size, i), resolveSize(size, i2));
    }

    @Override // android.view.View
    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        initConstants();
        layoutStaticNorthMark();
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!this.isSimple) {
            canvas.drawCircle(this.CENTER.x, this.CENTER.y, this.WIDTH * 0.43f, this.outerCirclePaint);
            canvas.drawCircle(this.CENTER.x, this.CENTER.y, this.WIDTH * 0.33f, this.middleCirclePaint);
            canvas.drawCircle(this.CENTER.x, this.CENTER.y, this.WIDTH * 0.24f, this.innerCirclePaint);
        }
        canvas.drawPath(this.staticNorthMarkPath, this.northMarkStaticPaint);
    }

    private void initConstants() {
        float width = getWidth();
        this.WIDTH = width;
        this.CENTER.set(((int) width) / 2, getHeight() / 2);
    }

    private void layoutStaticNorthMark() {
        if (this.staticNorthMarkPath == null) {
            float f = this.CENTER.x;
            float dpToPx = AndroidUtilsCompass.dpToPx(12);
            float dpToPx2 = ((this.CENTER.y - (this.WIDTH * 0.43f)) + dpToPx) - AndroidUtilsCompass.dpToPx(2);
            Path path = new Path();
            this.staticNorthMarkPath = path;
            float f2 = dpToPx / 2.0f;
            float f3 = f - f2;
            float f4 = dpToPx2 - dpToPx;
            path.moveTo(f3, f4);
            this.staticNorthMarkPath.lineTo(f2 + f, f4);
            this.staticNorthMarkPath.lineTo(f, dpToPx2);
            this.staticNorthMarkPath.lineTo(f3, f4);
        }
    }

    public void setSimpleMode(boolean z) {
        this.isSimple = z;
        invalidate();
    }
}
