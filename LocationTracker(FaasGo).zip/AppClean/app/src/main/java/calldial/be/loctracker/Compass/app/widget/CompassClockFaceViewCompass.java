package calldial.be.loctracker.Compass.app.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;

import calldial.be.loctracker.Compass.util.AndroidUtilsCompass;
import calldial.be.loctracker.R;

/* loaded from: classes.dex */
public class CompassClockFaceViewCompass extends View {
    public static final float BIG_MARK_INNER_RADIUS = 0.34f;
    public static final float BIG_MARK_OUTER_RADIUS = 0.38f;
    public static final float DEGREE_RADIUS = 0.3f;
    public static final float DIRECTION_RADIUS = 0.215f;
    public static final float NORTH_MARK_INNER_RADIUS = 0.3f;
    public static final float NORTH_MARK_OUTER_RADIUS = 0.4f;
    public static final float SMALL_MARK_INNER_RADIUS = 0.35f;
    public static final float SMALL_MARK_OUTER_RADIUS = 0.38f;
    private Point CENTER;
    private float WIDTH;
    private float azimuth;
    private Paint bigMarkPaint;
    private Paint degreeTextPaint;
    private Paint directionTextMainPaint;
    private Paint directionTextSlavePaint;
    private String e;
    private String n;
    private String ne;
    private Paint northMarkPaint;
    private Paint northMarkStaticPaint;
    private Paint northMarkTextPaint;
    private String nw;
    private String s;
    private String se;
    private Paint smallMarkPaint;
    private String sw;
    private String w;
    private Path smallMarkPath = null;
    private Path bigMarkPath = null;
    private Path northMarkPath = null;
    private Path northMarkPath2 = null;

    public CompassClockFaceViewCompass(Context context) {
        super(context);
        init(context, null);
    }

    public CompassClockFaceViewCompass(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(context, attributeSet);
    }

    public CompassClockFaceViewCompass(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init(context, attributeSet);
    }

    private void init(Context context, AttributeSet attributeSet) {
        int i;
        Typeface create = Typeface.create("sans-serif-light", 0);
        Typeface create2 = Typeface.create("sans-serif-medium", 0);
        Resources resources = context.getResources();
        this.n = resources.getString(R.string.n);
        this.e = resources.getString(R.string.e);
        this.s = resources.getString(R.string.s);
        this.w = resources.getString(R.string.w);
        this.ne = resources.getString(R.string.ne);
        this.se = resources.getString(R.string.se);
        this.sw = resources.getString(R.string.sw);
        this.nw = resources.getString(R.string.nw);
        int color = resources.getColor(R.color.md_indigo_200);
        int color2 = resources.getColor(R.color.md_indigo_50);
        int color3 = resources.getColor(R.color.md_red_400);
        int color4 = resources.getColor(R.color.md_indigo_50);
        int color5 = resources.getColor(R.color.md_indigo_100);
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R.styleable.CompassClockFaceView);
            if (obtainStyledAttributes != null) {
                color = obtainStyledAttributes.getColor(4, resources.getColor(R.color.md_indigo_200));
                color2 = obtainStyledAttributes.getColor(0, resources.getColor(R.color.md_indigo_50));
                color3 = obtainStyledAttributes.getColor(1, resources.getColor(R.color.md_red_400));
                color4 = obtainStyledAttributes.getColor(2, resources.getColor(R.color.md_indigo_50));
                color5 = obtainStyledAttributes.getColor(3, resources.getColor(R.color.md_indigo_100));
                obtainStyledAttributes.recycle();
            }
            i = 1;
        } else {
            TypedValue typedValue = new TypedValue();
            Resources.Theme theme = context.getTheme();
            i = 1;
            theme.resolveAttribute(R.attr.smallMarkColor, typedValue, true);
            color = typedValue.data;
            theme.resolveAttribute(R.attr.bigMarkColor, typedValue, true);
            color2 = typedValue.data;
            theme.resolveAttribute(R.attr.northMarkColor, typedValue, true);
            color3 = typedValue.data;
            theme.resolveAttribute(R.attr.primaryTextColor, typedValue, true);
            color4 = typedValue.data;
            theme.resolveAttribute(R.attr.secondaryTextColor, typedValue, true);
            color5 = typedValue.data;
        }
        this.CENTER = new Point(0, 0);
        Paint paint = new Paint(i);
        this.smallMarkPaint = paint;
        paint.setStrokeCap(Paint.Cap.ROUND);
        this.smallMarkPaint.setColor(color);
        this.smallMarkPaint.setStyle(Paint.Style.STROKE);
        this.smallMarkPaint.setStrokeWidth(AndroidUtilsCompass.dpToPx(i));
        Paint paint2 = new Paint(i);
        this.bigMarkPaint = paint2;
        paint2.setStrokeCap(Paint.Cap.ROUND);
        this.bigMarkPaint.setColor(color2);
        this.bigMarkPaint.setStyle(Paint.Style.STROKE);
        this.bigMarkPaint.setStrokeWidth(AndroidUtilsCompass.dpToPx(2.0f));
        Paint paint3 = new Paint(1);
        this.northMarkStaticPaint = paint3;
        paint3.setStyle(Paint.Style.FILL);
        this.northMarkStaticPaint.setColor(color3);
        Paint paint4 = new Paint(1);
        this.northMarkPaint = paint4;
        paint4.setStrokeCap(Paint.Cap.ROUND);
        this.northMarkPaint.setColor(color3);
        this.northMarkPaint.setStyle(Paint.Style.STROKE);
        this.northMarkPaint.setStrokeWidth(AndroidUtilsCompass.dpToPx(4.0f));
        Paint paint5 = new Paint(1);
        this.northMarkTextPaint = paint5;
        paint5.setColor(color3);
        this.northMarkTextPaint.setTypeface(create2);
        this.northMarkTextPaint.setTextSize(AndroidUtilsCompass.dpToPx(28));
        this.northMarkTextPaint.setTextAlign(Paint.Align.CENTER);
        Paint paint6 = new Paint(1);
        this.degreeTextPaint = paint6;
        paint6.setTextSize(AndroidUtilsCompass.dpToPx(12));
        this.degreeTextPaint.setTypeface(create);
        this.degreeTextPaint.setColor(color4);
        this.degreeTextPaint.setTextAlign(Paint.Align.CENTER);
        Paint paint7 = new Paint(1);
        this.directionTextMainPaint = paint7;
        paint7.setColor(color4);
        this.directionTextMainPaint.setTextSize(AndroidUtilsCompass.dpToPx(26));
        this.directionTextMainPaint.setTypeface(create2);
        this.directionTextMainPaint.setTextAlign(Paint.Align.CENTER);
        Paint paint8 = new Paint(1);
        this.directionTextSlavePaint = paint8;
        paint8.setColor(color5);
        this.directionTextSlavePaint.setTextSize(AndroidUtilsCompass.dpToPx(14));
        this.directionTextSlavePaint.setTextAlign(Paint.Align.CENTER);
    }

    @Override // android.view.View
    protected void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        int size = MeasureSpec.getSize(i);
        int size2 = MeasureSpec.getSize(i2);
        if (size > size2) {
            size = size2;
        }
        setMeasuredDimension(resolveSize(size, i), resolveSize(size, i2));
    }

    @Override // android.view.View
    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        initConstants();
        layoutSmallClockMarks();
        layoutBigClockMarks();
        layoutNorthMark();
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.save();
        canvas.rotate(-this.azimuth, this.CENTER.x, this.CENTER.y);
        canvas.drawPath(this.smallMarkPath, this.smallMarkPaint);
        canvas.drawPath(this.bigMarkPath, this.bigMarkPaint);
        canvas.drawPath(this.northMarkPath, this.northMarkPaint);
        canvas.drawPath(this.northMarkPath2, this.northMarkStaticPaint);
        float f = this.WIDTH * 0.3f;
        drawText(canvas, 300.0f, "30", f, this.degreeTextPaint);
        drawText(canvas, 330.0f, "60", f, this.degreeTextPaint);
        drawText(canvas, 360.0f, "90", f, this.degreeTextPaint);
        drawText(canvas, 30.0f, "120", f, this.degreeTextPaint);
        drawText(canvas, 60.0f, "150", f, this.degreeTextPaint);
        drawText(canvas, 90.0f, "180", f, this.degreeTextPaint);
        drawText(canvas, 120.0f, "210", f, this.degreeTextPaint);
        drawText(canvas, 150.0f, "240", f, this.degreeTextPaint);
        drawText(canvas, 180.0f, "270", f, this.degreeTextPaint);
        drawText(canvas, 210.0f, "300", f, this.degreeTextPaint);
        drawText(canvas, 240.0f, "330", f, this.degreeTextPaint);
        float f2 = this.WIDTH * 0.215f;
        drawText(canvas, 270.0f, this.n, f2, this.northMarkTextPaint);
        drawText(canvas, 0.0f, this.e, f2, this.directionTextMainPaint);
        drawText(canvas, 90.0f, this.s, f2, this.directionTextMainPaint);
        drawText(canvas, 180.0f, this.w, f2, this.directionTextMainPaint);
        drawText(canvas, 315.0f, this.ne, f2, this.directionTextSlavePaint);
        drawText(canvas, 45.0f, this.se, f2, this.directionTextSlavePaint);
        drawText(canvas, 135.0f, this.sw, f2, this.directionTextSlavePaint);
        drawText(canvas, 225.0f, this.nw, f2, this.directionTextSlavePaint);
        canvas.restore();
    }

    private void initConstants() {
        float width = getWidth();
        this.WIDTH = width;
        this.CENTER.set(((int) width) / 2, getHeight() / 2);
    }

    private void layoutSmallClockMarks() {
        if (this.smallMarkPath == null) {
            float f = this.WIDTH;
            float f2 = 0.35f * f;
            float f3 = f * 0.38f;
            this.smallMarkPath = new Path();
            float f4 = 0.0f;
            while (true) {
                double d = f4;
                if (d < 6.283185307179586d) {
                    float cos = (float) Math.cos(d);
                    float sin = (float) Math.sin(d);
                    this.smallMarkPath.moveTo((f2 * cos) + this.CENTER.x, (f2 * sin) + this.CENTER.y);
                    this.smallMarkPath.lineTo((cos * f3) + this.CENTER.x, (sin * f3) + this.CENTER.y);
                    f4 = (float) (d + Math.toRadians(2.5f));
                } else {
                    return;
                }
            }
        }
    }

    private void layoutBigClockMarks() {
        if (this.bigMarkPath == null) {
            float f = this.WIDTH;
            float f2 = 0.34f * f;
            float f3 = f * 0.38f;
            this.bigMarkPath = new Path();
            float f4 = 0.0f;
            while (true) {
                double d = f4;
                if (d < 6.283185307179586d) {
                    float cos = (float) Math.cos(d);
                    float sin = (float) Math.sin(d);
                    this.bigMarkPath.moveTo((f2 * cos) + this.CENTER.x, (f2 * sin) + this.CENTER.y);
                    this.bigMarkPath.lineTo((cos * f3) + this.CENTER.x, (sin * f3) + this.CENTER.y);
                    f4 = (float) (d + Math.toRadians(30.0f));
                } else {
                    return;
                }
            }
        }
    }

    private void layoutNorthMark() {
        if (this.northMarkPath == null) {
            this.northMarkPath = new Path();
            double radians = (float) Math.toRadians(270.0d);
            float cos = (float) Math.cos(radians);
            float sin = (float) Math.sin(radians);
            float f = this.WIDTH;
            float f2 = 0.3f * f;
            float f3 = f * 0.4f;
            this.northMarkPath.moveTo(this.CENTER.x + (f2 * cos), this.CENTER.y + (f2 * sin));
            this.northMarkPath.lineTo((cos * f3) + this.CENTER.x, (f3 * sin) + this.CENTER.y);
        }
        if (this.northMarkPath2 == null) {
            float dpToPx = AndroidUtilsCompass.dpToPx(12);
            float f4 = this.CENTER.x;
            float f5 = this.CENTER.y - (this.WIDTH * 0.38f);
            Path path = new Path();
            this.northMarkPath2 = path;
            float f6 = dpToPx / 2.0f;
            float f7 = f4 - f6;
            path.moveTo(f7, f5);
            this.northMarkPath2.lineTo(f6 + f4, f5);
            this.northMarkPath2.lineTo(f4, this.CENTER.y - (this.WIDTH * 0.41f));
            this.northMarkPath2.lineTo(f7, f5);
        }
    }

    private void drawText(Canvas canvas, float f, String str, float f2, Paint paint) {
        canvas.save();
        double d = f;
        canvas.translate((((float) Math.cos(Math.toRadians(d))) * f2) + this.CENTER.x, (((float) Math.sin(Math.toRadians(d))) * f2) + this.CENTER.y);
        canvas.rotate(f + 90.0f);
        canvas.drawText(str, 0.0f, 0.0f, paint);
        canvas.restore();
    }

    public void updateAzimuth(float f) {
        if (((int) this.azimuth) != ((int) f)) {
            this.azimuth = f;
            invalidate();
        }
    }
}
