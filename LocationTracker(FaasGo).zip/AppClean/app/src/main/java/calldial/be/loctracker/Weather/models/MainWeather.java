package calldial.be.loctracker.Weather.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/* loaded from: classes.dex */
public class MainWeather {
    @SerializedName("grnd_level")
    @Expose
    private float grndLevel;
    @SerializedName("humidity")
    @Expose
    private int humidity;
    @SerializedName("pressure")
    @Expose
    private float pressure;
    @SerializedName("sea_level")
    @Expose
    private float seaLevel;
    @SerializedName("temp")
    @Expose
    private float temp;
    @SerializedName("temp_kf")
    @Expose
    private float tempKf;
    @SerializedName("temp_max")
    @Expose
    private float tempMax;
    @SerializedName("temp_min")
    @Expose
    private float tempMin;

    public float getTemp() {
        return this.temp;
    }

    public void setTemp(float f) {
        this.temp = f;
    }

    public float getTempMin() {
        return this.tempMin;
    }

    public void setTempMin(float f) {
        this.tempMin = f;
    }

    public float getTempMax() {
        return this.tempMax;
    }

    public void setTempMax(float f) {
        this.tempMax = f;
    }

    public float getPressure() {
        return this.pressure;
    }

    public void setPressure(float f) {
        this.pressure = f;
    }

    public float getSeaLevel() {
        return this.seaLevel;
    }

    public void setSeaLevel(float f) {
        this.seaLevel = f;
    }

    public float getGrndLevel() {
        return this.grndLevel;
    }

    public void setGrndLevel(float f) {
        this.grndLevel = f;
    }

    public int getHumidity() {
        return this.humidity;
    }

    public void setHumidity(int i) {
        this.humidity = i;
    }

    public float getTempKf() {
        return this.tempKf;
    }

    public void setTempKf(float f) {
        this.tempKf = f;
    }
}
