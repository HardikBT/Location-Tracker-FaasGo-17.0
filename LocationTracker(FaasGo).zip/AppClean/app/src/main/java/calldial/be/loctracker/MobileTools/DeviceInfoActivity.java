package calldial.be.loctracker.MobileTools;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Camera;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.PrintStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import calldial.be.loctracker.R;

/* loaded from: classes.dex */
public class DeviceInfoActivity extends AppCompatActivity {
    public static final int PERMISSION_CAMERA = 40;
    private BroadcastReceiver batteryInfoReceiver = new BroadcastReceiver() { // from class: calldial.be.loctracker.MobileTools.DeviceInfoActivity.1
        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            DeviceInfoActivity.this.updateBatteryData(intent);
        }
    };
    TextView tv_info;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_device_info);
        this.tv_info = (TextView) findViewById(R.id.tv_info);
    }

    private void getDeviceSuperInfo() {
        try {
            this.tv_info.setText(((((((((((((((("Debug-infos:\n OS Version: " + System.getProperty("os.version") + "(" + Build.VERSION.INCREMENTAL + ")") + "\n OS API Level: " + Build.VERSION.SDK_INT) + "\n Device: " + Build.DEVICE) + "\n Model (and Product): " + Build.MODEL + " (" + Build.PRODUCT + ")") + "\n RELEASE: " + Build.VERSION.RELEASE) + "\n BRAND: " + Build.BRAND) + "\n DISPLAY: " + Build.DISPLAY) + "\n CPU_ABI: " + Build.CPU_ABI) + "\n CPU_ABI2: " + Build.CPU_ABI2) + "\n UNKNOWN: unknown") + "\n HARDWARE: " + Build.HARDWARE) + "\n Build ID: " + Build.ID) + "\n MANUFACTURER: " + Build.MANUFACTURER) + "\n SERIAL: " + Build.SERIAL) + "\n USER: " + Build.USER) + "\n HOST: " + Build.HOST);
        } catch (Exception unused) {
            Toast.makeText(this, "Error getting Device INFO", 0).show();
        }
    }

    public void getScreenResolution() {
        Display defaultDisplay = ((WindowManager) getApplicationContext().getSystemService("window")).getDefaultDisplay();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        defaultDisplay.getMetrics(displayMetrics);
        int i = displayMetrics.widthPixels;
        int i2 = displayMetrics.heightPixels;
        Toast.makeText(getApplicationContext(), "{" + i + "," + i2 + "}", 0).show();
    }

    public void getScreenDensity() {
        String str;
        double d = getResources().getDisplayMetrics().density;
        String str2 = "unknown";
        if (d == 0.75d) {
            str2 = "100 DPI";
            str = "Low";
        } else if (d == 1.0d) {
            str2 = "160 DPI";
            str = "Medium";
        } else if (d == 1.5d) {
            str2 = "240 DPI";
            str = "High";
        } else if (d == 2.0d) {
            str2 = "320 DPI";
            str = "X High";
        } else if (d == 3.0d) {
            str2 = "480 DPI";
            str = "XX High";
        } else if (d == 4.0d) {
            str2 = "640 DPI";
            str = "XXX High";
        } else {
            str = str2;
        }
        Toast.makeText(this, str2 + " (" + str + ")", 0).show();
    }

    public void getScreenRefreshRate() {
        Display defaultDisplay = ((WindowManager) getSystemService("window")).getDefaultDisplay();
        Toast.makeText(this, "RefreshRate : " + (String.valueOf(defaultDisplay.getRefreshRate()) + " Hz"), 0).show();
    }

    public void getScreenPhysicalSize() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        double sqrt = Math.sqrt(Math.pow(displayMetrics.widthPixels / displayMetrics.xdpi, 2.0d) + Math.pow(displayMetrics.heightPixels / displayMetrics.ydpi, 2.0d));
        DecimalFormat decimalFormat = new DecimalFormat("##.00");
        double parseDouble = Double.parseDouble(decimalFormat.format(sqrt));
        double parseDouble2 = Double.parseDouble(decimalFormat.format(2.54d * parseDouble));
        Toast.makeText(this, (parseDouble + "\"") + " (" + (parseDouble2 + " cm") + ")", 0).show();
    }

    public void getCameraMegapixels() {
        if (ContextCompat.checkSelfPermission(this, "android.permission.CAMERA") != 0) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.CAMERA"}, 40);
        }
        if (ContextCompat.checkSelfPermission(this, "android.permission.CAMERA") == 0) {
            Camera open = Camera.open(0);
            List<Camera.Size> supportedPictureSizes = open.getParameters().getSupportedPictureSizes();
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            for (int i = 0; i < supportedPictureSizes.size(); i++) {
                Camera.Size size = supportedPictureSizes.get(i);
                arrayList.add(Integer.valueOf(size.width));
                arrayList2.add(Integer.valueOf(size.height));
                PrintStream printStream = System.out;
                printStream.println("BACK PictureSize Supported Size: " + size.width + "height : " + size.height);
            }
            if (!(arrayList.size() == 0 || arrayList2.size() == 0)) {
                Toast.makeText(this, "Back Megapixel :" + ((((Integer) Collections.max(arrayList)).intValue() * ((Integer) Collections.max(arrayList2)).intValue()) / 1024000), 0).show();
            }
            open.release();
            arrayList.clear();
            arrayList2.clear();
            Camera open2 = Camera.open(1);
            List<Camera.Size> supportedPictureSizes2 = open2.getParameters().getSupportedPictureSizes();
            for (int i2 = 0; i2 < supportedPictureSizes2.size(); i2++) {
                Camera.Size size2 = supportedPictureSizes2.get(i2);
                arrayList.add(Integer.valueOf(size2.width));
                arrayList2.add(Integer.valueOf(size2.height));
                PrintStream printStream2 = System.out;
                printStream2.println("FRONT PictureSize Supported Size: " + size2.width + "height : " + size2.height);
            }
            if (!(arrayList.size() == 0 || arrayList2.size() == 0)) {
                Toast.makeText(this, "FRONT Megapixel :" + ((((Integer) Collections.max(arrayList)).intValue() * ((Integer) Collections.max(arrayList2)).intValue()) / 1024000), 0).show();
            }
            open2.release();
        }
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i == 40) {
            if (iArr.length <= 0 || iArr[0] != 0) {
                ActivityCompat.requestPermissions(this, new String[]{"android.permission.CAMERA"}, 40);
                Toast.makeText(this, "Please allow permission to access", 0).show();
                return;
            }
            getCameraMegapixels();
        }
    }

    private void getAllBatteryInfo() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.ACTION_POWER_CONNECTED");
        intentFilter.addAction("android.intent.action.ACTION_POWER_DISCONNECTED");
        intentFilter.addAction("android.intent.action.BATTERY_CHANGED");
        registerReceiver(this.batteryInfoReceiver, intentFilter);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:51:0x0119  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x0135  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x013f  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x0156  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x0161  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void updateBatteryData(Intent intent) {
        String str = null;
        String str2 = null;
        String str3;
        String str4;
        String str5;
        String str6;
        int i;
        int intExtra;
        int intExtra2;
        long batteryCapacity;
        String str7 = "None";
        if (intent.getBooleanExtra("present", false)) {
            switch (intent.getIntExtra("health", 0)) {
                case 2:
                    i = R.string.battery_health_good;
                    break;
                case 3:
                    i = R.string.battery_health_overheat;
                    break;
                case 4:
                    i = R.string.battery_health_dead;
                    break;
                case 5:
                    i = R.string.battery_health_over_voltage;
                    break;
                case 6:
                    i = R.string.battery_health_unspecified_failure;
                    break;
                case 7:
                    i = R.string.battery_health_cold;
                    break;
                default:
                    i = -1;
                    break;
            }
            if (i != -1) {
                str7 = "Health : " + getString(i);
            } else {
                str7 = str7;
            }
            int intExtra3 = intent.getIntExtra("level", -1);
            int intExtra4 = intent.getIntExtra("scale", -1);
            if (intExtra3 == -1 || intExtra4 == -1) {
                str5 = str7;
            } else {
                str5 = "Battery Pct : " + ((int) ((intExtra3 / intExtra4) * 100.0f)) + " %";
            }
            int intExtra5 = intent.getIntExtra("plugged", 0);
            int i2 = intExtra5 != 1 ? intExtra5 != 2 ? intExtra5 != 4 ? R.string.battery_plugged_none : R.string.battery_plugged_wireless : R.string.battery_plugged_usb : R.string.battery_plugged_ac;
            str4 = "Plugged : " + getString(i2);
            int intExtra6 = intent.getIntExtra("status", -1);
            int i3 = R.string.battery_status_discharging;
            if (intExtra6 == 1) {
                i3 = -1;
            } else if (intExtra6 == 2) {
                i3 = R.string.battery_status_charging;
            } else if (intExtra6 != 3 && intExtra6 == 5) {
                i3 = R.string.battery_status_full;
            }
            if (i3 != -1) {
                str6 = "Battery Charging Status : " + getString(i3);
            } else {
                str6 = str7;
            }
            if (intent.getExtras() != null) {
                String string = intent.getExtras().getString("technology");
                if (!"".equals(string)) {
                    str3 = "Technology : " + string;
                    intExtra = intent.getIntExtra("temperature", 0);
                    if (intExtra <= 0) {
                        str2 = "Temperature : " + (intExtra / 10.0f) + "°C";
                    } else {
                        str2 = str7;
                    }
                    intExtra2 = intent.getIntExtra("voltage", 0);
                    if (intExtra2 <= 0) {
                        str = "Voltage : " + intExtra2 + " mV";
                    } else {
                        str = str7;
                    }
                    batteryCapacity = getBatteryCapacity(this);
                    if (batteryCapacity > 0) {
                        str7 = "Capacity : " + batteryCapacity + " mAh";
                    }
                }
            }
            str3 = str7;
            intExtra = intent.getIntExtra("temperature", 0);
            if (intExtra <= 0) {
            }
            intExtra2 = intent.getIntExtra("voltage", 0);
            if (intExtra2 <= 0) {
            }
            batteryCapacity = getBatteryCapacity(this);
            if (batteryCapacity > 0) {
            }
        } else {
            Toast.makeText(this, "No Battery present", 0).show();
            str = str7;
            str7 = str;
            str6 = str7;
            str5 = str6;
            str4 = str5;
            str3 = str4;
            str2 = str3;
        }
        this.tv_info.setText(str7 + "\n" + str5 + "\n" + str4 + "\n" + str6 + "\n" + str3 + "\n" + str2 + "\n" + str + "\n" + str7 + "\n");
    }

    public long getBatteryCapacity(Context context) {
        if (Build.VERSION.SDK_INT < 21) {
            return 0L;
        }
        BatteryManager batteryManager = (BatteryManager) context.getSystemService("batterymanager");
        Long valueOf = Long.valueOf(batteryManager.getLongProperty(1));
        Long valueOf2 = Long.valueOf(batteryManager.getLongProperty(4));
        if (valueOf == null || valueOf2 == null) {
            return 0L;
        }
        return (long) ((((float) valueOf.longValue()) / ((float) valueOf2.longValue())) * 100.0f);
    }
}
