package calldial.be.loctracker.MagicCode;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.lifecycle.ProcessLifecycleOwner;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import calldial.be.loctracker.Compass.InjectorCompass;
import calldial.be.loctracker.MagicBold.AllAdsKeyPlace;
import calldial.be.loctracker.MagicBold.AppPrefrence;

/* loaded from: classes.dex */
public class GlobalMaintainer extends Application implements Application.ActivityLifecycleCallbacks, LifecycleObserver {
    public static String AD_ON_OFF = "off";
    public static String APP_OPEN_ID = "";
    public static String BANNER_ID = "";
    public static String INTERSTITIAL_ID = "";
    public static String NATIVE_ID = "";
    public static String QUREKA = "off";
    public static String TAG = "MagicCodeAM";
    public static List<String> TestDeviceID = Arrays.asList("9568F35768B1E464FE89FCA084A30A22");
    public static String Volley_Loading_Completed = "no";
    public static InjectorCompass injector;
    private AppOpenAdManager appOpenAdManager;
    private Activity currentActivity;

    /* loaded from: classes.dex */
    public interface OnShowAdCompleteListener {
        void onShowAdComplete();
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityCreated(Activity activity, Bundle bundle) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityDestroyed(Activity activity) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPaused(Activity activity) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityResumed(Activity activity) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityStopped(Activity activity) {
    }

    public static InjectorCompass getInjector() {
        return injector;
    }

    @Override // android.app.Application
    public void onCreate() {
        super.onCreate();
        MobileAds.initialize(this, new OnInitializationCompleteListener() { // from class: calldial.be.loctracker.MagicCode.GlobalMaintainer.1
            @Override // com.google.android.gms.ads.initialization.OnInitializationCompleteListener
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        MobileAds.setRequestConfiguration(new RequestConfiguration.Builder().setTestDeviceIds(TestDeviceID).build());
        registerActivityLifecycleCallbacks(this);
        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);
        this.appOpenAdManager = new AppOpenAdManager();
        fetchDataVolley();
        injector = new InjectorCompass(getApplicationContext());
    }

    @Override // android.app.Application
    public void onTerminate() {
        super.onTerminate();
        injector.releaseMainPresenter();
        injector.closeTasks();
    }

    public void fetchDataVolley() {
        Volley.newRequestQueue(this).add(new JsonObjectRequest(0, "https://s3.ap-south-1.amazonaws.com/get.all.caller.info.officially.locked/magic_code.txt", null, new Response.Listener<JSONObject>() { // from class: calldial.be.loctracker.MagicCode.GlobalMaintainer.3
            public void onResponse(JSONObject jSONObject) {
                try {
                    GlobalMaintainer.AD_ON_OFF = jSONObject.getString("ad_on_off");
                    GlobalMaintainer.APP_OPEN_ID = jSONObject.getString("app_open_id");
                    GlobalMaintainer.BANNER_ID = jSONObject.getString("banner_id");
                    GlobalMaintainer.INTERSTITIAL_ID = jSONObject.getString("interstitial_id");
                    GlobalMaintainer.NATIVE_ID = jSONObject.getString("native_id");
                    GlobalMaintainer.QUREKA = jSONObject.getString("qureka");
                    GlobalMaintainer.this.setAppPreferenceId();
                    GlobalMaintainer.Volley_Loading_Completed = "yes";
                } catch (JSONException e) {
                    e.printStackTrace();
                    GlobalMaintainer.this.setAppPreferenceId();
                    GlobalMaintainer.Volley_Loading_Completed = "yes";
                }
            }
        }, new Response.ErrorListener() { // from class: calldial.be.loctracker.MagicCode.GlobalMaintainer.4
            @Override // com.android.volley.Response.ErrorListener
            public void onErrorResponse(VolleyError volleyError) {
                GlobalMaintainer.this.setAppPreferenceId();
                GlobalMaintainer.Volley_Loading_Completed = "yes";
            }
        }));
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    public void onMoveToForeground() {
        this.appOpenAdManager.showAdIfAvailable(this.currentActivity);
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityStarted(Activity activity) {
        if (!this.appOpenAdManager.isShowingAd) {
            this.currentActivity = activity;
        }
    }

    public void showAdIfAvailable(Activity activity, OnShowAdCompleteListener onShowAdCompleteListener) {
        this.appOpenAdManager.showAdIfAvailable(activity, onShowAdCompleteListener);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public class AppOpenAdManager {
        private static final String LOG_TAG = "AppOpenAdManager";
        private AppOpenAd appOpenAd = null;
        private boolean isLoadingAd = false;
        private boolean isShowingAd = false;
        private long loadTime = 0;

        public AppOpenAdManager() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void loadAd(Context context) {
            if (!this.isLoadingAd && !isAdAvailable()) {
                this.isLoadingAd = true;
                AppOpenAd.load(context, new AppPrefrence(context).getAM_BETA(), new AdRequest.Builder().build(), 1, new AppOpenAd.AppOpenAdLoadCallback() { // from class: calldial.be.loctracker.MagicCode.GlobalMaintainer.AppOpenAdManager.1
                    public void onAdLoaded(AppOpenAd appOpenAd) {
                        AppOpenAdManager.this.appOpenAd = appOpenAd;
                        AppOpenAdManager.this.isLoadingAd = false;
                        AppOpenAdManager.this.loadTime = new Date().getTime();
                        Log.d(AppOpenAdManager.LOG_TAG, "onAdLoaded.");
                    }

                    @Override // com.google.android.gms.ads.AdLoadCallback
                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        AppOpenAdManager.this.isLoadingAd = false;
                        Log.d(AppOpenAdManager.LOG_TAG, "onAdFailedToLoad: " + loadAdError.getMessage());
                    }
                });
            }
        }

        private boolean wasLoadTimeLessThanNHoursAgo(long j) {
            return new Date().getTime() - this.loadTime < j * 3600000;
        }

        private boolean isAdAvailable() {
            return this.appOpenAd != null && wasLoadTimeLessThanNHoursAgo(4L);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void showAdIfAvailable(Activity activity) {
            showAdIfAvailable(activity, new OnShowAdCompleteListener() { // from class: calldial.be.loctracker.MagicCode.GlobalMaintainer.AppOpenAdManager.2
                @Override // calldial.be.loctracker.MagicCode.GlobalMaintainer.OnShowAdCompleteListener
                public void onShowAdComplete() {
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void showAdIfAvailable(final Activity activity, final OnShowAdCompleteListener onShowAdCompleteListener) {
            if (this.isShowingAd) {
                Log.d(LOG_TAG, "The app open ad is already showing.");
            } else if (!isAdAvailable()) {
                Log.d(LOG_TAG, "The app open ad is not ready yet.");
                onShowAdCompleteListener.onShowAdComplete();
                loadAd(activity);
            } else {
                Log.d(LOG_TAG, "Will show ad.");
                this.appOpenAd.setFullScreenContentCallback(new FullScreenContentCallback() { // from class: calldial.be.loctracker.MagicCode.GlobalMaintainer.AppOpenAdManager.3
                    @Override // com.google.android.gms.ads.FullScreenContentCallback
                    public void onAdDismissedFullScreenContent() {
                        AppOpenAdManager.this.appOpenAd = null;
                        AppOpenAdManager.this.isShowingAd = false;
                        Log.d(AppOpenAdManager.LOG_TAG, "onAdDismissedFullScreenContent.");
                        onShowAdCompleteListener.onShowAdComplete();
                        AppOpenAdManager.this.loadAd(activity);
                    }

                    @Override // com.google.android.gms.ads.FullScreenContentCallback
                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                        AppOpenAdManager.this.appOpenAd = null;
                        AppOpenAdManager.this.isShowingAd = false;
                        Log.d(AppOpenAdManager.LOG_TAG, "onAdFailedToShowFullScreenContent: " + adError.getMessage());
                        onShowAdCompleteListener.onShowAdComplete();
                        AppOpenAdManager.this.loadAd(activity);
                    }

                    @Override // com.google.android.gms.ads.FullScreenContentCallback
                    public void onAdShowedFullScreenContent() {
                        Log.d(AppOpenAdManager.LOG_TAG, "onAdShowedFullScreenContent.");
                    }
                });
                this.isShowingAd = true;
                this.appOpenAd.show(activity);
            }
        }
    }

    public void setAppPreferenceId() {
        AppPrefrence appPrefrence = new AppPrefrence(this);
        appPrefrence.setAds_On_Off(AD_ON_OFF);
        appPrefrence.setCF("off");
        appPrefrence.setCURL("");
        appPrefrence.setAM_FB_Priority("AM");
        appPrefrence.setSplash_Priority("beta");
        appPrefrence.setBackPress_Priority("inter");
        appPrefrence.setQureka_ADS(QUREKA);
        appPrefrence.setBack_cnt(2);
        appPrefrence.setFront_cnt(1);
        appPrefrence.setAM_INTERTITIAL(INTERSTITIAL_ID);
        appPrefrence.setAM_BETA(APP_OPEN_ID);
        appPrefrence.setAM_NATIVE_BIG_HOME(NATIVE_ID);
        appPrefrence.setAM_Rewarded_Video("");
        appPrefrence.setAM_RECT_BIG_HOME(BANNER_ID);
        appPrefrence.setAM_NATIVE_BANNER_HOME(NATIVE_ID);
        this.appOpenAdManager.loadAd(this.currentActivity);
        AllAdsKeyPlace.LoadInterstitialAds(this);
    }
}
