package calldial.be.loctracker.Compass.app.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.PointF;
import android.util.AttributeSet;
import android.view.View;

import calldial.be.loctracker.Compass.util.AndroidUtilsCompass;

public class AccelerometerViewCompass extends View {
    private int MAX_ACCELERATION;
    float MAX_MOVE;
    private AccelerometerDrawerCompass drawer;
    private boolean isSimple;
    private float k;
    private float pitch = 0.0f;
    private PointF point;
    private float roll = 0.0f;

    public AccelerometerViewCompass(Context context) {
        super(context);
        float dpToPx = AndroidUtilsCompass.dpToPx(50);
        this.MAX_MOVE = dpToPx;
        this.k = (float) (((double) dpToPx) / 1.5707963267948966d);
        this.isSimple = false;
        init(context);
    }

    public AccelerometerViewCompass(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        float dpToPx = AndroidUtilsCompass.dpToPx(50);
        this.MAX_MOVE = dpToPx;
        this.k = (float) (((double) dpToPx) / 1.5707963267948966d);
        this.isSimple = false;
        init(context);
    }

    public AccelerometerViewCompass(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        int dpToPx = (int) AndroidUtilsCompass.dpToPx(50);
        this.MAX_MOVE = dpToPx;
        this.k = (float) (((double) dpToPx) / 1.5707963267948966d);
        this.isSimple = false;
        init(context);
    }

    private void init(Context context) {
        this.point = new PointF(0.0f, 0.0f);
        this.drawer = new AccelerometerDrawerCompass(context, this.isSimple);
    }

    /* Access modifiers changed, original: protected */
    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        int size = MeasureSpec.getSize(i);
        int size2 = MeasureSpec.getSize(i2);
        if (size > size2) {
            size = size2;
        }
        setMeasuredDimension(resolveSize(size, i), resolveSize(size, i2));
    }

    /* Access modifiers changed, original: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        int width = getWidth();
        i = width / 2;
        this.MAX_MOVE = i;
        this.k = (float) (((double) i) / 1.5707963267948966d);
        this.MAX_ACCELERATION = width / 10;
        this.drawer.layout(getWidth(), getHeight());
    }

    /* Access modifiers changed, original: protected */
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.drawer.draw(canvas);
    }

    public void updateOrientation(float f, float f2) {
        if (((int) this.pitch) != ((int) f) || ((int) this.roll) != ((int) f2)) {
            this.pitch = f;
            this.roll = f2;
            this.point.set((((float) getWidth()) * 0.37f) * ((float) Math.cos(Math.toRadians((double) (90.0f - f2)))), (((float) getWidth()) * 0.37f) * ((float) Math.cos(Math.toRadians((double) (90.0f - f)))));
            this.drawer.update(this.point);
            invalidate();
        }
    }

    public void updateLinearAcceleration(float f, float f2) {
        if (((int) this.pitch) != ((int) f) * 1000 || ((int) this.roll) != ((int) f2) * 1000) {
            this.pitch = f * 1000.0f;
            this.roll = 1000.0f * f2;
            PointF pointF = this.point;
            float f3 = this.k;
            f = (float) (((double) f3) * Math.atan((double) ((f * ((float) this.MAX_ACCELERATION)) / f3)));
            f3 = this.k;
            pointF.set(f, (float) (((double) f3) * Math.atan((double) ((f2 * ((float) this.MAX_ACCELERATION)) / f3))));
            this.drawer.update(this.point);
            invalidate();
        }
    }

    public void setSimpleMode(boolean z) {
        if (this.isSimple != z) {
            this.isSimple = z;
            AccelerometerDrawerCompass accelerometerDrawerCompass = new AccelerometerDrawerCompass(getContext(), this.isSimple);
            this.drawer = accelerometerDrawerCompass;
            accelerometerDrawerCompass.update(this.point);
            requestLayout();
        }
    }
}