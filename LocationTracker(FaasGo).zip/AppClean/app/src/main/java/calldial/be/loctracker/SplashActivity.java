package calldial.be.loctracker;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.Log;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.work.WorkRequest;

import com.facebook.FacebookSdk;
import com.facebook.appevents.AppEventsLogger;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import org.imaginativeworld.oopsnointernet.callbacks.ConnectionCallback;
import org.imaginativeworld.oopsnointernet.dialogs.pendulum.DialogPropertiesPendulum;
import org.imaginativeworld.oopsnointernet.dialogs.pendulum.NoInternetDialogPendulum;

import java.util.Timer;
import java.util.TimerTask;

import calldial.be.loctracker.MagicBold.AppPrefrence;
import calldial.be.loctracker.MagicCode.GlobalMaintainer;


/* loaded from: classes.dex */
public class SplashActivity extends AppCompatActivity {
    private static final String LOG_TAG = "AppOpenBeta";
    private AppOpenAd appOpenAd = null;
    ImageView iv_line;
    ImageView iv_logo;
    private AppOpenAd.AppOpenAdLoadCallback loadCallback;
    TextView name;
    TextView tagline;
    Timer timer;
    Window window;

    /* JADX WARN: Type inference failed for: r9v3, types: [calldial.be.loctracker.SplashActivity$5] */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.activity_splash);
        Window window = getWindow();
        this.window = window;
        window.getDecorView().setSystemUiVisibility(1280);
        MobileAds.initialize(this, new OnInitializationCompleteListener() { // from class: calldial.be.loctracker.SplashActivity.1
            @Override // com.google.android.gms.ads.initialization.OnInitializationCompleteListener
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        this.name = (TextView) findViewById(R.id.name);
        this.tagline = (TextView) findViewById(R.id.tagline);
        this.iv_line = (ImageView) findViewById(R.id.iv_line);
        this.iv_logo = (ImageView) findViewById(R.id.iv_logo);
        Animation loadAnimation = AnimationUtils.loadAnimation(this, R.anim.textview_down_anim);
        Animation loadAnimation2 = AnimationUtils.loadAnimation(this, R.anim.textview_up_anim);
        Animation loadAnimation3 = AnimationUtils.loadAnimation(this, R.anim.slide_left);
        final Animation loadAnimation4 = AnimationUtils.loadAnimation(this, R.anim.zoom_in);
        new Handler().postDelayed(new Runnable() { // from class: calldial.be.loctracker.SplashActivity.2
            @Override // java.lang.Runnable
            public void run() {
                SplashActivity.this.iv_logo.setVisibility(0);
                SplashActivity.this.iv_logo.startAnimation(loadAnimation4);
            }
        }, 100L);
        new Handler().postDelayed(new AnonymousClass3(loadAnimation3, loadAnimation2, loadAnimation), 1000L);
        FacebookSdk.setApplicationId(getResources().getString(R.string.facebook_app_id));
        FacebookSdk.sdkInitialize(getApplicationContext());
        AppEventsLogger.activateApp(this);
        NoInternetDialogPendulum.Builder builder = new NoInternetDialogPendulum.Builder(this, getLifecycle());
        DialogPropertiesPendulum dialogProperties = builder.getDialogProperties();
        dialogProperties.setConnectionCallback(new ConnectionCallback() { // from class: calldial.be.loctracker.SplashActivity.4
            @Override // org.imaginativeworld.oopsnointernet.callbacks.ConnectionCallback
            public void hasActiveConnection(boolean z) {
            }
        });
        dialogProperties.setCancelable(false);
        dialogProperties.setNoInternetConnectionTitle("No Internet");
        dialogProperties.setNoInternetConnectionMessage("Check your Internet connection and try again");
        dialogProperties.setShowInternetOnButtons(true);
        dialogProperties.setPleaseTurnOnText("Please turn on");
        dialogProperties.setWifiOnButtonText("Wifi");
        dialogProperties.setMobileDataOnButtonText("Mobile data");
        dialogProperties.setOnAirplaneModeTitle("No Internet");
        dialogProperties.setOnAirplaneModeMessage("You have turned on the airplane mode.");
        dialogProperties.setPleaseTurnOffText("Please turn off");
        dialogProperties.setAirplaneModeOffButtonText("Airplane mode");
        dialogProperties.setShowAirplaneModeOffButtons(true);
        builder.build();
        if (Common.isNetworkConnected(this)) {
            TimerForNext();
            new CountDownTimer(9500L, 100L) { // from class: calldial.be.loctracker.SplashActivity.5
                @Override // android.os.CountDownTimer
                public void onTick(long j) {
                    if (GlobalMaintainer.Volley_Loading_Completed.equalsIgnoreCase("yes")) {
                        cancel();
                        onFinish();
                    }
                }

                @Override // android.os.CountDownTimer
                public void onFinish() {
                    if (new AppPrefrence(SplashActivity.this.getApplicationContext()).getAds_On_Off().equalsIgnoreCase("on")) {
                        SplashActivity.this.fetchAppOpenAd();
                    }
                }
            }.start();
        }
    }

    /* renamed from: calldial.be.loctracker.SplashActivity$3  reason: invalid class name */
    /* loaded from: classes.dex */
    class AnonymousClass3 implements Runnable {
        final /* synthetic */ Animation val$down;
        final /* synthetic */ Animation val$slideleft;
        final /* synthetic */ Animation val$up;

        AnonymousClass3(Animation animation, Animation animation2, Animation animation3) {
            this.val$slideleft = animation;
            this.val$up = animation2;
            this.val$down = animation3;
        }

        @Override // java.lang.Runnable
        public void run() {
            SplashActivity.this.iv_line.setVisibility(0);
            SplashActivity.this.iv_line.startAnimation(this.val$slideleft);
            new Handler().postDelayed(new Runnable() { // from class: calldial.be.loctracker.SplashActivity.3.1
                @Override // java.lang.Runnable
                public void run() {
                    SplashActivity.this.name.setVisibility(0);
                    SplashActivity.this.name.startAnimation(AnonymousClass3.this.val$up);
                    new Handler().postDelayed(new Runnable() { // from class: calldial.be.loctracker.SplashActivity.3.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            SplashActivity.this.tagline.setVisibility(0);
                            SplashActivity.this.tagline.startAnimation(AnonymousClass3.this.val$down);
                        }
                    }, 1000L);
                }
            }, 1000L);
        }
    }

    public void fetchAppOpenAd() {
        if (!GlobalMaintainer.APP_OPEN_ID.isEmpty() && !GlobalMaintainer.APP_OPEN_ID.equals(null) && GlobalMaintainer.APP_OPEN_ID != null && !GlobalMaintainer.APP_OPEN_ID.equals("") && !GlobalMaintainer.APP_OPEN_ID.equalsIgnoreCase("")) {
            this.loadCallback = new AppOpenAd.AppOpenAdLoadCallback() { // from class: calldial.be.loctracker.SplashActivity.6
                @Override // com.google.android.gms.ads.AdLoadCallback
                public void onAdFailedToLoad(LoadAdError loadAdError) {
                }

                public void onAdLoaded(AppOpenAd appOpenAd) {
                    SplashActivity.this.appOpenAd = appOpenAd;
                    SplashActivity.this.showAdIfAvailable();
                }
            };
            AppOpenAd.load(this, GlobalMaintainer.APP_OPEN_ID, getAdRequest(), 1, this.loadCallback);
        }
    }

    private AdRequest getAdRequest() {
        return new AdRequest.Builder().build();
    }

    public boolean isAdAvailable() {
        return this.appOpenAd != null;
    }

    public void showAdIfAvailable() {
        if (isAdAvailable()) {
            Log.d(LOG_TAG, "Will show ad.");
            this.appOpenAd.setFullScreenContentCallback(new FullScreenContentCallback() { // from class: calldial.be.loctracker.SplashActivity.7

                @Override // com.google.android.gms.ads.FullScreenContentCallback
                public void onAdFailedToShowFullScreenContent(AdError adError) {
                }

                @Override // com.google.android.gms.ads.FullScreenContentCallback
                public void onAdImpression() {
                }

                @Override // com.google.android.gms.ads.FullScreenContentCallback
                public void onAdDismissedFullScreenContent() {
                    SplashActivity.this.appOpenAd = null;
                    SplashActivity.this.MoveToNext("off");
                }

                @Override // com.google.android.gms.ads.FullScreenContentCallback
                public void onAdShowedFullScreenContent() {
                    SplashActivity.this.timer.cancel();
                }
            });
            this.appOpenAd.show(this);
            return;
        }
        Log.d(LOG_TAG, "Can not show ad.");
        fetchAppOpenAd();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void MoveToNext(String str) {
        if (str.equalsIgnoreCase("off")) {
            startActivity(new Intent(this, PrivacyPolicyActivity.class));
            finish();
            return;
        }
        startActivity(new Intent(this, PrivacyPolicyActivity.class).putExtra("my_boolean_key", true));
        finish();
    }

    public void TimerForNext() {
        Timer timer = new Timer();
        this.timer = timer;
        timer.schedule(new TimerTask() { // from class: calldial.be.loctracker.SplashActivity.8
            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                SplashActivity.this.MoveToNext("on");
            }
        }, WorkRequest.MIN_BACKOFF_MILLIS);
    }
}
