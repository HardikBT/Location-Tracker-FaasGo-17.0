package calldial.be.loctracker.Compass.app.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.TypedValue;

import com.tomlonghurst.expandablehinttext.ConstantsKt;

import calldial.be.loctracker.Compass.util.AndroidUtilsCompass;
import calldial.be.loctracker.R;

/* loaded from: classes.dex */
public class MagneticFieldDrawerCompass implements ViewDrawerCompass<Float> {
    private static final float MAGNETIC_NAME_RADIUS = 0.414f;
    private static final float MAGNETIC_VAL_RADIUS = 0.4f;
    private static final float MAGNETIC_VIEW_RADIUS = 0.407f;
    private Point CENTER;
    private float WIDTH;
    private String mT;
    private String magField;
    private Paint magneticBackgroundPaint;
    private Path magneticBackgroundPath = null;
    private float magneticField;
    private Paint magneticFieldPaint;
    private Path magneticPath;
    private Paint magneticTextPaint;

    public MagneticFieldDrawerCompass(Context context) {
        int i;
        int i2;
        int i3;
        Typeface create = Typeface.create("sans-serif-light", 0);
        Resources resources = context.getResources();
        this.mT = resources.getString(R.string.mt_val);
        this.magField = resources.getString(R.string.mag_field);
        TypedValue typedValue = new TypedValue();
        Resources.Theme theme = context.getTheme();
        if (theme.resolveAttribute(R.attr.indicatorBackgroundColor, typedValue, true)) {
            i = typedValue.data;
        } else {
            i = resources.getColor(R.color.md_indigo_800x);
        }
        if (theme.resolveAttribute(R.attr.indicatorTextColor, typedValue, true)) {
            i2 = typedValue.data;
        } else {
            i2 = resources.getColor(R.color.md_indigo_100);
        }
        if (theme.resolveAttribute(R.attr.indicatorFieldColor, typedValue, true)) {
            i3 = typedValue.data;
        } else {
            i3 = resources.getColor(R.color.md_green_400);
        }
        this.magneticPath = new Path();
        this.CENTER = new Point(0, 0);
        Paint paint = new Paint(1);
        this.magneticBackgroundPaint = paint;
        paint.setStyle(Paint.Style.STROKE);
        this.magneticBackgroundPaint.setStrokeCap(Paint.Cap.ROUND);
        this.magneticBackgroundPaint.setStrokeWidth(AndroidUtilsCompass.dpToPx(6));
        this.magneticBackgroundPaint.setColor(i);
        Paint paint2 = new Paint(1);
        this.magneticTextPaint = paint2;
        paint2.setColor(i2);
        this.magneticTextPaint.setTextSize(AndroidUtilsCompass.dpToPx(10));
        this.magneticTextPaint.setTypeface(create);
        this.magneticTextPaint.setTextAlign(Paint.Align.CENTER);
        Paint paint3 = new Paint(1);
        this.magneticFieldPaint = paint3;
        paint3.setColor(i3);
        this.magneticFieldPaint.setStrokeWidth(AndroidUtilsCompass.dpToPx(6));
        this.magneticFieldPaint.setStyle(Paint.Style.STROKE);
        this.magneticFieldPaint.setStrokeCap(Paint.Cap.ROUND);
    }

    @Override // calldial.be.loctracker.Compass.app.widget.ViewDrawerCompass
    public void layout(int i, int i2) {
        initConstants(i, i2);
        layoutMagnetic();
    }

    @Override // calldial.be.loctracker.Compass.app.widget.ViewDrawerCompass
    public void draw(Canvas canvas) {
        drawMagnetic(canvas);
    }

    public void update(Float f) {
        this.magneticField = f.floatValue();
    }

    private void initConstants(int i, int i2) {
        this.WIDTH = i;
        this.CENTER.set(i / 2, i2 / 2);
    }

    private void layoutMagnetic() {
        if (this.magneticBackgroundPath == null) {
            float f = this.WIDTH * 0.407f;
            RectF rectF = new RectF(this.CENTER.x - f, this.CENTER.y - f, this.CENTER.x + f, this.CENTER.y + f);
            Path path = new Path();
            this.magneticBackgroundPath = path;
            path.addArc(rectF, 315.0f, 85.0f);
        }
    }

    private void drawMagnetic(Canvas canvas) {
        float f = this.WIDTH * 0.407f;
        RectF rectF = new RectF(this.CENTER.x - f, this.CENTER.y - f, this.CENTER.x + f, this.CENTER.y + f);
        canvas.drawPath(this.magneticBackgroundPath, this.magneticBackgroundPaint);
        float min = Math.min(1.0f, this.magneticField / 160) * 85;
        this.magneticPath.reset();
        this.magneticPath.addArc(rectF, ((float) ConstantsKt.DEFAULT_ANIMATION_MS) - min, min);
        canvas.drawPath(this.magneticPath, this.magneticFieldPaint);
        drawText(canvas, 307.0f, ((int) this.magneticField) + this.mT, this.WIDTH * 0.4f, this.magneticTextPaint);
        drawTextInverted(canvas, 53.0f, this.magField, this.WIDTH * 0.414f, this.magneticTextPaint);
    }

    private void drawText(Canvas canvas, float f, String str, float f2, Paint paint) {
        canvas.save();
        double d = f;
        canvas.translate((((float) Math.cos(Math.toRadians(d))) * f2) + this.CENTER.x, (((float) Math.sin(Math.toRadians(d))) * f2) + this.CENTER.y);
        canvas.rotate(f + 90.0f);
        canvas.drawText(str, 0.0f, 0.0f, paint);
        canvas.restore();
    }

    private void drawTextInverted(Canvas canvas, float f, String str, float f2, Paint paint) {
        canvas.save();
        double d = f;
        canvas.translate((((float) Math.cos(Math.toRadians(d))) * f2) + this.CENTER.x, (((float) Math.sin(Math.toRadians(d))) * f2) + this.CENTER.y);
        canvas.rotate(f + 270.0f);
        canvas.drawText(str, 0.0f, 0.0f, paint);
        canvas.restore();
    }
}
