package calldial.be.loctracker.MagicBold;

import android.content.Context;
import android.content.SharedPreferences;

/* loaded from: classes.dex */
public class AppPrefrence {
    SharedPreferences appSharedPref;
    SharedPreferences.Editor prefEditor;
    final String USER_PREFS = "ADS USER PREFS";
    String InstallCount = "InstallCount";
    String Ads_On_Off = "ads_show_flag";
    String AM_FB_Priority = "AM_FB_Priority";
    String Splash_Priority = "Splash_Priority";
    String Back_cnt = "back_cnt";
    String front_cnt = "front_cnt";
    String Qureka_ADS = "Qureka_ADS";
    String BackPress_Priority = "BackPress_Priority";
    String AM_AppID = "AM_AppID";
    String AM_INTERTITIAL = "AM_INTERTITIAL";
    String AM_BETA = "AM_BETA";
    String AM_NATIVE_BIG_HOME = "AM_NATIVE_BIG_HOME";
    String AM_NATIVE_BANNER_HOME = "AM_NATIVE_BANNER_HOME";
    String AM_RECT_BIG_HOME = "AM_RECT_BIG_HOME";
    String AM_Rewarded_Video = "AM_Rewarded_Video";
    String CF = "CF";
    String CURL = "CURL";

    public AppPrefrence(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("ADS USER PREFS", 0);
        this.appSharedPref = sharedPreferences;
        this.prefEditor = sharedPreferences.edit();
    }

    public String getInstallCount() {
        return this.appSharedPref.getString(this.InstallCount, "F");
    }

    public void setInstallCount(String str) {
        this.prefEditor.putString(this.InstallCount, str).commit();
    }

    public String getCF() {
        return this.appSharedPref.getString(this.CF, "");
    }

    public void setCF(String str) {
        this.prefEditor.putString(this.CF, str).commit();
    }

    public String getCURL() {
        return this.appSharedPref.getString(this.CURL, "");
    }

    public void setCURL(String str) {
        this.prefEditor.putString(this.CURL, str).commit();
    }

    public String getAds_On_Off() {
        return this.appSharedPref.getString(this.Ads_On_Off, "");
    }

    public void setAds_On_Off(String str) {
        this.prefEditor.putString(this.Ads_On_Off, str).commit();
    }

    public String getAM_FB_Priority() {
        return this.appSharedPref.getString(this.AM_FB_Priority, "");
    }

    public void setAM_FB_Priority(String str) {
        this.prefEditor.putString(this.AM_FB_Priority, str).commit();
    }

    public String getSplash_Priority() {
        return this.appSharedPref.getString(this.Splash_Priority, "Inter");
    }

    public void setSplash_Priority(String str) {
        this.prefEditor.putString(this.Splash_Priority, str).commit();
    }

    public String getBackPress_Priority() {
        return this.appSharedPref.getString(this.BackPress_Priority, "Inter");
    }

    public void setBackPress_Priority(String str) {
        this.prefEditor.putString(this.BackPress_Priority, str).commit();
    }

    public int getBack_cnt() {
        return this.appSharedPref.getInt(this.Back_cnt, 2);
    }

    public void setBack_cnt(int i) {
        this.prefEditor.putInt(this.Back_cnt, i).commit();
    }

    public int getFront_cnt() {
        return this.appSharedPref.getInt(this.front_cnt, 1);
    }

    public void setFront_cnt(int i) {
        this.prefEditor.putInt(this.front_cnt, i).commit();
    }

    public String getAM_RECT_BIG_HOME() {
        return this.appSharedPref.getString(this.AM_RECT_BIG_HOME, "");
    }

    public void setAM_INTERTITIAL(String str) {
        this.prefEditor.putString(this.AM_INTERTITIAL, str).commit();
    }

    public String getAM_INTERTITIAL() {
        return this.appSharedPref.getString(this.AM_INTERTITIAL, "");
    }

    public String getAM_NATIVE_BANNER_HOME() {
        return this.appSharedPref.getString(this.AM_NATIVE_BANNER_HOME, "");
    }

    public void setAM_NATIVE_BANNER_HOME(String str) {
        this.prefEditor.putString(this.AM_NATIVE_BANNER_HOME, str).commit();
    }

    public String getAM_NATIVE_BIG_HOME() {
        return this.appSharedPref.getString(this.AM_NATIVE_BIG_HOME, "");
    }

    public String getAM_Rewarded_Video() {
        return this.appSharedPref.getString(this.AM_Rewarded_Video, "");
    }

    public void setAM_AppID(String str) {
        this.prefEditor.putString(this.AM_AppID, str).commit();
    }

    public String getAM_AppID() {
        return this.appSharedPref.getString(this.AM_AppID, "ca-app-pub-3940256099942544~3347511713");
    }

    public void setAM_Rewarded_Video(String str) {
        this.prefEditor.putString(this.AM_Rewarded_Video, str).commit();
    }

    public void setAM_RECT_BIG_HOME(String str) {
        this.prefEditor.putString(this.AM_RECT_BIG_HOME, str).commit();
    }

    public void setAM_NATIVE_BIG_HOME(String str) {
        this.prefEditor.putString(this.AM_NATIVE_BIG_HOME, str).commit();
    }

    public String getAM_BETA() {
        return this.appSharedPref.getString(this.AM_BETA, "");
    }

    public void setAM_BETA(String str) {
        this.prefEditor.putString(this.AM_BETA, str).commit();
    }

    public String getGenarateEventLog() {
        return this.appSharedPref.getString("GenarateEventLog", "");
    }

    public void setGenarateEventLog(String str) {
        this.prefEditor.putString("GenarateEventLog", str).commit();
    }

    public String getQureka_ADS() {
        return this.appSharedPref.getString(this.Qureka_ADS, "off");
    }

    public void setQureka_ADS(String str) {
        this.prefEditor.putString(this.Qureka_ADS, str).commit();
    }
}
