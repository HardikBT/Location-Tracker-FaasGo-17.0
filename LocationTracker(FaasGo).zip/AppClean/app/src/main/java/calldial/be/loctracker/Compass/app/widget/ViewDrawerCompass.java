package calldial.be.loctracker.Compass.app.widget;

import android.graphics.Canvas;

/* loaded from: classes.dex */
public interface ViewDrawerCompass<T> {
    void draw(Canvas canvas);

    void layout(int i, int i2);

    void update(T t);
}
