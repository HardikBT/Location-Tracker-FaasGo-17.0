package calldial.be.loctracker.MagicQG;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.browser.customtabs.CustomTabsIntent;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;

import com.github.infinitebanner.AbsBannerAdapter;
import com.github.infinitebanner.InfiniteBannerView;

import calldial.be.loctracker.MagicBold.AppPrefrence;
import calldial.be.loctracker.R;

/* loaded from: classes.dex */
public class QG {
    public static boolean qg_alternate = false;
    Context context;

    public QG(Context context) {
        this.context = context;
    }

    /* loaded from: classes.dex */
    public static class BannerAdapter extends AbsBannerAdapter {
        @Override // com.github.infinitebanner.AbsBannerAdapter
        public int getCount() {
            return 10;
        }

        @Override // com.github.infinitebanner.AbsBannerAdapter
        public View makeView(InfiniteBannerView infiniteBannerView) {
            ImageView imageView = new ImageView(infiniteBannerView.getContext());
            imageView.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            return imageView;
        }

        @Override // com.github.infinitebanner.AbsBannerAdapter
        public void bind(View view, int i) {
            if (i == 0) {
                ((ImageView) view).setImageResource(R.drawable.qg_autoscroll_banner_1);
            } else if (i == 1) {
                ((ImageView) view).setImageResource(R.drawable.qg_autoscroll_banner_2);
            } else if (i == 2) {
                ((ImageView) view).setImageResource(R.drawable.qg_autoscroll_banner_3);
            } else if (i == 3) {
                ((ImageView) view).setImageResource(R.drawable.qg_autoscroll_banner_4);
            } else if (i == 4) {
                ((ImageView) view).setImageResource(R.drawable.qg_autoscroll_banner_5);
            } else if (i == 5) {
                ((ImageView) view).setImageResource(R.drawable.qg_autoscroll_banner_6);
            } else if (i == 6) {
                ((ImageView) view).setImageResource(R.drawable.qg_autoscroll_banner_7);
            } else if (i == 7) {
                ((ImageView) view).setImageResource(R.drawable.qg_autoscroll_banner_8);
            } else {
                ((ImageView) view).setImageResource(R.drawable.qg_autoscroll_banner_1);
            }
        }
    }

    public static void openLink(Context context, String str) {
        Toast.makeText(context, "Opening... Please Wait", 0).show();
        CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
        builder.setToolbarColor(ContextCompat.getColor(context, R.color.qureka_tab_color));
        CustomTabsIntent build = builder.build();
        build.intent.setPackage("com.android.chrome");
        build.launchUrl(context, Uri.parse(str));
    }

    public static void openQuereka(Context context) {
        Toast.makeText(context, "Opening... Please Wait", 0).show();
        CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
        builder.setToolbarColor(ContextCompat.getColor(context, R.color.qureka_tab_color));
        CustomTabsIntent build = builder.build();
        build.intent.setPackage("com.android.chrome");
        build.launchUrl(context, Uri.parse("https://766.win.qureka.com"));
    }

    public static void openQGAlternate(Context context) {
        boolean z = qg_alternate;
        if (!z) {
            qg_alternate = !z;
            openQuereka(context);
            return;
        }
        qg_alternate = !z;
        openGamezop(context);
    }

    public static void openGamezop(Context context) {
        Toast.makeText(context, "Opening... Please wait", 0).show();
        CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
        builder.setToolbarColor(ContextCompat.getColor(context, R.color.qureka_tab_color));
        CustomTabsIntent build = builder.build();
        build.intent.setPackage("com.android.chrome");
        build.launchUrl(context, Uri.parse("https://www.quizzop.com/?id=3313"));
    }
}
