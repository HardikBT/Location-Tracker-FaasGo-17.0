package calldial.be.loctracker.Weather.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/* loaded from: classes.dex */
public class WindWeather {
    @SerializedName("deg")
    @Expose
    private float deg;
    @SerializedName("speed")
    @Expose
    private float speed;

    public float getSpeed() {
        return this.speed;
    }

    public void setSpeed(float f) {
        this.speed = f;
    }

    public float getDeg() {
        return this.deg;
    }

    public void setDeg(float f) {
        this.deg = f;
    }
}
