package calldial.be.loctracker;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.core.widget.NestedScrollView;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.appbar.AppBarLayout;

import calldial.be.loctracker.BatteryInfo.BatteryInfoActivity;
import calldial.be.loctracker.DeviceInfo.MobileDeviceInfoActivity;
import calldial.be.loctracker.MagicBold.AllAdsKeyPlace;
import calldial.be.loctracker.MagicBold.AppPrefrence;
import calldial.be.loctracker.MagicQG.QG;

/* loaded from: classes.dex */
public class MobileToolsActivity extends AppCompatActivity {
    public static boolean IS_DOWN = true;
    public static boolean IS_UP = true;
    AppBarLayout appbarlay_tool;
    ImageView btn_compass_map;
    ImageView btn_device_info;
    ImageView btn_live_weather;
    ImageView btn_system_usage_battery;
    Animation down_anim_toolbar;
    ImageView imgDrawerLines;
    LinearLayout iv_moreads;
    private DrawerLayout mDrawerLayout;
    NestedScrollView nested_scroll;
    Animation up_anim_toolbar;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_mobile_tools);
        AllAdsKeyPlace.ShowInterstitialAdsOnCreate(this);
        AllAdsKeyPlace.ShowNativeAd(this, (ViewGroup) findViewById(R.id.nativeContainer));
        this.iv_moreads = (LinearLayout) findViewById(R.id.iv_moreads);
        if (Common.isNetworkConnected(this) && new AppPrefrence(getApplicationContext()).getQureka_ADS().equalsIgnoreCase("on")) {
            this.iv_moreads.setVisibility(0);
        }
        this.iv_moreads.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.MobileToolsActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                QG.openQGAlternate(MobileToolsActivity.this);
            }
        });
        this.mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        ImageView imageView = (ImageView) findViewById(R.id.imgDrawerLines);
        this.imgDrawerLines = imageView;
        Common.Animation(imageView);
        this.imgDrawerLines.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.MobileToolsActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (MobileToolsActivity.this.mDrawerLayout.isDrawerOpen(3)) {
                    MobileToolsActivity.this.mDrawerLayout.closeDrawer(5);
                } else {
                    MobileToolsActivity.this.mDrawerLayout.openDrawer(3);
                }
            }
        });
        findViewById(R.id.llhomeapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.MobileToolsActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MobileToolsActivity.this.mDrawerLayout.closeDrawers();
                MobileToolsActivity.this.startActivity(new Intent(MobileToolsActivity.this, DashboardActivity.class));
            }
        });
        findViewById(R.id.llrateapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.MobileToolsActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MobileToolsActivity.this.mDrawerLayout.closeDrawers();
                Common.showRateDialog(MobileToolsActivity.this);
            }
        });
        findViewById(R.id.llshareapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.MobileToolsActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MobileToolsActivity.this.mDrawerLayout.closeDrawers();
                Common.ShareApp(MobileToolsActivity.this);
            }
        });
        findViewById(R.id.llpolicy__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.MobileToolsActivity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MobileToolsActivity.this.mDrawerLayout.closeDrawers();
                Common.showPrivacyDialog(MobileToolsActivity.this);
            }
        });
        findViewById(R.id.llmoreapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.MobileToolsActivity.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MobileToolsActivity.this.mDrawerLayout.closeDrawers();
                MobileToolsActivity.this.startActivity(new Intent(MobileToolsActivity.this, MoreAdActivity.class));
            }
        });
        this.btn_device_info = (ImageView) findViewById(R.id.btn_device_info);
        this.btn_system_usage_battery = (ImageView) findViewById(R.id.btn_system_usage_battery);
        Common.Animation(this.btn_device_info);
        Common.Animation(this.btn_system_usage_battery);
        this.appbarlay_tool = (AppBarLayout) findViewById(R.id.appbarlay_tool);
        this.nested_scroll = (NestedScrollView) findViewById(R.id.nested_scroll);
        this.down_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.down_anim_toolbar);
        this.up_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.up_anim_toolbar);
        NestedScrollView nestedScrollView = this.nested_scroll;
        if (nestedScrollView != null) {
            nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() { // from class: calldial.be.loctracker.MobileToolsActivity.8
                @Override // androidx.core.widget.NestedScrollView.OnScrollChangeListener
                public void onScrollChange(NestedScrollView nestedScrollView2, int i, int i2, int i3, int i4) {
                    if (i2 > i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling DOWN");
                        if (MobileToolsActivity.IS_UP) {
                            MobileToolsActivity.this.appbarlay_tool.startAnimation(MobileToolsActivity.this.up_anim_toolbar);
                            MobileToolsActivity.IS_UP = false;
                            MobileToolsActivity.IS_DOWN = true;
                        }
                    }
                    if (i2 < i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling UP");
                        if (MobileToolsActivity.IS_DOWN) {
                            MobileToolsActivity.this.appbarlay_tool.startAnimation(MobileToolsActivity.this.down_anim_toolbar);
                            MobileToolsActivity.IS_DOWN = false;
                            MobileToolsActivity.IS_UP = true;
                        }
                    }
                    if (i2 == 0) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to TOP SCROLL");
                    }
                    if (i2 == nestedScrollView2.getMeasuredHeight() - nestedScrollView2.getChildAt(0).getMeasuredHeight()) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to BOTTOM SCROLL");
                    }
                }
            });
        }
        this.btn_device_info.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.MobileToolsActivity.9
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MobileToolsActivity.this.startActivity(new Intent(MobileToolsActivity.this, MobileDeviceInfoActivity.class));
            }
        });
        this.btn_system_usage_battery.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.MobileToolsActivity.10
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MobileToolsActivity.this.startActivity(new Intent(MobileToolsActivity.this, BatteryInfoActivity.class));
            }
        });
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (this.mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            this.mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            AllAdsKeyPlace.CloseActivityWithAds(this, "true");
        }
    }
}
