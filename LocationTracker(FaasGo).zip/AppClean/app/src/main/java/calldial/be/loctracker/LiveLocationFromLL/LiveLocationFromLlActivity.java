package calldial.be.loctracker.LiveLocationFromLL;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.view.GravityCompat;
import androidx.core.widget.NestedScrollView;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.appbar.AppBarLayout;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import calldial.be.loctracker.Common;
import calldial.be.loctracker.DashboardActivity;
import calldial.be.loctracker.GoogleMap.LiveLocationMapActivity;
import calldial.be.loctracker.MagicBold.AllAdsKeyPlace;
import calldial.be.loctracker.MagicBold.AppPrefrence;
import calldial.be.loctracker.MagicQG.QG;
import calldial.be.loctracker.MoreAdActivity;
import calldial.be.loctracker.R;

/* loaded from: classes.dex */
public class LiveLocationFromLlActivity extends AppCompatActivity {
    public static boolean IS_DOWN = true;
    public static boolean IS_UP = true;
    private static final int REQUEST_LOCATION_CODE = 1;
    AppBarLayout appbarlay_tool;
    Animation down_anim_toolbar;
    ImageView imgDrawerLines;
    LinearLayout iv_moreads;
    String latitude;
    LinearLayout ll_live_location_google_map;
    LocationManager locationManager;
    String longitude;
    private DrawerLayout mDrawerLayout;
    NestedScrollView nested_scroll;
    TextView tv_address;
    TextView tv_latitude;
    TextView tv_longitude;
    Animation up_anim_toolbar;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_live_location_from_ll);
        AllAdsKeyPlace.ShowInterstitialAdsOnCreate(this);
        AllAdsKeyPlace.ShowNativeAd(this, (ViewGroup) findViewById(R.id.nativeContainer));
        this.iv_moreads = (LinearLayout) findViewById(R.id.iv_moreads);
        if (Common.isNetworkConnected(this) && new AppPrefrence(getApplicationContext()).getQureka_ADS().equalsIgnoreCase("on")) {
            this.iv_moreads.setVisibility(0);
        }
        this.iv_moreads.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LiveLocationFromLL.LiveLocationFromLlActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                QG.openQGAlternate(LiveLocationFromLlActivity.this);
            }
        });
        this.mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        ImageView imageView = (ImageView) findViewById(R.id.imgDrawerLines);
        this.imgDrawerLines = imageView;
        Common.Animation(imageView);
        this.imgDrawerLines.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LiveLocationFromLL.LiveLocationFromLlActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (LiveLocationFromLlActivity.this.mDrawerLayout.isDrawerOpen(3)) {
                    LiveLocationFromLlActivity.this.mDrawerLayout.closeDrawer(5);
                } else {
                    LiveLocationFromLlActivity.this.mDrawerLayout.openDrawer(3);
                }
            }
        });
        findViewById(R.id.llhomeapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LiveLocationFromLL.LiveLocationFromLlActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                LiveLocationFromLlActivity.this.mDrawerLayout.closeDrawers();
                LiveLocationFromLlActivity.this.startActivity(new Intent(LiveLocationFromLlActivity.this, DashboardActivity.class));
            }
        });
        findViewById(R.id.llrateapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LiveLocationFromLL.LiveLocationFromLlActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                LiveLocationFromLlActivity.this.mDrawerLayout.closeDrawers();
                Common.showRateDialog(LiveLocationFromLlActivity.this);
            }
        });
        findViewById(R.id.llshareapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LiveLocationFromLL.LiveLocationFromLlActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                LiveLocationFromLlActivity.this.mDrawerLayout.closeDrawers();
                Common.ShareApp(LiveLocationFromLlActivity.this);
            }
        });
        findViewById(R.id.llpolicy__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LiveLocationFromLL.LiveLocationFromLlActivity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                LiveLocationFromLlActivity.this.mDrawerLayout.closeDrawers();
                Common.showPrivacyDialog(LiveLocationFromLlActivity.this);
            }
        });
        findViewById(R.id.llmoreapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LiveLocationFromLL.LiveLocationFromLlActivity.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                LiveLocationFromLlActivity.this.mDrawerLayout.closeDrawers();
                LiveLocationFromLlActivity.this.startActivity(new Intent(LiveLocationFromLlActivity.this, MoreAdActivity.class));
            }
        });
        this.tv_latitude = (TextView) findViewById(R.id.tv_latitude);
        this.tv_longitude = (TextView) findViewById(R.id.tv_longitude);
        this.tv_address = (TextView) findViewById(R.id.tv_address);
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.ll_live_location_google_map);
        this.ll_live_location_google_map = linearLayout;
        Common.Animation((ViewGroup) linearLayout);
        getCurrentLocationFromLL();
        this.appbarlay_tool = (AppBarLayout) findViewById(R.id.appbarlay_tool);
        this.nested_scroll = (NestedScrollView) findViewById(R.id.nested_scroll);
        this.down_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.down_anim_toolbar);
        this.up_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.up_anim_toolbar);
        NestedScrollView nestedScrollView = this.nested_scroll;
        if (nestedScrollView != null) {
            nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() { // from class: calldial.be.loctracker.LiveLocationFromLL.LiveLocationFromLlActivity.8
                @Override // androidx.core.widget.NestedScrollView.OnScrollChangeListener
                public void onScrollChange(NestedScrollView nestedScrollView2, int i, int i2, int i3, int i4) {
                    if (i2 > i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling DOWN");
                        if (LiveLocationFromLlActivity.IS_UP) {
                            LiveLocationFromLlActivity.this.appbarlay_tool.startAnimation(LiveLocationFromLlActivity.this.up_anim_toolbar);
                            LiveLocationFromLlActivity.IS_UP = false;
                            LiveLocationFromLlActivity.IS_DOWN = true;
                        }
                    }
                    if (i2 < i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling UP");
                        if (LiveLocationFromLlActivity.IS_DOWN) {
                            LiveLocationFromLlActivity.this.appbarlay_tool.startAnimation(LiveLocationFromLlActivity.this.down_anim_toolbar);
                            LiveLocationFromLlActivity.IS_DOWN = false;
                            LiveLocationFromLlActivity.IS_UP = true;
                        }
                    }
                    if (i2 == 0) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to TOP SCROLL");
                    }
                    if (i2 == nestedScrollView2.getMeasuredHeight() - nestedScrollView2.getChildAt(0).getMeasuredHeight()) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to BOTTOM SCROLL");
                    }
                }
            });
        }
        this.ll_live_location_google_map.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LiveLocationFromLL.LiveLocationFromLlActivity.9
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Intent intent = new Intent(LiveLocationFromLlActivity.this, LiveLocationMapActivity.class);
                intent.putExtra("IS_TRAFFIC_ENABLED", false);
                LiveLocationFromLlActivity.this.startActivity(intent);
            }
        });
    }

    public void getCurrentLocationFromLL() {
        ActivityCompat.requestPermissions(this, new String[]{"android.permission.ACCESS_FINE_LOCATION"}, 1);
        LocationManager locationManager = (LocationManager) getSystemService("location");
        this.locationManager = locationManager;
        if (!locationManager.isProviderEnabled("gps")) {
            OnGPS();
            return;
        }
        try {
            getLocation();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void OnGPS() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Enable GPS to Access").setCancelable(false).setPositiveButton("Yes", new DialogInterface.OnClickListener() { // from class: calldial.be.loctracker.LiveLocationFromLL.LiveLocationFromLlActivity.11
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
                LiveLocationFromLlActivity.this.startActivity(new Intent("android.settings.LOCATION_SOURCE_SETTINGS"));
            }
        }).setNegativeButton("No", new DialogInterface.OnClickListener() { // from class: calldial.be.loctracker.LiveLocationFromLL.LiveLocationFromLlActivity.10
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        builder.create().show();
    }

    public void getLocation() throws IOException {
        if (ActivityCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0 || ActivityCompat.checkSelfPermission(this, "android.permission.ACCESS_COARSE_LOCATION") == 0) {
            for (String str : this.locationManager.getProviders(true)) {
                this.locationManager.requestLocationUpdates(str, 1000L, 0.0f, new LocationListener() { // from class: calldial.be.loctracker.LiveLocationFromLL.LiveLocationFromLlActivity.12
                    @Override // android.location.LocationListener
                    public void onLocationChanged(Location location) {
                    }

                    @Override // android.location.LocationListener
                    public void onProviderDisabled(String str2) {
                    }

                    @Override // android.location.LocationListener
                    public void onProviderEnabled(String str2) {
                    }

                    @Override // android.location.LocationListener
                    public void onStatusChanged(String str2, int i, Bundle bundle) {
                    }
                });
                Location lastKnownLocation = this.locationManager.getLastKnownLocation(str);
                if (lastKnownLocation != null) {
                    double latitude = lastKnownLocation.getLatitude();
                    double longitude = lastKnownLocation.getLongitude();
                    this.latitude = String.valueOf(latitude);
                    this.longitude = String.valueOf(longitude);
                    this.tv_latitude.setText(this.latitude);
                    this.tv_longitude.setText(this.longitude);
                    List<Address> fromLocation = new Geocoder(this, Locale.getDefault()).getFromLocation(latitude, longitude, 1);
                    String addressLine = fromLocation.get(0).getAddressLine(0);
                    fromLocation.get(0).getLocality();
                    fromLocation.get(0).getAdminArea();
                    fromLocation.get(0).getCountryName();
                    fromLocation.get(0).getPostalCode();
                    fromLocation.get(0).getFeatureName();
                    this.tv_address.setText(addressLine);
                } else {
                    Log.d("NOT_FOUND", "getLocation: Unable to find location.");
                }
            }
            return;
        }
        ActivityCompat.requestPermissions(this, new String[]{"android.permission.ACCESS_FINE_LOCATION"}, 1);
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i == 1) {
            if (iArr.length <= 0 || iArr[0] != 0) {
                Toast.makeText(this, "Please allow permission to access...", 0).show();
                return;
            }
            try {
                getLocation();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (this.mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            this.mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            AllAdsKeyPlace.CloseActivityWithAds(this, "true");
        }
    }
}
