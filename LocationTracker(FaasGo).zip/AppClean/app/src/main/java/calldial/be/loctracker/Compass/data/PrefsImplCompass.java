package calldial.be.loctracker.Compass.data;

import android.content.Context;
import android.content.SharedPreferences;

/* loaded from: classes.dex */
public class PrefsImplCompass implements PrefsCompass {
    private static final String PREF_KEY_ENERGY_SAVING_MODE = "is_energy_saving_mode";
    private static final String PREF_KEY_IS_FIRST_RUN = "is_first_run";
    private static final String PREF_KEY_KEEP_SCREEN_ON = "keep_screen_on";
    private static final String PREF_KEY_SHOW_ACCELERATION = "is_show_acceleration";
    private static final String PREF_KEY_SHOW_ACCURACY = "is_show_accuracy";
    private static final String PREF_KEY_SHOW_MAGNETIC = "is_show_magnetic";
    private static final String PREF_KEY_SHOW_ORIENTATION = "is_show_orientation";
    private static final String PREF_KEY_SIMPLE_MODE = "is_simple_mode";
    private static final String PREF_KEY_THEME_COLORMAP_POSITION = "theme_color";
    private static final String PREF_NAME = "com.dimowner.audiorecorder.data.PrefsImpl";
    private static volatile PrefsImplCompass instance;
    private SharedPreferences sharedPreferences;

    private PrefsImplCompass(Context context) {
        this.sharedPreferences = context.getSharedPreferences(PREF_NAME, 0);
    }

    public static PrefsImplCompass getInstance(Context context) {
        if (instance == null) {
            synchronized (PrefsImplCompass.class) {
                if (instance == null) {
                    instance = new PrefsImplCompass(context);
                }
            }
        }
        return instance;
    }

    @Override // calldial.be.loctracker.Compass.data.PrefsCompass
    public boolean isFirstRun() {
        return !this.sharedPreferences.contains(PREF_KEY_IS_FIRST_RUN) || this.sharedPreferences.getBoolean(PREF_KEY_IS_FIRST_RUN, false);
    }

    @Override // calldial.be.loctracker.Compass.data.PrefsCompass
    public void firstRunExecuted() {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.putBoolean(PREF_KEY_IS_FIRST_RUN, false);
        edit.apply();
    }

    @Override // calldial.be.loctracker.Compass.data.PrefsCompass
    public void setAppThemeColor(int i) {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.putInt(PREF_KEY_THEME_COLORMAP_POSITION, i);
        edit.apply();
    }

    @Override // calldial.be.loctracker.Compass.data.PrefsCompass
    public int getThemeColor() {
        return this.sharedPreferences.getInt(PREF_KEY_THEME_COLORMAP_POSITION, 0);
    }

    @Override // calldial.be.loctracker.Compass.data.PrefsCompass
    public void setKeepScreenOn(boolean z) {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.putBoolean(PREF_KEY_KEEP_SCREEN_ON, z);
        edit.apply();
    }

    @Override // calldial.be.loctracker.Compass.data.PrefsCompass
    public boolean isKeepScreenOn() {
        return this.sharedPreferences.getBoolean(PREF_KEY_KEEP_SCREEN_ON, false);
    }

    @Override // calldial.be.loctracker.Compass.data.PrefsCompass
    public void setSimpleMode(boolean z) {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.putBoolean(PREF_KEY_SIMPLE_MODE, z);
        edit.apply();
    }

    @Override // calldial.be.loctracker.Compass.data.PrefsCompass
    public boolean isSimpleMode() {
        return this.sharedPreferences.getBoolean(PREF_KEY_SIMPLE_MODE, false);
    }

    @Override // calldial.be.loctracker.Compass.data.PrefsCompass
    public void setEnergySavingMode(boolean z) {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.putBoolean(PREF_KEY_ENERGY_SAVING_MODE, z);
        edit.apply();
    }

    @Override // calldial.be.loctracker.Compass.data.PrefsCompass
    public boolean isEnergySavingMode() {
        return this.sharedPreferences.getBoolean(PREF_KEY_ENERGY_SAVING_MODE, false);
    }

    @Override // calldial.be.loctracker.Compass.data.PrefsCompass
    public void setShowAcceleration(boolean z) {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.putBoolean(PREF_KEY_SHOW_ACCELERATION, z);
        edit.apply();
    }

    @Override // calldial.be.loctracker.Compass.data.PrefsCompass
    public boolean isShowAcceleration() {
        return this.sharedPreferences.getBoolean(PREF_KEY_SHOW_ACCELERATION, true);
    }

    @Override // calldial.be.loctracker.Compass.data.PrefsCompass
    public void setShowOrientation(boolean z) {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.putBoolean(PREF_KEY_SHOW_ORIENTATION, z);
        edit.apply();
    }

    @Override // calldial.be.loctracker.Compass.data.PrefsCompass
    public boolean isShowOrientation() {
        return this.sharedPreferences.getBoolean(PREF_KEY_SHOW_ORIENTATION, true);
    }

    @Override // calldial.be.loctracker.Compass.data.PrefsCompass
    public void setShowAccuracy(boolean z) {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.putBoolean(PREF_KEY_SHOW_ACCURACY, z);
        edit.apply();
    }

    @Override // calldial.be.loctracker.Compass.data.PrefsCompass
    public boolean isShowAccuracy() {
        return this.sharedPreferences.getBoolean(PREF_KEY_SHOW_ACCURACY, true);
    }

    @Override // calldial.be.loctracker.Compass.data.PrefsCompass
    public void setShowMagnetic(boolean z) {
        SharedPreferences.Editor edit = this.sharedPreferences.edit();
        edit.putBoolean(PREF_KEY_SHOW_MAGNETIC, z);
        edit.apply();
    }

    @Override // calldial.be.loctracker.Compass.data.PrefsCompass
    public boolean isShowMagnetic() {
        return this.sharedPreferences.getBoolean(PREF_KEY_SHOW_MAGNETIC, true);
    }
}
