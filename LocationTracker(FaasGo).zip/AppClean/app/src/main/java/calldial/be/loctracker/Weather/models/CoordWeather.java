package calldial.be.loctracker.Weather.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/* loaded from: classes.dex */
public class CoordWeather {
    @SerializedName("lat")
    @Expose
    private float lat;
    @SerializedName("lon")
    @Expose
    private float lon;

    public float getLat() {
        return this.lat;
    }

    public void setLat(float f) {
        this.lat = f;
    }

    public float getLon() {
        return this.lon;
    }

    public void setLon(float f) {
        this.lon = f;
    }
}
