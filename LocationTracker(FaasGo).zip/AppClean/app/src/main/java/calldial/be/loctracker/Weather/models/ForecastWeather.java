package calldial.be.loctracker.Weather.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/* loaded from: classes.dex */
public class ForecastWeather {
    @SerializedName("city")
    @Expose
    private CityWeather city;
    @SerializedName("cnt")
    @Expose
    private int cnt;
    @SerializedName("cod")
    @Expose
    private String cod;
    @SerializedName("list")
    @Expose
    private List<DataObjectWeather> dataObject = null;
    @SerializedName("message")
    @Expose
    private float message;

    public String getCod() {
        return this.cod;
    }

    public void setCod(String str) {
        this.cod = str;
    }

    public float getMessage() {
        return this.message;
    }

    public void setMessage(float f) {
        this.message = f;
    }

    public int getCnt() {
        return this.cnt;
    }

    public void setCnt(int i) {
        this.cnt = i;
    }

    public List<DataObjectWeather> getDataObjectList() {
        return this.dataObject;
    }

    public void setDataObject(List<DataObjectWeather> list) {
        this.dataObject = list;
    }

    public CityWeather getCity() {
        return this.city;
    }

    public void setCity(CityWeather cityWeather) {
        this.city = cityWeather;
    }
}
