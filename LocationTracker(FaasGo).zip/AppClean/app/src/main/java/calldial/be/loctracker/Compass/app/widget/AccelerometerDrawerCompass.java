package calldial.be.loctracker.Compass.app.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.PointF;
import android.util.TypedValue;

import calldial.be.loctracker.R;

/* loaded from: classes.dex */
public class AccelerometerDrawerCompass implements ViewDrawerCompass<PointF> {
    private Point CENTER;
    private int RADIUS;
    private Paint ballPaint;
    private boolean isSimple;
    private Path path;
    private Paint pathPaint;
    private float xPos;
    private float yPos;

    public AccelerometerDrawerCompass(Context context, boolean z) {
        int i;
        int i2;
        this.isSimple = z;
        TypedValue typedValue = new TypedValue();
        Resources.Theme theme = context.getTheme();
        if (theme.resolveAttribute(R.attr.accelerometerGridColor, typedValue, true)) {
            i = typedValue.data;
        } else {
            i = context.getResources().getColor(R.color.md_white_1000);
        }
        if (theme.resolveAttribute(R.attr.accelerometerBallColor, typedValue, true)) {
            i2 = typedValue.data;
        } else {
            i2 = context.getResources().getColor(R.color.md_white_1000);
        }
        Paint paint = new Paint(1);
        this.pathPaint = paint;
        paint.setStrokeWidth(1.0f);
        this.pathPaint.setStyle(Paint.Style.STROKE);
        this.pathPaint.setColor(i);
        Paint paint2 = new Paint(1);
        this.ballPaint = paint2;
        paint2.setStyle(Paint.Style.FILL);
        this.ballPaint.setColor(i2);
        this.CENTER = new Point(0, 0);
    }

    @Override // calldial.be.loctracker.Compass.app.widget.ViewDrawerCompass
    public void layout(int i, int i2) {
        this.RADIUS = i / 8;
        this.CENTER.set(i / 2, i2 / 2);
        if (this.path == null) {
            float f = i;
            float f2 = (f / 2.0f) - (f * 0.03f);
            Path path = new Path();
            this.path = path;
            path.moveTo(this.CENTER.x - f2, this.CENTER.y);
            this.path.lineTo(this.CENTER.x + f2, this.CENTER.y);
            this.path.moveTo(this.CENTER.x, this.CENTER.y - f2);
            this.path.lineTo(this.CENTER.x, this.CENTER.y + f2);
            if (!this.isSimple) {
                this.path.addCircle(this.CENTER.x, this.CENTER.y, f2, Path.Direction.CCW);
            }
        }
    }

    @Override // calldial.be.loctracker.Compass.app.widget.ViewDrawerCompass
    public void draw(Canvas canvas) {
        canvas.drawPath(this.path, this.pathPaint);
        canvas.drawCircle(this.CENTER.x - this.xPos, this.CENTER.y + this.yPos, this.RADIUS, this.ballPaint);
    }

    public void update(PointF pointF) {
        this.xPos = pointF.x;
        this.yPos = pointF.y;
    }
}
