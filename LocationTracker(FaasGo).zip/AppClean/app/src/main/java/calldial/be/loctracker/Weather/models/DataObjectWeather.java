package calldial.be.loctracker.Weather.models;

import androidx.core.app.NotificationCompat;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/* loaded from: classes.dex */
public class DataObjectWeather {
    @SerializedName("clouds")
    @Expose
    private CloudsWeather clouds;
    @SerializedName("dt")
    @Expose
    private int dt;
    @SerializedName("dt_txt")
    @Expose
    private String dtTxt;
    @SerializedName("main")
    @Expose
    private MainWeather main;
    @SerializedName(NotificationCompat.CATEGORY_SYSTEM)
    @Expose
    private SysWeather sys;
    @SerializedName("weather")
    @Expose
    private List<WeatherWeather> weather = null;
    @SerializedName("wind")
    @Expose
    private WindWeather wind;

    public long getDt() {
        return this.dt;
    }

    public void setDt(int i) {
        this.dt = i;
    }

    public MainWeather getMain() {
        return this.main;
    }

    public void setMain(MainWeather mainWeather) {
        this.main = mainWeather;
    }

    public List<WeatherWeather> getWeather() {
        return this.weather;
    }

    public void setWeather(List<WeatherWeather> list) {
        this.weather = list;
    }

    public CloudsWeather getClouds() {
        return this.clouds;
    }

    public void setClouds(CloudsWeather cloudsWeather) {
        this.clouds = cloudsWeather;
    }

    public WindWeather getWind() {
        return this.wind;
    }

    public void setWind(WindWeather windWeather) {
        this.wind = windWeather;
    }

    public SysWeather getSys() {
        return this.sys;
    }

    public void setSys(SysWeather sysWeather) {
        this.sys = sysWeather;
    }

    public String getDtTxt() {
        return this.dtTxt;
    }

    public void setDtTxt(String str) {
        this.dtTxt = str;
    }
}
