package calldial.be.loctracker.Compass.app.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.TypedValue;

import calldial.be.loctracker.Compass.util.AndroidUtilsCompass;
import calldial.be.loctracker.R;

/* loaded from: classes.dex */
public class AccuracyDrawerCompass implements ViewDrawerCompass<Integer> {
    public static final float ACCURACY_NAME_RADIUS = 0.414f;
    public static final float ACCURACY_VAL_RADIUS = 0.4f;
    public static final float ACCURACY_VIEW_RADIUS = 0.407f;
    private Point CENTER;
    private float WIDTH;
    private String accHigh;
    private String accLow;
    private String accMedium;
    private String accName;
    private String accUnreliable;
    private String accValue;
    private Paint accuracyBackgroundPaint;
    private Paint accuracyFieldPaint;
    private Paint accuracyTextPaint;
    private Path accuracyPath = null;
    private Path accuracyBackgroundPath = null;
    private int accuracy = 0;

    public AccuracyDrawerCompass(Context context) {
        int i;
        int i2;
        int i3;
        Typeface create = Typeface.create("sans-serif-light", 0);
        Resources resources = context.getResources();
        this.accName = resources.getString(R.string.accuracy);
        this.accValue = resources.getString(R.string.accuracy_unreliable);
        this.accLow = context.getResources().getString(R.string.accuracy_low);
        this.accMedium = context.getResources().getString(R.string.accuracy_medium);
        this.accHigh = context.getResources().getString(R.string.accuracy_high);
        this.accUnreliable = context.getResources().getString(R.string.accuracy_unreliable);
        TypedValue typedValue = new TypedValue();
        Resources.Theme theme = context.getTheme();
        if (theme.resolveAttribute(R.attr.indicatorBackgroundColor, typedValue, true)) {
            i = typedValue.data;
        } else {
            i = resources.getColor(R.color.md_indigo_800x);
        }
        if (theme.resolveAttribute(R.attr.indicatorTextColor, typedValue, true)) {
            i2 = typedValue.data;
        } else {
            i2 = resources.getColor(R.color.md_indigo_100);
        }
        if (theme.resolveAttribute(R.attr.indicatorFieldColor, typedValue, true)) {
            i3 = typedValue.data;
        } else {
            i3 = resources.getColor(R.color.md_green_400);
        }
        this.CENTER = new Point(0, 0);
        Paint paint = new Paint(1);
        this.accuracyBackgroundPaint = paint;
        paint.setStyle(Paint.Style.STROKE);
        this.accuracyBackgroundPaint.setStrokeCap(Paint.Cap.ROUND);
        this.accuracyBackgroundPaint.setStrokeWidth(AndroidUtilsCompass.dpToPx(6));
        this.accuracyBackgroundPaint.setColor(i);
        Paint paint2 = new Paint(1);
        this.accuracyTextPaint = paint2;
        paint2.setColor(i2);
        this.accuracyTextPaint.setTextSize(AndroidUtilsCompass.dpToPx(10));
        this.accuracyTextPaint.setTypeface(create);
        this.accuracyTextPaint.setTextAlign(Paint.Align.CENTER);
        Paint paint3 = new Paint(1);
        this.accuracyFieldPaint = paint3;
        paint3.setColor(i3);
        this.accuracyFieldPaint.setStrokeWidth(AndroidUtilsCompass.dpToPx(6));
        this.accuracyFieldPaint.setStyle(Paint.Style.STROKE);
        this.accuracyFieldPaint.setStrokeCap(Paint.Cap.ROUND);
    }

    @Override // calldial.be.loctracker.Compass.app.widget.ViewDrawerCompass
    public void layout(int i, int i2) {
        initConstants(i, i2);
        layoutAccuracy();
    }

    @Override // calldial.be.loctracker.Compass.app.widget.ViewDrawerCompass
    public void draw(Canvas canvas) {
        drawAccuracy(canvas);
    }

    public void update(Integer num) {
        if (this.accuracy != num.intValue()) {
            int intValue = num.intValue();
            this.accuracy = intValue;
            if (intValue == 1) {
                this.accValue = this.accLow;
            } else if (intValue == 2) {
                this.accValue = this.accMedium;
            } else if (intValue != 3) {
                this.accValue = this.accUnreliable;
            } else {
                this.accValue = this.accHigh;
            }
        }
    }

    private void initConstants(int i, int i2) {
        float f = i;
        this.WIDTH = f;
        this.CENTER.set(((int) f) / 2, i2 / 2);
    }

    private void layoutAccuracy() {
        if (this.accuracyBackgroundPath == null) {
            float f = this.WIDTH * 0.407f;
            RectF rectF = new RectF(this.CENTER.x - f, this.CENTER.y - f, this.CENTER.x + f, this.CENTER.y + f);
            Path path = new Path();
            this.accuracyBackgroundPath = path;
            path.addArc(rectF, 155.0f, 45.0f);
        }
        if (this.accuracyPath == null) {
            this.accuracyPath = new Path();
        }
    }

    private void drawAccuracy(Canvas canvas) {
        float f = this.WIDTH * 0.407f;
        RectF rectF = new RectF(this.CENTER.x - f, this.CENTER.y - f, this.CENTER.x + f, this.CENTER.y + f);
        canvas.drawPath(this.accuracyBackgroundPath, this.accuracyBackgroundPaint);
        float min = Math.min(1.0f, (this.accuracy * 20) / 60) * 45;
        this.accuracyPath.reset();
        this.accuracyPath.addArc(rectF, 155.0f, min);
        canvas.drawPath(this.accuracyPath, this.accuracyFieldPaint);
        drawTextInverted(canvas, 143.0f, this.accName, this.WIDTH * 0.414f, this.accuracyTextPaint);
        drawText(canvas, 2010.0f, this.accValue, this.WIDTH * 0.4f, this.accuracyTextPaint);
    }

    private void drawText(Canvas canvas, float f, String str, float f2, Paint paint) {
        canvas.save();
        double d = f;
        canvas.translate((((float) Math.cos(Math.toRadians(d))) * f2) + this.CENTER.x, (((float) Math.sin(Math.toRadians(d))) * f2) + this.CENTER.y);
        canvas.rotate(f + 90.0f);
        canvas.drawText(str, 0.0f, 0.0f, paint);
        canvas.restore();
    }

    private void drawTextInverted(Canvas canvas, float f, String str, float f2, Paint paint) {
        canvas.save();
        double d = f;
        canvas.translate((((float) Math.cos(Math.toRadians(d))) * f2) + this.CENTER.x, (((float) Math.sin(Math.toRadians(d))) * f2) + this.CENTER.y);
        canvas.rotate(f + 270.0f);
        canvas.drawText(str, 0.0f, 0.0f, paint);
        canvas.restore();
    }
}
