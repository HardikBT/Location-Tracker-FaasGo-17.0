package calldial.be.loctracker.DeviceInfo;

import android.content.Intent;
import android.hardware.Camera;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.core.widget.NestedScrollView;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.appbar.AppBarLayout;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import calldial.be.loctracker.Common;
import calldial.be.loctracker.DashboardActivity;
import calldial.be.loctracker.MagicBold.AllAdsKeyPlace;
import calldial.be.loctracker.MagicBold.AppPrefrence;
import calldial.be.loctracker.MagicQG.QG;
import calldial.be.loctracker.MoreAdActivity;
import calldial.be.loctracker.R;

/* loaded from: classes.dex */
public class MobileDeviceInfoActivity extends AppCompatActivity {
    public static boolean IS_DOWN = true;
    public static boolean IS_UP = true;
    public static final int PERMISSION_CAMERA = 40;
    AppBarLayout appbarlay_tool;
    Animation down_anim_toolbar;
    ImageView imgDrawerLines;
    LinearLayout iv_moreads;
    private DrawerLayout mDrawerLayout;
    NestedScrollView nested_scroll;
    TextView tv_android_version;
    TextView tv_api_level;
    TextView tv_back_camera;
    TextView tv_brand_name;
    TextView tv_build_id;
    TextView tv_device_name;
    TextView tv_front_camera;
    TextView tv_hardware;
    TextView tv_host;
    TextView tv_instruction_set;
    TextView tv_model_name;
    TextView tv_os_version;
    TextView tv_physical_size;
    TextView tv_product_code;
    TextView tv_refresh_rate;
    TextView tv_resolution;
    TextView tv_screen_density;
    Animation up_anim_toolbar;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_mobile_device_info);
        AllAdsKeyPlace.ShowInterstitialAdsOnCreate(this);
        AllAdsKeyPlace.ShowNativeAd(this, (ViewGroup) findViewById(R.id.nativeContainer));
        this.iv_moreads = (LinearLayout) findViewById(R.id.iv_moreads);
        if (Common.isNetworkConnected(this) && new AppPrefrence(getApplicationContext()).getQureka_ADS().equalsIgnoreCase("on")) {
            this.iv_moreads.setVisibility(0);
        }
        this.iv_moreads.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.DeviceInfo.MobileDeviceInfoActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                QG.openQGAlternate(MobileDeviceInfoActivity.this);
            }
        });
        this.mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        ImageView imageView = (ImageView) findViewById(R.id.imgDrawerLines);
        this.imgDrawerLines = imageView;
        Common.Animation(imageView);
        this.imgDrawerLines.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.DeviceInfo.MobileDeviceInfoActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (MobileDeviceInfoActivity.this.mDrawerLayout.isDrawerOpen(3)) {
                    MobileDeviceInfoActivity.this.mDrawerLayout.closeDrawer(5);
                } else {
                    MobileDeviceInfoActivity.this.mDrawerLayout.openDrawer(3);
                }
            }
        });
        findViewById(R.id.llhomeapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.DeviceInfo.MobileDeviceInfoActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MobileDeviceInfoActivity.this.mDrawerLayout.closeDrawers();
                MobileDeviceInfoActivity.this.startActivity(new Intent(MobileDeviceInfoActivity.this, DashboardActivity.class));
            }
        });
        findViewById(R.id.llrateapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.DeviceInfo.MobileDeviceInfoActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MobileDeviceInfoActivity.this.mDrawerLayout.closeDrawers();
                Common.showRateDialog(MobileDeviceInfoActivity.this);
            }
        });
        findViewById(R.id.llshareapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.DeviceInfo.MobileDeviceInfoActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MobileDeviceInfoActivity.this.mDrawerLayout.closeDrawers();
                Common.ShareApp(MobileDeviceInfoActivity.this);
            }
        });
        findViewById(R.id.llpolicy__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.DeviceInfo.MobileDeviceInfoActivity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MobileDeviceInfoActivity.this.mDrawerLayout.closeDrawers();
                Common.showPrivacyDialog(MobileDeviceInfoActivity.this);
            }
        });
        findViewById(R.id.llmoreapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.DeviceInfo.MobileDeviceInfoActivity.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MobileDeviceInfoActivity.this.mDrawerLayout.closeDrawers();
                MobileDeviceInfoActivity.this.startActivity(new Intent(MobileDeviceInfoActivity.this, MoreAdActivity.class));
            }
        });
        this.tv_device_name = (TextView) findViewById(R.id.tv_device_name);
        this.tv_model_name = (TextView) findViewById(R.id.tv_model_name);
        this.tv_brand_name = (TextView) findViewById(R.id.tv_brand_name);
        this.tv_product_code = (TextView) findViewById(R.id.tv_product_code);
        this.tv_resolution = (TextView) findViewById(R.id.tv_resolution);
        this.tv_screen_density = (TextView) findViewById(R.id.tv_screen_density);
        this.tv_refresh_rate = (TextView) findViewById(R.id.tv_refresh_rate);
        this.tv_physical_size = (TextView) findViewById(R.id.tv_physical_size);
        this.tv_front_camera = (TextView) findViewById(R.id.tv_front_camera);
        this.tv_back_camera = (TextView) findViewById(R.id.tv_back_camera);
        this.tv_android_version = (TextView) findViewById(R.id.tv_android_version);
        this.tv_api_level = (TextView) findViewById(R.id.tv_api_level);
        this.tv_os_version = (TextView) findViewById(R.id.tv_os_version);
        this.tv_instruction_set = (TextView) findViewById(R.id.tv_instruction_set);
        this.tv_hardware = (TextView) findViewById(R.id.tv_hardware);
        this.tv_host = (TextView) findViewById(R.id.tv_host);
        this.tv_build_id = (TextView) findViewById(R.id.tv_build_id);
        getDeviceInfo();
        getScreenInfo();
        getCameraMegapixels();
        this.appbarlay_tool = (AppBarLayout) findViewById(R.id.appbarlay_tool);
        this.nested_scroll = (NestedScrollView) findViewById(R.id.nested_scroll);
        this.down_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.down_anim_toolbar);
        this.up_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.up_anim_toolbar);
        NestedScrollView nestedScrollView = this.nested_scroll;
        if (nestedScrollView != null) {
            nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() { // from class: calldial.be.loctracker.DeviceInfo.MobileDeviceInfoActivity.8
                @Override // androidx.core.widget.NestedScrollView.OnScrollChangeListener
                public void onScrollChange(NestedScrollView nestedScrollView2, int i, int i2, int i3, int i4) {
                    if (i2 > i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling DOWN");
                        if (MobileDeviceInfoActivity.IS_UP) {
                            MobileDeviceInfoActivity.this.appbarlay_tool.startAnimation(MobileDeviceInfoActivity.this.up_anim_toolbar);
                            MobileDeviceInfoActivity.IS_UP = false;
                            MobileDeviceInfoActivity.IS_DOWN = true;
                        }
                    }
                    if (i2 < i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling UP");
                        if (MobileDeviceInfoActivity.IS_DOWN) {
                            MobileDeviceInfoActivity.this.appbarlay_tool.startAnimation(MobileDeviceInfoActivity.this.down_anim_toolbar);
                            MobileDeviceInfoActivity.IS_DOWN = false;
                            MobileDeviceInfoActivity.IS_UP = true;
                        }
                    }
                    if (i2 == 0) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to TOP SCROLL");
                    }
                    if (i2 == nestedScrollView2.getMeasuredHeight() - nestedScrollView2.getChildAt(0).getMeasuredHeight()) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to BOTTOM SCROLL");
                    }
                }
            });
        }
    }

    public void getDeviceInfo() {
        try {
            String str = Build.MODEL;
            String str2 = Build.BRAND;
            String str3 = Build.PRODUCT;
            this.tv_device_name.setText(Build.BRAND + " " + Build.DEVICE);
            this.tv_model_name.setText(str);
            this.tv_brand_name.setText(str2);
            this.tv_product_code.setText(str3);
            String str4 = Build.VERSION.RELEASE;
            String valueOf = String.valueOf(Build.VERSION.SDK_INT);
            this.tv_android_version.setText(str4);
            this.tv_api_level.setText(valueOf);
            this.tv_os_version.setText(System.getProperty("os.version") + " (" + Build.VERSION.INCREMENTAL + ")");
            String str5 = Build.CPU_ABI;
            String str6 = Build.HARDWARE;
            String str7 = Build.HOST;
            String str8 = Build.ID;
            this.tv_instruction_set.setText(str5);
            this.tv_hardware.setText(str6);
            this.tv_host.setText(str7);
            this.tv_build_id.setText(str8);
        } catch (Exception unused) {
            Log.d("ERROR", "Error getting Device INFO");
        }
    }

    public void getScreenInfo() {
        String screenResolution = getScreenResolution();
        String screenDensity = getScreenDensity();
        String screenRefreshRate = getScreenRefreshRate();
        String screenPhysicalSize = getScreenPhysicalSize();
        this.tv_resolution.setText(screenResolution);
        this.tv_screen_density.setText(screenDensity);
        this.tv_refresh_rate.setText(screenRefreshRate);
        this.tv_physical_size.setText(screenPhysicalSize);
    }

    public String getScreenResolution() {
        Display defaultDisplay = ((WindowManager) getApplicationContext().getSystemService("window")).getDefaultDisplay();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        defaultDisplay.getMetrics(displayMetrics);
        int i = displayMetrics.widthPixels;
        int i2 = displayMetrics.heightPixels;
        return i + "w * " + i2 + "h";
    }

    public String getScreenDensity() {
        String str;
        double d = getResources().getDisplayMetrics().density;
        String str2 = "unknown";
        if (d == 0.75d) {
            str2 = "100 DPI";
            str = "Low";
        } else if (d == 1.0d) {
            str2 = "160 DPI";
            str = "Medium";
        } else if (d == 1.5d) {
            str2 = "240 DPI";
            str = "High";
        } else if (d == 2.0d) {
            str2 = "320 DPI";
            str = "X High";
        } else if (d == 3.0d) {
            str2 = "480 DPI";
            str = "XX High";
        } else if (d == 4.0d) {
            str2 = "640 DPI";
            str = "XXX High";
        } else {
            str = str2;
        }
        return str2 + " (" + str + ")";
    }

    public String getScreenRefreshRate() {
        Display defaultDisplay = ((WindowManager) getSystemService("window")).getDefaultDisplay();
        return String.valueOf(defaultDisplay.getRefreshRate()) + " Hz";
    }

    public String getScreenPhysicalSize() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        double sqrt = Math.sqrt(Math.pow(displayMetrics.widthPixels / displayMetrics.xdpi, 2.0d) + Math.pow(displayMetrics.heightPixels / displayMetrics.ydpi, 2.0d));
        DecimalFormat decimalFormat = new DecimalFormat("##.00");
        double parseDouble = Double.parseDouble(decimalFormat.format(sqrt));
        double parseDouble2 = Double.parseDouble(decimalFormat.format(2.54d * parseDouble));
        return (parseDouble + "\"") + " (" + (parseDouble2 + " cm") + ")";
    }

    public void getCameraMegapixels() {
        if (ContextCompat.checkSelfPermission(this, "android.permission.CAMERA") != 0) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.CAMERA"}, 40);
        }
        if (ContextCompat.checkSelfPermission(this, "android.permission.CAMERA") == 0) {
            Camera open = Camera.open(0);
            List<Camera.Size> supportedPictureSizes = open.getParameters().getSupportedPictureSizes();
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            for (int i = 0; i < supportedPictureSizes.size(); i++) {
                Camera.Size size = supportedPictureSizes.get(i);
                arrayList.add(Integer.valueOf(size.width));
                arrayList2.add(Integer.valueOf(size.height));
            }
            String str = "";
            String str2 = (arrayList.size() == 0 || arrayList2.size() == 0) ? str : ((((Integer) Collections.max(arrayList)).intValue() * ((Integer) Collections.max(arrayList2)).intValue()) / 1024000) + " Megapixel";
            open.release();
            arrayList.clear();
            arrayList2.clear();
            Camera open2 = Camera.open(1);
            List<Camera.Size> supportedPictureSizes2 = open2.getParameters().getSupportedPictureSizes();
            for (int i2 = 0; i2 < supportedPictureSizes2.size(); i2++) {
                Camera.Size size2 = supportedPictureSizes2.get(i2);
                arrayList.add(Integer.valueOf(size2.width));
                arrayList2.add(Integer.valueOf(size2.height));
            }
            if (!(arrayList.size() == 0 || arrayList2.size() == 0)) {
                str = ((((Integer) Collections.max(arrayList)).intValue() * ((Integer) Collections.max(arrayList2)).intValue()) / 1024000) + " Megapixel";
            }
            open2.release();
            this.tv_front_camera.setText(str);
            this.tv_back_camera.setText(str2);
        }
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i == 40) {
            if (iArr.length <= 0 || iArr[0] != 0) {
                Toast.makeText(this, "Please allow permission to access", 0).show();
            } else {
                getCameraMegapixels();
            }
        }
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (this.mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            this.mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            AllAdsKeyPlace.CloseActivityWithAds(this, "true");
        }
    }
}
