package calldial.be.loctracker.MagicQG;

import android.app.Activity;
import android.app.Dialog;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.browser.customtabs.CustomTabsIntent;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import java.util.Random;
import java.util.concurrent.TimeUnit;

import calldial.be.loctracker.MagicBold.AllAdsKeyPlace;
import calldial.be.loctracker.MagicBold.AppPrefrence;
import calldial.be.loctracker.MagicBold.onInterstitialAdsClose;
import calldial.be.loctracker.R;
import pl.droidsonroids.gif.GifImageView;

/* loaded from: classes.dex */
public class AdsQurekaDialog extends Dialog {
    static int uniqNo;
    static int uniqNoRes;
    CardView ImgClose;
    TextView ad_advertiser;
    AppPrefrence appPrefrence;
    ImageView banner;
    TextView bodytxt;
    CardView cardViewBg;
    Activity context;
    GifImageView gifImageView;
    TextView header;
    boolean layoutRandom = new Random().nextBoolean();
    onInterstitialAdsClose onInterstitialAdsClose;
    Button playgame;
    ProgressBar progressBarCircle;
    RelativeLayout rlClose;
    TextView tvTimer;

    public AdsQurekaDialog(Activity activity, onInterstitialAdsClose oninterstitialadsclose) {
        super(activity, R.style.qg_fulldialog);
        this.context = activity;
        uniqNo = new Random().nextInt(14);
        uniqNoRes = new Random().nextInt(2);
        this.onInterstitialAdsClose = oninterstitialadsclose;
    }

    @Override // android.app.Dialog
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setCancelable(false);
        String[] stringArray = this.context.getResources().getStringArray(R.array.header);
        String[] stringArray2 = this.context.getResources().getStringArray(R.array.body);
        int[] iArr = {R.drawable.qg_1_gif, R.drawable.qg_2_gif, R.drawable.qg_3_gif};
        this.appPrefrence = new AppPrefrence(this.context);
        if (this.layoutRandom) {
            setContentView(R.layout.qg_inter_one);
        } else {
            setContentView(R.layout.qg_inter_two);
        }
        this.ad_advertiser = (TextView) findViewById(R.id.ad_advertiser);
        this.ImgClose = (CardView) findViewById(R.id.dismiss);
        this.tvTimer = (TextView) findViewById(R.id.tv_timer);
        this.progressBarCircle = (ProgressBar) findViewById(R.id.progressBarCircle);
        this.rlClose = (RelativeLayout) findViewById(R.id.rlClose);
        this.gifImageView = (GifImageView) findViewById(R.id.gifImageView);
        this.header = (TextView) findViewById(R.id.header);
        this.bodytxt = (TextView) findViewById(R.id.body_txt);
        this.playgame = (Button) findViewById(R.id.playgame);
        this.ad_advertiser.setBackgroundResource(R.drawable.qg_sdk_ads_new_rounded_corners_shape);
        this.header.setText(stringArray[uniqNo]);
        this.bodytxt.setText(stringArray2[uniqNo]);
        this.gifImageView.setImageResource(iArr[uniqNoRes]);
        this.ImgClose.setOnClickListener(new SingleClickListener() { // from class: calldial.be.loctracker.MagicQG.AdsQurekaDialog.1
            @Override // calldial.be.loctracker.MagicQG.SingleClickListener
            public void performClick(View view) {
                AdsQurekaDialog.this.dismiss();
            }
        });
        this.playgame.setOnClickListener(new SingleClickListener() { // from class: calldial.be.loctracker.MagicQG.AdsQurekaDialog.2
            @Override // calldial.be.loctracker.MagicQG.SingleClickListener
            public void performClick(View view) {
                new Handler().postDelayed(new Runnable() { // from class: calldial.be.loctracker.MagicQG.AdsQurekaDialog.2.1
                    @Override // java.lang.Runnable
                    public void run() {
                        AdsQurekaDialog.this.dismiss();
                    }
                }, 1000L);
                CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
                builder.setToolbarColor(ContextCompat.getColor(AdsQurekaDialog.this.context, R.color.chormecolor));
                AdsQurekaDialog.openCustomTab(AdsQurekaDialog.this.context, builder.build(), Uri.parse("https://766.win.qureka.com"));
            }
        });
    }

    @Override // android.app.Dialog, android.content.DialogInterface
    public void dismiss() {
        super.dismiss();
        AllAdsKeyPlace.Strcheckad = "StrClosed";
        this.onInterstitialAdsClose.onAdsClose();
    }

    @Override // android.app.Dialog, android.view.Window.Callback
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        int[] iArr = {R.drawable.qg_b1, R.drawable.qg_b2, R.drawable.qg_b3};
        if (!this.layoutRandom) {
            ImageView imageView = (ImageView) findViewById(R.id.banner);
            this.banner = imageView;
            imageView.setImageResource(iArr[uniqNoRes]);
            this.banner.startAnimation(AnimationUtils.loadAnimation(this.context, R.anim.zoom_in));
        } else {
            CardView cardView = (CardView) findViewById(R.id.cardViewBg);
            this.cardViewBg = cardView;
            cardView.startAnimation(AnimationUtils.loadAnimation(this.context, R.anim.qg_card_fade_in));
        }
        this.gifImageView.startAnimation(AnimationUtils.loadAnimation(this.context, R.anim.qg_slide_left));
    }

    @Override // android.app.Dialog
    public void show() {
        super.show();
        fn_countdown();
        AllAdsKeyPlace.Strcheckad = "StrOpen";
        if (AllAdsKeyPlace.Backprssornot == 0) {
            AllAdsKeyPlace.FrontshowadsCounter++;
        } else {
            AllAdsKeyPlace.BackshowadsCounter++;
        }
    }

    public static void openCustomTab(Activity activity, CustomTabsIntent customTabsIntent, Uri uri) {
        customTabsIntent.intent.setPackage("com.android.chrome");
        customTabsIntent.launchUrl(activity, uri);
    }

    /* JADX WARN: Type inference failed for: r6v0, types: [calldial.be.loctracker.MagicQG.AdsQurekaDialog$3] */
    private void fn_countdown() {
        new CountDownTimer(5000L, 100L) { // from class: calldial.be.loctracker.MagicQG.AdsQurekaDialog.3
            @Override // android.os.CountDownTimer
            public void onTick(long j) {
                AdsQurekaDialog.this.tvTimer.setText(AdsQurekaDialog.this.hmsTimeFormatter(j));
                AdsQurekaDialog.this.progressBarCircle.setProgress((int) (j / 100));
            }

            @Override // android.os.CountDownTimer
            public void onFinish() {
                AdsQurekaDialog.this.progressBarCircle.setVisibility(8);
                AdsQurekaDialog.this.tvTimer.setVisibility(8);
                AdsQurekaDialog.this.rlClose.setBackgroundColor(ContextCompat.getColor(AdsQurekaDialog.this.context, R.color.transparent));
                AdsQurekaDialog.this.ImgClose.setVisibility(0);
                AdsQurekaDialog.this.setCancelable(true);
            }
        }.start().start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String hmsTimeFormatter(long j) {
        return String.format("%02d", Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(j) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(j))));
    }
}
