package calldial.be.loctracker;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.AnimationUtils;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.LinearLayoutCompat;

/* loaded from: classes.dex */
public class Common {
    Context context;

    public Common(Context context) {
        this.context = context;
    }

    public static boolean isNetworkConnected(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService("connectivity");
        return connectivityManager.getActiveNetworkInfo() != null && connectivityManager.getActiveNetworkInfo().isConnected();
    }

    public static void RateUs(Context context) {
        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + context.getPackageName()));
        intent.addFlags(1208483840);
        try {
            context.startActivity(intent);
        } catch (ActivityNotFoundException unused) {
            context.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("http://play.google.com/store/apps/details?id=" + context.getPackageName())));
        }
    }

    public static void ShareApp(Context context) {
        try {
            Intent intent = new Intent("android.intent.action.SEND");
            intent.setType("text/plain");
            intent.putExtra("android.intent.extra.SUBJECT", R.string.app_name);
            intent.putExtra("android.intent.extra.TEXT", "\nLet me recommend you this application\n\nhttps://play.google.com/store/apps/details?id=" + context.getPackageName() + "\n\n");
            context.startActivity(Intent.createChooser(intent, "choose one"));
        } catch (Exception unused) {
        }
    }

    public static void setFadeAnimation(View view) {
        AlphaAnimation alphaAnimation = new AlphaAnimation(0.0f, 1.0f);
        alphaAnimation.setDuration(500L);
        view.startAnimation(alphaAnimation);
    }

    public static void showPrivacyDialog(Context context) {
        final Dialog dialog = new Dialog(context);
        dialog.setContentView(R.layout.dialog_privacy);
        dialog.setCancelable(true);
        ((ViewGroup) dialog.getWindow().getDecorView()).getChildAt(0).startAnimation(AnimationUtils.loadAnimation(context, R.anim.fade_in));
        dialog.getWindow().setBackgroundDrawableResource(17170445);
        WebView webView = (WebView) dialog.findViewById(R.id.webView1);
        webView.loadUrl(context.getString(R.string.policy_link));
        webView.setWebViewClient(new WebViewClient() { // from class: calldial.be.loctracker.Common.1
            @Override // android.webkit.WebViewClient
            public boolean shouldOverrideUrlLoading(WebView webView2, String str) {
                webView2.loadUrl(str);
                return false;
            }
        });
        ((TextView) dialog.findViewById(R.id.no)).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.Common.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    public static void showRateDialog(final Context context) {
        final Dialog dialog = new Dialog(context);
        dialog.show();
        dialog.setContentView(R.layout.fake_rate_dialog);
        final RatingBar ratingBar = (RatingBar) dialog.findViewById(R.id.rating_bar);
        dialog.getWindow().setBackgroundDrawableResource(17170445);
        ((AppCompatButton) dialog.findViewById(R.id.btn_rate_now)).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.Common.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (ratingBar.getRating() == 0.0f) {
                    Toast.makeText(context, "Please provide some rating!", 1).show();
                } else if (ratingBar.getRating() < 4.0f) {
                    dialog.dismiss();
                    Toast.makeText(context, "Thank you for valuable feedback.", 1).show();
                } else {
                    dialog.dismiss();
                    try {
                        context.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + context.getPackageName())));
                    } catch (ActivityNotFoundException unused) {
                        Context context2 = context;
                        context2.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("http://play.google.com/store/apps/details?id=" + context.getPackageName())));
                    }
                }
            }
        });
        ((LinearLayoutCompat) dialog.findViewById(R.id.bt_maybe_later)).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.Common.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.setCanceledOnTouchOutside(false);
        dialog.setCancelable(true);
        dialog.setOnKeyListener(new DialogInterface.OnKeyListener() { // from class: calldial.be.loctracker.Common.5
            @Override // android.content.DialogInterface.OnKeyListener
            public boolean onKey(DialogInterface dialogInterface, int i, KeyEvent keyEvent) {
                if (i != 4) {
                    return false;
                }
                dialog.dismiss();
                return true;
            }
        });
    }

    public static PushDownAnim Animation(ViewGroup viewGroup) {
        PushDownAnim pushDownAnim = new PushDownAnim(viewGroup);
        PushDownAnim.setPushDownAnimTo(viewGroup);
        pushDownAnim.setScale(1, 8.0f);
        pushDownAnim.setDurationPush(50L);
        pushDownAnim.setDurationRelease(125L);
        AccelerateDecelerateInterpolator accelerateDecelerateInterpolator = PushDownAnim.DEFAULT_INTERPOLATOR;
        pushDownAnim.setInterpolatorPush(accelerateDecelerateInterpolator);
        pushDownAnim.setInterpolatorRelease(accelerateDecelerateInterpolator);
        return pushDownAnim;
    }

    public static PushDownAnim Animation(View view) {
        PushDownAnim pushDownAnim = new PushDownAnim(view);
        PushDownAnim.setPushDownAnimTo(view);
        pushDownAnim.setScale(1, 8.0f);
        pushDownAnim.setDurationPush(50L);
        pushDownAnim.setDurationRelease(125L);
        AccelerateDecelerateInterpolator accelerateDecelerateInterpolator = PushDownAnim.DEFAULT_INTERPOLATOR;
        pushDownAnim.setInterpolatorPush(accelerateDecelerateInterpolator);
        pushDownAnim.setInterpolatorRelease(accelerateDecelerateInterpolator);
        return pushDownAnim;
    }
}
