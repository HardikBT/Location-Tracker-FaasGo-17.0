package calldial.be.loctracker.Compass.app.settings;

import calldial.be.loctracker.Compass.ContractCompass;

/* loaded from: classes.dex */
public class SettingsContractCompass {

    /* loaded from: classes.dex */
    public interface UserActionsListener extends ContractCompass.UserActionsListener<View> {
        void energySavingMode(boolean z);

        void keepScreenOn(boolean z);

        void loadSettings();

        void showAccelerationView(boolean z);

        void showAccuracyView(boolean z);

        void showAdvancedClicked();

        void showMagneticView(boolean z);

        void showOrientationView(boolean z);

        void simpleMode(boolean z);
    }

    /* loaded from: classes.dex */
    interface View extends ContractCompass.View {
        void hideAdvanced();

        void setShowAccelerationView(boolean z);

        void setShowAccuracyView(boolean z);

        void setShowMagneticView(boolean z);

        void setShowOrientationView(boolean z);

        void showAdvanced();

        void showEnergySavingModeSetting(boolean z);

        void showKeepScreenOnSetting(boolean z);

        void showSimpleModeSetting(boolean z);
    }
}
