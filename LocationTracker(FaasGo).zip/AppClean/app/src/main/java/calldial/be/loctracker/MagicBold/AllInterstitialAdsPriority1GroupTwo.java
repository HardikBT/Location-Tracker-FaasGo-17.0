package calldial.be.loctracker.MagicBold;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

import calldial.be.loctracker.MagicQG.AdsQurekaDialog;

/* loaded from: classes.dex */
public class AllInterstitialAdsPriority1GroupTwo {
    private static InterstitialAd AMInterstitial1 = null;
    public static boolean FBCreateLoadedFlag1 = false;
    public static boolean FBCreateRequestFlag1 = false;
    private static String FinishTag1 = "";
    private static onInterstitialAdsClose adsListener2;
    private static AppPrefrence appPrefrence1;
    private static Context mContext;

    public static void LoadInterstitialAd(Context context, String str) {
        try {
            mContext = context;
            AppPrefrence appPrefrence = new AppPrefrence(context);
            appPrefrence1 = appPrefrence;
            if (appPrefrence.getAds_On_Off().equalsIgnoreCase("on")) {
                MobileAds.initialize(context, new OnInitializationCompleteListener() { // from class: calldial.be.loctracker.MagicBold.AllInterstitialAdsPriority1GroupTwo.1
                    @Override
                    // com.google.android.gms.ads.initialization.OnInitializationCompleteListener
                    public void onInitializationComplete(InitializationStatus initializationStatus) {
                    }
                });
                MobileAds.setRequestConfiguration(new RequestConfiguration.Builder().setTestDeviceIds(AllAdsKeyPlace.TestDeviceID).build());
                if (!FBCreateLoadedFlag1) {
                    Log.e("Ads2", "FB Req");
                    FinishTag1 = str;
                    FBCreateLoadedFlag1 = true;
                    FBCreateRequestFlag1 = true;
                    displayAdMobFourInAd();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void displayAdMobFourInAd() {
        AdRequest build = new AdRequest.Builder().build();
        try {
            Context context = mContext;
            InterstitialAd.load(context, new AppPrefrence(context).getAM_INTERTITIAL(), build, new InterstitialAdLoadCallback() { // from class: calldial.be.loctracker.MagicBold.AllInterstitialAdsPriority1GroupTwo.2
                public void onAdLoaded(InterstitialAd interstitialAd) {
                    super.onAdLoaded(interstitialAd);
                    InterstitialAd unused = AllInterstitialAdsPriority1GroupTwo.AMInterstitial1 = interstitialAd;
                    AllInterstitialAdsPriority1GroupTwo.FBCreateRequestFlag1 = false;
                    Log.e("Intertitial_2_four", "onAdLoaded.");
                    AllInterstitialAdsPriority1GroupTwo.AMCallBack();
                }

                @Override // com.google.android.gms.ads.AdLoadCallback
                public void onAdFailedToLoad(LoadAdError loadAdError) {
                    super.onAdFailedToLoad(loadAdError);
                    Log.e("Intertitial_2_four", "Error." + loadAdError.getCode() + "-" + loadAdError.toString());
                    AllInterstitialAdsPriority1GroupTwo.LoadSDKInterstitialAd();
                    InterstitialAd unused = AllInterstitialAdsPriority1GroupTwo.AMInterstitial1 = null;
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void AMCallBack() {
        AMInterstitial1.setFullScreenContentCallback(new FullScreenContentCallback() { // from class: calldial.be.loctracker.MagicBold.AllInterstitialAdsPriority1GroupTwo.3
            @Override // com.google.android.gms.ads.FullScreenContentCallback
            public void onAdDismissedFullScreenContent() {
                if (!AllInterstitialAdsPriority1GroupTwo.FinishTag1.equals("Fail")) {
                    AllInterstitialAdsPriority1GroupTwo.adsListener2.onAdsClose();
                }
                AllAdsKeyPlace.Strcheckad = "StrClosed";
                Log.e("TAG", "The ad was dismissed.");
                InterstitialAd unused = AllInterstitialAdsPriority1GroupTwo.AMInterstitial1 = null;
            }

            @Override // com.google.android.gms.ads.FullScreenContentCallback
            public void onAdFailedToShowFullScreenContent(AdError adError) {
                super.onAdFailedToShowFullScreenContent(adError);
                Log.e("TAG", "onAdFailedToShowFullScreenContent.");
                if (!AllInterstitialAdsPriority1GroupTwo.FinishTag1.equals("Fail")) {
                    AllInterstitialAdsPriority1GroupTwo.adsListener2.onAdsClose();
                }
                AllAdsKeyPlace.Strcheckad = "StrClosed";
            }

            @Override // com.google.android.gms.ads.FullScreenContentCallback
            public void onAdShowedFullScreenContent() {
                Log.e("TAGsasassa", "The ad was shown.");
                if (AllAdsKeyPlace.Backprssornot == 0) {
                    AllAdsKeyPlace.FrontshowadsCounter++;
                } else {
                    AllAdsKeyPlace.BackshowadsCounter++;
                }
            }
        });
    }

    public static void ShowInterstitialAd(Context context, String str, onInterstitialAdsClose oninterstitialadsclose) {
        mContext = context;
        if (FBCreateLoadedFlag1) {
            AllAdsKeyPlace.Strcheckad = "StrOpen";
            try {
                adsListener2 = oninterstitialadsclose;
                InterstitialAd interstitialAd = AMInterstitial1;
                if (interstitialAd != null) {
                    FinishTag1 = str;
                    interstitialAd.show((Activity) context);
                    FBCreateLoadedFlag1 = false;
                    AllInterstitialAdsPriorityGroupTwo.LoadInterstitialAd(mContext, FinishTag1);
                    return;
                }
                FBCreateLoadedFlag1 = false;
                FinishTag1 = str;
                if (appPrefrence1.getQureka_ADS().equalsIgnoreCase("on")) {
                    Log.e("@@TAG", "ShowInterstitialAd: Qureka");
                    new AdsQurekaDialog((Activity) context, adsListener2).show();
                } else if (!FinishTag1.equals("Fail")) {
                    adsListener2.onAdsClose();
                }
                AllInterstitialAdsPriorityGroupTwo.LoadInterstitialAd(mContext, FinishTag1);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            adsListener2 = oninterstitialadsclose;
            FinishTag1 = str;
            AllInterstitialAdsPriorityGroupTwo.LoadInterstitialAd(context, str);
        }
    }

    public static void ChangeActivityWithAds(final Activity activity, final Class cls, final String str) {
        if (!FBCreateRequestFlag1) {
            ShowInterstitialAd(activity, str, new onInterstitialAdsClose() { // from class: calldial.be.loctracker.MagicBold.AllInterstitialAdsPriority1GroupTwo.4
                @Override // calldial.be.loctracker.MagicBold.onInterstitialAdsClose
                public void onAdsClose() {
                    activity.startActivity(new Intent(activity, cls));
                    if (str.equals("true") || str.equals("True") || str.equals("TRUE")) {
                        activity.finish();
                    }
                }
            });
            return;
        }
        activity.startActivity(new Intent(activity, cls));
        if (str.equals("true") || str.equals("True") || str.equals("TRUE")) {
            activity.finish();
        }
    }

    public static void CloseActivityWithAds(final Activity activity, final String str) {
        if (!FBCreateRequestFlag1) {
            ShowInterstitialAd(activity, str, new onInterstitialAdsClose() { // from class: calldial.be.loctracker.MagicBold.AllInterstitialAdsPriority1GroupTwo.5
                @Override // calldial.be.loctracker.MagicBold.onInterstitialAdsClose
                public void onAdsClose() {
                    if (str.equals("true") || str.equals("True") || str.equals("TRUE")) {
                        activity.finish();
                    }
                }
            });
        } else if (str.equals("true") || str.equals("True") || str.equals("TRUE")) {
            activity.finish();
        }
    }

    public static void ShowAdsOnCreate(Context context) {
        if (!FBCreateRequestFlag1) {
            ShowInterstitialAd(context, "false", new onInterstitialAdsClose() { // from class: calldial.be.loctracker.MagicBold.AllInterstitialAdsPriority1GroupTwo.6
                @Override // calldial.be.loctracker.MagicBold.onInterstitialAdsClose
                public void onAdsClose() {
                }
            });
        }
    }

    public static void LoadSDKInterstitialAd() {
        try {
            Log.e("sdkInter2", "Load");
            FBCreateRequestFlag1 = false;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
