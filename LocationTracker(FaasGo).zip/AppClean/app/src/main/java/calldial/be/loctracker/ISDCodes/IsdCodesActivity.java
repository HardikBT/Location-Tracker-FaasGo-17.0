package calldial.be.loctracker.ISDCodes;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import calldial.be.loctracker.Common;
import calldial.be.loctracker.DashboardActivity;
import calldial.be.loctracker.MagicBold.AllAdsKeyPlace;
import calldial.be.loctracker.MagicBold.AppPrefrence;
import calldial.be.loctracker.MagicQG.QG;
import calldial.be.loctracker.MoreAdActivity;
import calldial.be.loctracker.R;
import in.mayanknagwanshi.countrypicker.bean.CountryData;
import in.mayanknagwanshi.countrypicker.custom.CountryPickerView;
import in.mayanknagwanshi.countrypicker.listener.CountrySelectListener;

/* loaded from: classes.dex */
public class IsdCodesActivity extends AppCompatActivity {
    ImageView imgDrawerLines;
    LinearLayout iv_moreads;
    private DrawerLayout mDrawerLayout;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_isd_codes);
        AllAdsKeyPlace.ShowInterstitialAdsOnCreate(this);
        AllAdsKeyPlace.ShowNativeBannerAd(this, (ViewGroup) findViewById(R.id.nativeContainer1));
        this.iv_moreads = (LinearLayout) findViewById(R.id.iv_moreads);
        if (Common.isNetworkConnected(this) && new AppPrefrence(getApplicationContext()).getQureka_ADS().equalsIgnoreCase("on")) {
            this.iv_moreads.setVisibility(0);
        }
        this.iv_moreads.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.ISDCodes.IsdCodesActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                QG.openQGAlternate(IsdCodesActivity.this);
            }
        });
        this.mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        ImageView imageView = (ImageView) findViewById(R.id.imgDrawerLines);
        this.imgDrawerLines = imageView;
        Common.Animation(imageView);
        this.imgDrawerLines.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.ISDCodes.IsdCodesActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (IsdCodesActivity.this.mDrawerLayout.isDrawerOpen(3)) {
                    IsdCodesActivity.this.mDrawerLayout.closeDrawer(5);
                } else {
                    IsdCodesActivity.this.mDrawerLayout.openDrawer(3);
                }
            }
        });
        findViewById(R.id.llhomeapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.ISDCodes.IsdCodesActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                IsdCodesActivity.this.mDrawerLayout.closeDrawers();
                IsdCodesActivity.this.startActivity(new Intent(IsdCodesActivity.this, DashboardActivity.class));
            }
        });
        findViewById(R.id.llrateapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.ISDCodes.IsdCodesActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                IsdCodesActivity.this.mDrawerLayout.closeDrawers();
                Common.showRateDialog(IsdCodesActivity.this);
            }
        });
        findViewById(R.id.llshareapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.ISDCodes.IsdCodesActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                IsdCodesActivity.this.mDrawerLayout.closeDrawers();
                Common.ShareApp(IsdCodesActivity.this);
            }
        });
        findViewById(R.id.llpolicy__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.ISDCodes.IsdCodesActivity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                IsdCodesActivity.this.mDrawerLayout.closeDrawers();
                Common.showPrivacyDialog(IsdCodesActivity.this);
            }
        });
        findViewById(R.id.llmoreapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.ISDCodes.IsdCodesActivity.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                IsdCodesActivity.this.mDrawerLayout.closeDrawers();
                IsdCodesActivity.this.startActivity(new Intent(IsdCodesActivity.this, MoreAdActivity.class));
            }
        });
        final CountryPickerView countryPickerView = (CountryPickerView) findViewById(R.id.countryPickerView);
        countryPickerView.setCountrySelectListener(new CountrySelectListener() { // from class: calldial.be.loctracker.ISDCodes.-$$Lambda$IsdCodesActivity$wW01rFxkSvFjx4J3KT9yJTjOYwU
            @Override // in.mayanknagwanshi.countrypicker.listener.CountrySelectListener
            public final void onCountrySelect(CountryData countryData) {
                IsdCodesActivity.this.lambda$onCreate$0$IsdCodesActivity(countryPickerView, countryData);
            }
        });
    }

    public /* synthetic */ void lambda$onCreate$0$IsdCodesActivity(CountryPickerView countryPickerView, CountryData countryData) {
        String countryName = countryPickerView.getSelectedCountry().getCountryName();
        String countryISD = countryPickerView.getSelectedCountry().getCountryISD();
        Toast.makeText(this, "Country Name : " + countryName + "\nISD Code: " + countryISD, 1).show();
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        AllAdsKeyPlace.CloseActivityWithAds(this, "true");
    }
}
