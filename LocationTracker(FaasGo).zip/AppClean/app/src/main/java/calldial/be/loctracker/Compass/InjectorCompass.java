package calldial.be.loctracker.Compass;

import android.content.Context;

import calldial.be.loctracker.Compass.app.main.MainContractCompass;
import calldial.be.loctracker.Compass.app.main.MainPresenterCompass;
import calldial.be.loctracker.Compass.app.settings.SettingsContractCompass;
import calldial.be.loctracker.Compass.app.settings.SettingsPresenterCompass;
import calldial.be.loctracker.Compass.data.PrefsCompass;
import calldial.be.loctracker.Compass.data.PrefsImplCompass;
import calldial.be.loctracker.Compass.sensor.SensorsContractCompass;
import calldial.be.loctracker.Compass.sensor.SensorsImplCompass;

/* loaded from: classes.dex */
public class InjectorCompass {
    private Context context;
    private MainContractCompass.UserActionsListener mainPresenter;
    private SensorsContractCompass.Sensors sensors;
    private SettingsContractCompass.UserActionsListener settingsPresenter;

    public void closeTasks() {
    }

    public InjectorCompass(Context context) {
        this.context = context;
    }

    public PrefsCompass providePrefs() {
        return PrefsImplCompass.getInstance(this.context);
    }

    public ColorMapCompass provideColorMap() {
        return ColorMapCompass.getInstance(providePrefs());
    }

    public MainContractCompass.UserActionsListener provideMainPresenter() {
        if (this.mainPresenter == null) {
            this.mainPresenter = new MainPresenterCompass(providePrefs(), provideSensors());
        }
        return this.mainPresenter;
    }

    public SettingsContractCompass.UserActionsListener provideSettingsPresenter() {
        if (this.settingsPresenter == null) {
            this.settingsPresenter = new SettingsPresenterCompass(providePrefs());
        }
        return this.settingsPresenter;
    }

    public SensorsContractCompass.Sensors provideSensors() {
        if (this.sensors == null) {
            this.sensors = new SensorsImplCompass(this.context);
        }
        return this.sensors;
    }

    public void releaseMainPresenter() {
        MainContractCompass.UserActionsListener userActionsListener = this.mainPresenter;
        if (userActionsListener != null) {
            userActionsListener.unbindView();
            this.mainPresenter = null;
        }
    }

    public void releaseSettingsPresenter() {
        SettingsContractCompass.UserActionsListener userActionsListener = this.settingsPresenter;
        if (userActionsListener != null) {
            userActionsListener.unbindView();
            this.settingsPresenter = null;
        }
    }
}
