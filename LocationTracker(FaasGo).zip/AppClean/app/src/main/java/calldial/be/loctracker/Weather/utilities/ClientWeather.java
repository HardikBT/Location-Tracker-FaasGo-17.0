package calldial.be.loctracker.Weather.utilities;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/* loaded from: classes.dex */
public class ClientWeather {
    private static Retrofit client;

    public static Retrofit getClient() {
        if (client == null) {
            client = new Retrofit.Builder().baseUrl(ConstantsWeather.BASE_URL).addConverterFactory(GsonConverterFactory.create()).build();
        }
        return client;
    }
}
