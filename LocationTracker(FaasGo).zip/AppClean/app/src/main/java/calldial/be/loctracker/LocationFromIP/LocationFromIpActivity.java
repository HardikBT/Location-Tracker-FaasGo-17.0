package calldial.be.loctracker.LocationFromIP;

import android.content.Intent;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.core.widget.NestedScrollView;
import androidx.drawerlayout.widget.DrawerLayout;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.androidfung.geoip.api.ApiManager;
import com.androidfung.geoip.model.GeoIpResponseModel;
import com.google.android.material.appbar.AppBarLayout;

import calldial.be.loctracker.Common;
import calldial.be.loctracker.DashboardActivity;
import calldial.be.loctracker.GoogleMap.LiveLocationMapActivity;
import calldial.be.loctracker.MagicBold.AllAdsKeyPlace;
import calldial.be.loctracker.MagicBold.AppPrefrence;
import calldial.be.loctracker.MagicQG.QG;
import calldial.be.loctracker.MoreAdActivity;
import calldial.be.loctracker.R;

/* loaded from: classes.dex */
public class LocationFromIpActivity extends AppCompatActivity {
    public static boolean IS_DOWN = true;
    public static boolean IS_UP = true;
    private static final int REQUEST_LOCATION_CODE = 1;
    AppBarLayout appbarlay_tool;
    Animation down_anim_toolbar;
    ImageView imgDrawerLines;
    LinearLayout iv_moreads;
    String latitude;
    LinearLayout ll_live_location_google_map;
    LocationManager locationManager;
    String longitude;
    private DrawerLayout mDrawerLayout;
    NestedScrollView nested_scroll;
    TextView tv_as;
    TextView tv_city;
    TextView tv_country;
    TextView tv_ip_address;
    TextView tv_isp;
    TextView tv_latitude;
    TextView tv_longitude;
    TextView tv_organisation;
    TextView tv_region;
    TextView tv_timezone;
    Animation up_anim_toolbar;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_location_from_ip);
        AllAdsKeyPlace.ShowInterstitialAdsOnCreate(this);
        AllAdsKeyPlace.ShowNativeAd(this, (ViewGroup) findViewById(R.id.nativeContainer));
        this.iv_moreads = (LinearLayout) findViewById(R.id.iv_moreads);
        if (Common.isNetworkConnected(this) && new AppPrefrence(getApplicationContext()).getQureka_ADS().equalsIgnoreCase("on")) {
            this.iv_moreads.setVisibility(0);
        }
        this.iv_moreads.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LocationFromIP.LocationFromIpActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                QG.openQGAlternate(LocationFromIpActivity.this);
            }
        });
        this.mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        ImageView imageView = (ImageView) findViewById(R.id.imgDrawerLines);
        this.imgDrawerLines = imageView;
        Common.Animation(imageView);
        this.imgDrawerLines.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LocationFromIP.LocationFromIpActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (LocationFromIpActivity.this.mDrawerLayout.isDrawerOpen(3)) {
                    LocationFromIpActivity.this.mDrawerLayout.closeDrawer(5);
                } else {
                    LocationFromIpActivity.this.mDrawerLayout.openDrawer(3);
                }
            }
        });
        findViewById(R.id.llhomeapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LocationFromIP.LocationFromIpActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                LocationFromIpActivity.this.mDrawerLayout.closeDrawers();
                LocationFromIpActivity.this.startActivity(new Intent(LocationFromIpActivity.this, DashboardActivity.class));
            }
        });
        findViewById(R.id.llrateapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LocationFromIP.LocationFromIpActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                LocationFromIpActivity.this.mDrawerLayout.closeDrawers();
                Common.showRateDialog(LocationFromIpActivity.this);
            }
        });
        findViewById(R.id.llshareapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LocationFromIP.LocationFromIpActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                LocationFromIpActivity.this.mDrawerLayout.closeDrawers();
                Common.ShareApp(LocationFromIpActivity.this);
            }
        });
        findViewById(R.id.llpolicy__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LocationFromIP.LocationFromIpActivity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                LocationFromIpActivity.this.mDrawerLayout.closeDrawers();
                Common.showPrivacyDialog(LocationFromIpActivity.this);
            }
        });
        findViewById(R.id.llmoreapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LocationFromIP.LocationFromIpActivity.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                LocationFromIpActivity.this.mDrawerLayout.closeDrawers();
                LocationFromIpActivity.this.startActivity(new Intent(LocationFromIpActivity.this, MoreAdActivity.class));
            }
        });
        this.tv_ip_address = (TextView) findViewById(R.id.tv_ip_address);
        this.tv_city = (TextView) findViewById(R.id.tv_city);
        this.tv_region = (TextView) findViewById(R.id.tv_region);
        this.tv_country = (TextView) findViewById(R.id.tv_country);
        this.tv_longitude = (TextView) findViewById(R.id.tv_longitude);
        this.tv_latitude = (TextView) findViewById(R.id.tv_latitude);
        this.tv_timezone = (TextView) findViewById(R.id.tv_timezone);
        this.tv_isp = (TextView) findViewById(R.id.tv_isp);
        this.tv_organisation = (TextView) findViewById(R.id.tv_organisation);
        this.tv_as = (TextView) findViewById(R.id.tv_as);
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.ll_live_location_google_map);
        this.ll_live_location_google_map = linearLayout;
        Common.Animation((ViewGroup) linearLayout);
        getInfoFromIpAddress();
        this.appbarlay_tool = (AppBarLayout) findViewById(R.id.appbarlay_tool);
        this.nested_scroll = (NestedScrollView) findViewById(R.id.nested_scroll);
        this.down_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.down_anim_toolbar);
        this.up_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.up_anim_toolbar);
        NestedScrollView nestedScrollView = this.nested_scroll;
        if (nestedScrollView != null) {
            nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() { // from class: calldial.be.loctracker.LocationFromIP.LocationFromIpActivity.8
                @Override // androidx.core.widget.NestedScrollView.OnScrollChangeListener
                public void onScrollChange(NestedScrollView nestedScrollView2, int i, int i2, int i3, int i4) {
                    if (i2 > i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling DOWN");
                        if (LocationFromIpActivity.IS_UP) {
                            LocationFromIpActivity.this.appbarlay_tool.startAnimation(LocationFromIpActivity.this.up_anim_toolbar);
                            LocationFromIpActivity.IS_UP = false;
                            LocationFromIpActivity.IS_DOWN = true;
                        }
                    }
                    if (i2 < i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling UP");
                        if (LocationFromIpActivity.IS_DOWN) {
                            LocationFromIpActivity.this.appbarlay_tool.startAnimation(LocationFromIpActivity.this.down_anim_toolbar);
                            LocationFromIpActivity.IS_DOWN = false;
                            LocationFromIpActivity.IS_UP = true;
                        }
                    }
                    if (i2 == 0) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to TOP SCROLL");
                    }
                    if (i2 == nestedScrollView2.getMeasuredHeight() - nestedScrollView2.getChildAt(0).getMeasuredHeight()) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to BOTTOM SCROLL");
                    }
                }
            });
        }
        this.ll_live_location_google_map.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LocationFromIP.LocationFromIpActivity.9
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Intent intent = new Intent(LocationFromIpActivity.this, LiveLocationMapActivity.class);
                intent.putExtra("IS_TRAFFIC_ENABLED", false);
                LocationFromIpActivity.this.startActivity(intent);
            }
        });
    }

    public void getInfoFromIpAddress() {
        new ApiManager(Volley.newRequestQueue(this)).getGeoIpInfo(new Response.Listener<GeoIpResponseModel>() { // from class: calldial.be.loctracker.LocationFromIP.LocationFromIpActivity.10
            public void onResponse(GeoIpResponseModel geoIpResponseModel) {
                String query = geoIpResponseModel.getQuery();
                String city = geoIpResponseModel.getCity();
                String str = geoIpResponseModel.getRegionName() + " (" + geoIpResponseModel.getRegion() + ")";
                String str2 = geoIpResponseModel.getCountry() + " (" + geoIpResponseModel.getCountryCode() + ")";
                double latitude = geoIpResponseModel.getLatitude();
                double longitude = geoIpResponseModel.getLongitude();
                String timezone = geoIpResponseModel.getTimezone();
                String isp = geoIpResponseModel.getIsp();
                String org2 = geoIpResponseModel.getOrg();
                String as = geoIpResponseModel.getAs();
                LocationFromIpActivity.this.tv_ip_address.setText(query);
                LocationFromIpActivity.this.tv_city.setText(city);
                LocationFromIpActivity.this.tv_region.setText(str);
                LocationFromIpActivity.this.tv_country.setText(str2);
                LocationFromIpActivity.this.tv_latitude.setText(String.valueOf(latitude));
                LocationFromIpActivity.this.tv_longitude.setText(String.valueOf(longitude));
                LocationFromIpActivity.this.tv_timezone.setText(timezone);
                LocationFromIpActivity.this.tv_isp.setText(isp);
                LocationFromIpActivity.this.tv_organisation.setText(org2);
                LocationFromIpActivity.this.tv_as.setText(as);
            }
        }, new Response.ErrorListener() { // from class: calldial.be.loctracker.LocationFromIP.LocationFromIpActivity.11
            @Override // com.android.volley.Response.ErrorListener
            public void onErrorResponse(VolleyError volleyError) {
                String volleyError2 = volleyError.toString();
                LocationFromIpActivity locationFromIpActivity = LocationFromIpActivity.this;
                Toast.makeText(locationFromIpActivity, "Error : " + volleyError2, 0).show();
            }
        });
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (this.mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            this.mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            AllAdsKeyPlace.CloseActivityWithAds(this, "true");
        }
    }
}
