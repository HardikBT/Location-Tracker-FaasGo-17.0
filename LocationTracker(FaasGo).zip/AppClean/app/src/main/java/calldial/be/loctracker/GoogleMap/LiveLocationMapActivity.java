package calldial.be.loctracker.GoogleMap;

import android.app.Activity;
import android.content.Context;
import android.location.Location;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;

import calldial.be.loctracker.MagicBold.AllAdsKeyPlace;
import calldial.be.loctracker.R;

/* loaded from: classes.dex */
public class LiveLocationMapActivity extends FragmentActivity implements OnMapReadyCallback {
    private static final int REQUEST_CODE = 101;
    Location currentLocation;
    FusedLocationProviderClient fusedLocationProviderClient;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_live_location_map);
        AllAdsKeyPlace.ShowInterstitialAdsOnCreate(this);
        AllAdsKeyPlace.ShowNativeBannerAd(this, (ViewGroup) findViewById(R.id.nativeContainer1));
        this.fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient((Activity) this);
        fetchLocation();
    }

    private void fetchLocation() {
        if (ActivityCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0 || ActivityCompat.checkSelfPermission(this, "android.permission.ACCESS_COARSE_LOCATION") == 0) {
            this.fusedLocationProviderClient.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() { // from class: calldial.be.loctracker.GoogleMap.LiveLocationMapActivity.1
                static final /* synthetic */ boolean $assertionsDisabled = false;

                public void onSuccess(Location location) {
                    if (location != null) {
                        LiveLocationMapActivity.this.currentLocation = location;
                        Context applicationContext = LiveLocationMapActivity.this.getApplicationContext();
                        Toast.makeText(applicationContext, LiveLocationMapActivity.this.currentLocation.getLatitude() + "" + LiveLocationMapActivity.this.currentLocation.getLongitude(), 0).show();
                        ((SupportMapFragment) LiveLocationMapActivity.this.getSupportFragmentManager().findFragmentById(R.id.myMap)).getMapAsync(LiveLocationMapActivity.this);
                    }
                }
            });
        } else {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.ACCESS_FINE_LOCATION"}, 101);
        }
    }

    @Override // com.google.android.gms.maps.OnMapReadyCallback
    public void onMapReady(GoogleMap googleMap) {
        LatLng latLng = new LatLng(this.currentLocation.getLatitude(), this.currentLocation.getLongitude());
        MarkerOptions title = new MarkerOptions().position(latLng).title("I am here!");
        googleMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 5.0f));
        googleMap.addMarker(title);
        googleMap.setTrafficEnabled(getIntent().getExtras().getBoolean("IS_TRAFFIC_ENABLED"));
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i == 101 && iArr.length > 0 && iArr[0] == 0) {
            fetchLocation();
        }
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        AllAdsKeyPlace.CloseActivityWithAds(this, "true");
    }
}
