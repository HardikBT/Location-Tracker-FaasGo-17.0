package calldial.be.loctracker.Compass.app.settings;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.text.SpannableStringBuilder;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import calldial.be.loctracker.Compass.AppConstantsCompass;
import calldial.be.loctracker.Compass.ColorMapCompass;
import calldial.be.loctracker.Compass.util.AnimationUtilCompass;
import calldial.be.loctracker.MagicBold.AllAdsKeyPlace;
import calldial.be.loctracker.MagicCode.GlobalMaintainer;
import calldial.be.loctracker.R;

/* loaded from: classes.dex */
public class SettingsActivityCompass extends Activity implements SettingsContractCompass.View, View.OnClickListener, CompoundButton.OnCheckedChangeListener {
    public static final long ANIMATION_DURATION = 200;
    private static final String VERSION_UNAVAILABLE = "N/A";
    private ColorMapCompass colorMap;
    private ImageView imgAdvanced;
    private ColorMapCompass.OnThemeColorChangeListener onThemeColorChangeListener;
    private LinearLayout pnlShowAcceleration;
    private LinearLayout pnlShowAccuracy;
    private LinearLayout pnlShowMagnetic;
    private LinearLayout pnlShowOrientation;
    private SettingsContractCompass.UserActionsListener presenter;
    private Switch swEnergySaving;
    private Switch swKeepScreenOn;
    private Switch swShowAcceleration;
    private Switch swShowAccuracy;
    private Switch swShowMagnetic;
    private Switch swShowOrientation;
    private Switch swSimpleMode;

    @Override // calldial.be.loctracker.Compass.ContractCompass.View
    public void hideProgress() {
    }

    @Override // calldial.be.loctracker.Compass.ContractCompass.View
    public void showProgress() {
    }

    public static Intent getStartIntent(Context context) {
        Intent intent = new Intent(context, SettingsActivityCompass.class);
        intent.setFlags(536870912);
        return intent;
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        ColorMapCompass provideColorMap = GlobalMaintainer.getInjector().provideColorMap();
        this.colorMap = provideColorMap;
        setTheme(provideColorMap.getAppThemeResource());
        super.onCreate(bundle);
        setContentView(R.layout.activity_settings_compass);
        AllAdsKeyPlace.ShowInterstitialAdsOnCreate(this);
        this.imgAdvanced = (ImageView) findViewById(R.id.imgAdvanced);
        ((TextView) findViewById(R.id.txtAbout)).setText(getAboutContent());
        ((ImageButton) findViewById(R.id.btn_back)).setOnClickListener(this);
        ((TextView) findViewById(R.id.btnRate)).setOnClickListener(this);
        ((TextView) findViewById(R.id.btnRequest)).setOnClickListener(this);
        ((LinearLayout) findViewById(R.id.pnlAdvanced)).setOnClickListener(this);
        this.swKeepScreenOn = (Switch) findViewById(R.id.swKeepScreenOn);
        this.swEnergySaving = (Switch) findViewById(R.id.swEnergySaving);
        this.swSimpleMode = (Switch) findViewById(R.id.swSimpleMode);
        this.swShowAcceleration = (Switch) findViewById(R.id.swShowAcceleration);
        this.swShowOrientation = (Switch) findViewById(R.id.swShowOrientation);
        this.swShowAccuracy = (Switch) findViewById(R.id.swShowAccuracy);
        this.swShowMagnetic = (Switch) findViewById(R.id.swShowMagnetic);
        this.pnlShowAcceleration = (LinearLayout) findViewById(R.id.pnlAcceleration);
        this.pnlShowOrientation = (LinearLayout) findViewById(R.id.pnlOrientation);
        this.pnlShowAccuracy = (LinearLayout) findViewById(R.id.pnlAccuracy);
        this.pnlShowMagnetic = (LinearLayout) findViewById(R.id.pnlMagnetic);
        this.swKeepScreenOn.setOnCheckedChangeListener(this);
        this.swEnergySaving.setOnCheckedChangeListener(this);
        this.swSimpleMode.setOnCheckedChangeListener(this);
        this.swShowAcceleration.setOnCheckedChangeListener(this);
        this.swShowOrientation.setOnCheckedChangeListener(this);
        this.swShowAccuracy.setOnCheckedChangeListener(this);
        this.swShowMagnetic.setOnCheckedChangeListener(this);
        this.presenter = GlobalMaintainer.getInjector().provideSettingsPresenter();
        Spinner spinner = (Spinner) findViewById(R.id.themeColor);
        ArrayList arrayList = new ArrayList();
        String[] stringArray = getResources().getStringArray(R.array.theme_colors);
        int[] colorResources = this.colorMap.getColorResources();
        for (int i = 0; i < stringArray.length; i++) {
            arrayList.add(new ThemeColorAdapterCompass.ThemeItem(stringArray[i], getApplicationContext().getResources().getColor(colorResources[i])));
        }
        spinner.setAdapter((SpinnerAdapter) new ThemeColorAdapterCompass(this, R.layout.list_item_spinner_compass, R.id.txtColor, arrayList));
        ColorMapCompass.OnThemeColorChangeListener onThemeColorChangeListener = new ColorMapCompass.OnThemeColorChangeListener() { // from class: calldial.be.loctracker.Compass.app.settings.SettingsActivityCompass.1
            @Override // calldial.be.loctracker.Compass.ColorMapCompass.OnThemeColorChangeListener
            public void onThemeColorChange(int i2) {
                SettingsActivityCompass settingsActivityCompass = SettingsActivityCompass.this;
                settingsActivityCompass.setTheme(settingsActivityCompass.colorMap.getAppThemeResource());
                SettingsActivityCompass.this.recreate();
            }
        };
        this.onThemeColorChangeListener = onThemeColorChangeListener;
        this.colorMap.addOnThemeColorChangeListener(onThemeColorChangeListener);
        if (this.colorMap.getSelected() > 0) {
            spinner.setSelection(this.colorMap.getSelected());
        }
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() { // from class: calldial.be.loctracker.Compass.app.settings.SettingsActivityCompass.2
            @Override // android.widget.AdapterView.OnItemSelectedListener
            public void onNothingSelected(AdapterView<?> adapterView) {
            }

            @Override // android.widget.AdapterView.OnItemSelectedListener
            public void onItemSelected(AdapterView<?> adapterView, View view, int i2, long j) {
                SettingsActivityCompass.this.colorMap.updateColorMap(i2);
            }
        });
    }

    @Override // android.app.Activity
    protected void onStart() {
        super.onStart();
        this.presenter.bindView(this);
        this.presenter.loadSettings();
    }

    @Override // android.app.Activity
    protected void onStop() {
        super.onStop();
        SettingsContractCompass.UserActionsListener userActionsListener = this.presenter;
        if (userActionsListener != null) {
            userActionsListener.unbindView();
        }
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        super.onDestroy();
        this.colorMap.removeOnThemeColorChangeListener(this.onThemeColorChangeListener);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnRate /* 2131361932 */:
                rateApp();
                return;
            case R.id.btnRequest /* 2131361933 */:
                requestFeature();
                return;
            case R.id.btn_back /* 2131361937 */:
                onBackPressed();
                GlobalMaintainer.getInjector().releaseSettingsPresenter();
                return;
            case R.id.pnlAdvanced /* 2131362394 */:
                this.presenter.showAdvancedClicked();
                return;
            default:
                return;
        }
    }

    @Override // android.widget.CompoundButton.OnCheckedChangeListener
    public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        switch (compoundButton.getId()) {
            case R.id.swEnergySaving /* 2131362508 */:
                this.presenter.energySavingMode(z);
                return;
            case R.id.swKeepScreenOn /* 2131362509 */:
                this.presenter.keepScreenOn(z);
                return;
            case R.id.swShowAcceleration /* 2131362510 */:
                this.presenter.showAccelerationView(z);
                return;
            case R.id.swShowAccuracy /* 2131362511 */:
                this.presenter.showAccuracyView(z);
                return;
            case R.id.swShowMagnetic /* 2131362512 */:
                this.presenter.showMagneticView(z);
                return;
            case R.id.swShowOrientation /* 2131362513 */:
                this.presenter.showOrientationView(z);
                return;
            case R.id.swSimpleMode /* 2131362514 */:
                this.presenter.simpleMode(z);
                return;
            default:
                return;
        }
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        GlobalMaintainer.getInjector().releaseSettingsPresenter();
        AllAdsKeyPlace.CloseActivityWithAds(this, "true");
    }

    private void rateApp() {
        try {
            startActivity(rateIntentForUrl("market://details"));
        } catch (ActivityNotFoundException unused) {
            startActivity(rateIntentForUrl("https://play.google.com/store/apps/details"));
        }
    }

    private void requestFeature() {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("message/rfc822");
        intent.putExtra("android.intent.extra.EMAIL", new String[]{AppConstantsCompass.REQUESTS_RECEIVER});
        intent.putExtra("android.intent.extra.SUBJECT", "[" + getResources().getString(R.string.app_name) + "] - " + getResources().getString(R.string.request));
        try {
            startActivity(Intent.createChooser(intent, getResources().getString(R.string.send_email)));
        } catch (ActivityNotFoundException unused) {
            showError(R.string.email_clients_not_found);
        }
    }

    private Intent rateIntentForUrl(String str) {
        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(String.format("%s?id=%s", str, getApplicationContext().getPackageName())));
        int i = Build.VERSION.SDK_INT;
        intent.addFlags(1208483840);
        return intent;
    }

    public SpannableStringBuilder getAboutContent() {
        String str;
        try {
            str = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException unused) {
            str = VERSION_UNAVAILABLE;
        }
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
        spannableStringBuilder.append((CharSequence) Html.fromHtml(getString(R.string.about_body, new Object[]{str})));
        return spannableStringBuilder;
    }

    @Override // calldial.be.loctracker.Compass.app.settings.SettingsContractCompass.View
    public void showKeepScreenOnSetting(boolean z) {
        this.swKeepScreenOn.setChecked(z);
    }

    @Override // calldial.be.loctracker.Compass.app.settings.SettingsContractCompass.View
    public void showSimpleModeSetting(boolean z) {
        this.swSimpleMode.setChecked(z);
    }

    @Override // calldial.be.loctracker.Compass.app.settings.SettingsContractCompass.View
    public void showEnergySavingModeSetting(boolean z) {
        this.swEnergySaving.setChecked(z);
    }

    @Override // calldial.be.loctracker.Compass.app.settings.SettingsContractCompass.View
    public void showAdvanced() {
        AnimationUtilCompass.viewRotationAnimation(this.imgAdvanced, 200L);
        this.pnlShowAcceleration.setVisibility(0);
        this.pnlShowOrientation.setVisibility(0);
        this.pnlShowAccuracy.setVisibility(0);
        this.pnlShowMagnetic.setVisibility(0);
    }

    @Override // calldial.be.loctracker.Compass.app.settings.SettingsContractCompass.View
    public void hideAdvanced() {
        AnimationUtilCompass.viewBackRotationAnimation(this.imgAdvanced, 200L);
        this.pnlShowAcceleration.setVisibility(8);
        this.pnlShowOrientation.setVisibility(8);
        this.pnlShowAccuracy.setVisibility(8);
        this.pnlShowMagnetic.setVisibility(8);
    }

    @Override // calldial.be.loctracker.Compass.app.settings.SettingsContractCompass.View
    public void setShowAccelerationView(boolean z) {
        this.swShowAcceleration.setChecked(z);
    }

    @Override // calldial.be.loctracker.Compass.app.settings.SettingsContractCompass.View
    public void setShowOrientationView(boolean z) {
        this.swShowOrientation.setChecked(z);
    }

    @Override // calldial.be.loctracker.Compass.app.settings.SettingsContractCompass.View
    public void setShowAccuracyView(boolean z) {
        this.swShowAccuracy.setChecked(z);
    }

    @Override // calldial.be.loctracker.Compass.app.settings.SettingsContractCompass.View
    public void setShowMagneticView(boolean z) {
        this.swShowMagnetic.setChecked(z);
    }

    @Override // calldial.be.loctracker.Compass.ContractCompass.View
    public void showError(String str) {
        Toast.makeText(getApplicationContext(), str, 1).show();
    }

    @Override // calldial.be.loctracker.Compass.ContractCompass.View
    public void showError(int i) {
        Toast.makeText(getApplicationContext(), i, 1).show();
    }
}
