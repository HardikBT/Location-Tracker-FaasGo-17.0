package calldial.be.loctracker.Weather.utilities;

import calldial.be.loctracker.Weather.models.ForecastWeather;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/* loaded from: classes.dex */
public interface ApisWeather {
    @GET("forecast")
    Call<ForecastWeather> getWeatherForecastData(@Query("q") StringBuilder sb, @Query("APPID") String str, @Query("units") String str2);
}
