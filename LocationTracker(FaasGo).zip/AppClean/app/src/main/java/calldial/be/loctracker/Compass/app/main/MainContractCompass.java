package calldial.be.loctracker.Compass.app.main;

import calldial.be.loctracker.Compass.ContractCompass;

/* loaded from: classes.dex */
public interface MainContractCompass {

    /* loaded from: classes.dex */
    public interface UserActionsListener extends ContractCompass.UserActionsListener<View> {
    }

    /* loaded from: classes.dex */
    public interface View extends ContractCompass.View {
        void alertPoorAccuracy();

        void hideAlertPoorAccuracy();

        void keepScreenOn(boolean z);

        void showAccelerationView(boolean z);

        void showAccuracyView(boolean z);

        void showAccuracyViewSimple(boolean z);

        void showMagneticView(boolean z);

        void showMagneticViewSimple(boolean z);

        void showOrientationView(boolean z);

        void showSensorsNotFound();

        void showSimpleMode(boolean z);

        void updateAccuracy(int i);

        void updateAccuracySimple(int i);

        void updateLinearAcceleration(float f, float f2);

        void updateMagneticField(float f);

        void updateMagneticFieldSimple(float f);

        void updateOrientation(float f, float f2);

        void updateRotation(float f);
    }
}
