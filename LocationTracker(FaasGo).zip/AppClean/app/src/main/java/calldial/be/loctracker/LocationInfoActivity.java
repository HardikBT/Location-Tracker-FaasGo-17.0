package calldial.be.loctracker;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.core.widget.NestedScrollView;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.appbar.AppBarLayout;

import calldial.be.loctracker.Compass.app.main.MainActivityCompass;
import calldial.be.loctracker.GoogleMap.LiveLocationMapActivity;
import calldial.be.loctracker.LiveLocationFromLL.LiveLocationFromLlActivity;
import calldial.be.loctracker.LocationFromIP.LocationFromIpActivity;
import calldial.be.loctracker.MagicBold.AllAdsKeyPlace;
import calldial.be.loctracker.MagicBold.AppPrefrence;
import calldial.be.loctracker.MagicQG.QG;
import calldial.be.loctracker.Weather.activities.SplashActivityWeather;

/* loaded from: classes.dex */
public class LocationInfoActivity extends AppCompatActivity {
    public static boolean IS_DOWN = true;
    public static boolean IS_UP = true;
    AppBarLayout appbarlay_tool;
    ImageView btn_compass_map;
    ImageView btn_current_location_ll;
    ImageView btn_ip_location;
    ImageView btn_live_location_google_map;
    ImageView btn_live_weather;
    ImageView btn_traffic_finder_google_map;
    Animation down_anim_toolbar;
    ImageView imgDrawerLines;
    LinearLayout iv_moreads;
    private DrawerLayout mDrawerLayout;
    NestedScrollView nested_scroll;
    Animation up_anim_toolbar;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_location_info);
        AllAdsKeyPlace.ShowInterstitialAdsOnCreate(this);
        AllAdsKeyPlace.ShowNativeAd(this, (ViewGroup) findViewById(R.id.nativeContainer));
        this.iv_moreads = (LinearLayout) findViewById(R.id.iv_moreads);
        if (Common.isNetworkConnected(this) && new AppPrefrence(getApplicationContext()).getQureka_ADS().equalsIgnoreCase("on")) {
            this.iv_moreads.setVisibility(0);
        }
        this.iv_moreads.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LocationInfoActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                QG.openQGAlternate(LocationInfoActivity.this);
            }
        });
        this.mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        ImageView imageView = (ImageView) findViewById(R.id.imgDrawerLines);
        this.imgDrawerLines = imageView;
        Common.Animation(imageView);
        this.imgDrawerLines.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LocationInfoActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (LocationInfoActivity.this.mDrawerLayout.isDrawerOpen(3)) {
                    LocationInfoActivity.this.mDrawerLayout.closeDrawer(5);
                } else {
                    LocationInfoActivity.this.mDrawerLayout.openDrawer(3);
                }
            }
        });
        findViewById(R.id.llhomeapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LocationInfoActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                LocationInfoActivity.this.mDrawerLayout.closeDrawers();
                LocationInfoActivity.this.startActivity(new Intent(LocationInfoActivity.this, DashboardActivity.class));
            }
        });
        findViewById(R.id.llrateapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LocationInfoActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                LocationInfoActivity.this.mDrawerLayout.closeDrawers();
                Common.showRateDialog(LocationInfoActivity.this);
            }
        });
        findViewById(R.id.llshareapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LocationInfoActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                LocationInfoActivity.this.mDrawerLayout.closeDrawers();
                Common.ShareApp(LocationInfoActivity.this);
            }
        });
        findViewById(R.id.llpolicy__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LocationInfoActivity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                LocationInfoActivity.this.mDrawerLayout.closeDrawers();
                Common.showPrivacyDialog(LocationInfoActivity.this);
            }
        });
        findViewById(R.id.llmoreapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LocationInfoActivity.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                LocationInfoActivity.this.mDrawerLayout.closeDrawers();
                LocationInfoActivity.this.startActivity(new Intent(LocationInfoActivity.this, MoreAdActivity.class));
            }
        });
        this.btn_live_location_google_map = (ImageView) findViewById(R.id.btn_live_location_google_map);
        this.btn_live_weather = (ImageView) findViewById(R.id.btn_live_weather);
        this.btn_compass_map = (ImageView) findViewById(R.id.btn_compass_map);
        this.btn_traffic_finder_google_map = (ImageView) findViewById(R.id.btn_traffic_finder_google_map);
        this.btn_current_location_ll = (ImageView) findViewById(R.id.btn_current_location_ll);
        this.btn_ip_location = (ImageView) findViewById(R.id.btn_ip_location);
        Common.Animation(this.btn_live_location_google_map);
        Common.Animation(this.btn_live_weather);
        Common.Animation(this.btn_compass_map);
        Common.Animation(this.btn_traffic_finder_google_map);
        Common.Animation(this.btn_current_location_ll);
        Common.Animation(this.btn_ip_location);
        this.appbarlay_tool = (AppBarLayout) findViewById(R.id.appbarlay_tool);
        this.nested_scroll = (NestedScrollView) findViewById(R.id.nested_scroll);
        this.down_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.down_anim_toolbar);
        this.up_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.up_anim_toolbar);
        NestedScrollView nestedScrollView = this.nested_scroll;
        if (nestedScrollView != null) {
            nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() { // from class: calldial.be.loctracker.LocationInfoActivity.8
                @Override // androidx.core.widget.NestedScrollView.OnScrollChangeListener
                public void onScrollChange(NestedScrollView nestedScrollView2, int i, int i2, int i3, int i4) {
                    if (i2 > i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling DOWN");
                        if (LocationInfoActivity.IS_UP) {
                            LocationInfoActivity.this.appbarlay_tool.startAnimation(LocationInfoActivity.this.up_anim_toolbar);
                            LocationInfoActivity.IS_UP = false;
                            LocationInfoActivity.IS_DOWN = true;
                        }
                    }
                    if (i2 < i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling UP");
                        if (LocationInfoActivity.IS_DOWN) {
                            LocationInfoActivity.this.appbarlay_tool.startAnimation(LocationInfoActivity.this.down_anim_toolbar);
                            LocationInfoActivity.IS_DOWN = false;
                            LocationInfoActivity.IS_UP = true;
                        }
                    }
                    if (i2 == 0) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to TOP SCROLL");
                    }
                    if (i2 == nestedScrollView2.getMeasuredHeight() - nestedScrollView2.getChildAt(0).getMeasuredHeight()) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to BOTTOM SCROLL");
                    }
                }
            });
        }
        this.btn_live_location_google_map.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LocationInfoActivity.9
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Intent intent = new Intent(LocationInfoActivity.this, LiveLocationMapActivity.class);
                intent.putExtra("IS_TRAFFIC_ENABLED", false);
                LocationInfoActivity.this.startActivity(intent);
            }
        });
        this.btn_live_weather.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LocationInfoActivity.10
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                LocationInfoActivity.this.startActivity(new Intent(LocationInfoActivity.this, SplashActivityWeather.class));
            }
        });
        this.btn_compass_map.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LocationInfoActivity.11
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                LocationInfoActivity.this.startActivity(new Intent(LocationInfoActivity.this, MainActivityCompass.class));
            }
        });
        this.btn_traffic_finder_google_map.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LocationInfoActivity.12
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Intent intent = new Intent(LocationInfoActivity.this, LiveLocationMapActivity.class);
                intent.putExtra("IS_TRAFFIC_ENABLED", true);
                LocationInfoActivity.this.startActivity(intent);
            }
        });
        this.btn_current_location_ll.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LocationInfoActivity.13
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                LocationInfoActivity.this.startActivity(new Intent(LocationInfoActivity.this, LiveLocationFromLlActivity.class));
            }
        });
        this.btn_ip_location.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.LocationInfoActivity.14
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                LocationInfoActivity.this.startActivity(new Intent(LocationInfoActivity.this, LocationFromIpActivity.class));
            }
        });
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (this.mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            this.mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            AllAdsKeyPlace.CloseActivityWithAds(this, "true");
        }
    }
}
