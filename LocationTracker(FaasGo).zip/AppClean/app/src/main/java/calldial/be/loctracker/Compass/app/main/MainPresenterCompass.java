package calldial.be.loctracker.Compass.app.main;

import calldial.be.loctracker.Compass.data.PrefsCompass;
import calldial.be.loctracker.Compass.sensor.SensorsContractCompass;

/* loaded from: classes.dex */
public class MainPresenterCompass implements MainContractCompass.UserActionsListener {
    private boolean isSimple = false;
    private final PrefsCompass prefs;
    private SensorsContractCompass.Sensors sensors;
    private SensorsContractCompass.SensorsCallback sensorsCallback;
    private MainContractCompass.View view;

    public MainPresenterCompass(PrefsCompass prefsCompass, SensorsContractCompass.Sensors sensors) {
        this.prefs = prefsCompass;
        this.sensors = sensors;
    }

    public void bindView(MainContractCompass.View view) {
        this.view = view;
        boolean isSimpleMode = this.prefs.isSimpleMode();
        this.isSimple = isSimpleMode;
        this.view.showSimpleMode(isSimpleMode);
        this.view.updateAccuracySimple(0);
        this.view.keepScreenOn(this.prefs.isKeepScreenOn());
        this.view.showAccelerationView(this.prefs.isShowAcceleration());
        this.view.showOrientationView(this.prefs.isShowOrientation());
        if (this.isSimple) {
            this.view.showAccuracyViewSimple(this.prefs.isShowAccuracy());
            this.view.showMagneticViewSimple(this.prefs.isShowMagnetic());
            this.view.updateMagneticFieldSimple(0.0f);
        } else {
            this.view.showAccuracyView(this.prefs.isShowAccuracy());
            this.view.showMagneticView(this.prefs.isShowMagnetic());
            this.view.updateMagneticField(0.0f);
        }
        if (this.sensorsCallback == null) {
            this.sensorsCallback = new SensorsContractCompass.SensorsCallback() { // from class: calldial.be.loctracker.Compass.app.main.MainPresenterCompass.1
                @Override // calldial.be.loctracker.Compass.sensor.SensorsContractCompass.SensorsCallback
                public void onRotationChange(float f, float f2, float f3) {
                    if (MainPresenterCompass.this.view != null) {
                        MainPresenterCompass.this.view.updateRotation(f);
                        MainPresenterCompass.this.view.updateOrientation(f2, f3);
                    }
                }

                @Override // calldial.be.loctracker.Compass.sensor.SensorsContractCompass.SensorsCallback
                public void onMagneticFieldChange(float f) {
                    if (MainPresenterCompass.this.view == null) {
                        return;
                    }
                    if (MainPresenterCompass.this.isSimple) {
                        MainPresenterCompass.this.view.updateMagneticFieldSimple(f);
                    } else {
                        MainPresenterCompass.this.view.updateMagneticField(f);
                    }
                }

                @Override // calldial.be.loctracker.Compass.sensor.SensorsContractCompass.SensorsCallback
                public void onLinearAccelerationChange(float f, float f2, float f3) {
                    if (MainPresenterCompass.this.view != null) {
                        MainPresenterCompass.this.view.updateLinearAcceleration(f, f2);
                    }
                }

                @Override // calldial.be.loctracker.Compass.sensor.SensorsContractCompass.SensorsCallback
                public void onAccuracyChanged(int i) {
                    if (MainPresenterCompass.this.view != null) {
                        if (MainPresenterCompass.this.isSimple) {
                            MainPresenterCompass.this.view.updateAccuracySimple(i);
                        } else {
                            MainPresenterCompass.this.view.updateAccuracy(i);
                        }
                        if (i == 0 || i == 1 || i == 2) {
                            MainPresenterCompass.this.view.alertPoorAccuracy();
                        } else if (i == 3) {
                            MainPresenterCompass.this.view.hideAlertPoorAccuracy();
                        }
                    }
                }

                @Override // calldial.be.loctracker.Compass.sensor.SensorsContractCompass.SensorsCallback
                public void onSensorsNotFound() {
                    if (MainPresenterCompass.this.view != null) {
                        MainPresenterCompass.this.view.showSensorsNotFound();
                    }
                }
            };
        }
        this.sensors.setEnergySavingMode(this.prefs.isEnergySavingMode());
        this.sensors.setSensorsCallback(this.sensorsCallback);
        this.sensors.start();
    }

    @Override // calldial.be.loctracker.Compass.ContractCompass.UserActionsListener
    public void unbindView() {
        this.view = null;
        this.sensors.stop();
    }
}
