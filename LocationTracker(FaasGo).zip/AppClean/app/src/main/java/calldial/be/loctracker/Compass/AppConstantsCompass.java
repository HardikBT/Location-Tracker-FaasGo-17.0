package calldial.be.loctracker.Compass;

/* loaded from: classes.dex */
public class AppConstantsCompass {
    public static final String APPLICATION_NAME = "AiryCompass";
    public static final String REQUESTS_RECEIVER = "dmitriy.ponomarenko.ua@gmail.com";
}
