package calldial.be.loctracker.Compass.util;

import android.view.View;
import android.view.animation.AnimationUtils;

/* loaded from: classes.dex */
public class AnimationUtilCompass {
    private AnimationUtilCompass() {
    }

    public static void viewRotationAnimation(View view, long j) {
        view.animate().rotation(180.0f).setDuration(j).setInterpolator(AnimationUtils.loadInterpolator(view.getContext(), 17563654)).start();
    }

    public static void viewBackRotationAnimation(View view, long j) {
        view.animate().rotation(0.0f).setDuration(j).setInterpolator(AnimationUtils.loadInterpolator(view.getContext(), 17563654)).start();
    }
}
