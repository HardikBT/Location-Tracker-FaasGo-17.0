package calldial.be.loctracker.Compass.sensor;

/* loaded from: classes.dex */
public interface SensorsContractCompass {

    /* loaded from: classes.dex */
    public interface Sensors {
        void setEnergySavingMode(boolean z);

        void setSensorsCallback(SensorsCallback sensorsCallback);

        void start();

        void stop();
    }

    /* loaded from: classes.dex */
    public interface SensorsCallback {
        void onAccuracyChanged(int i);

        void onLinearAccelerationChange(float f, float f2, float f3);

        void onMagneticFieldChange(float f);

        void onRotationChange(float f, float f2, float f3);

        void onSensorsNotFound();
    }
}
