package calldial.be.loctracker.Compass.data;

/* loaded from: classes.dex */
public interface PrefsCompass {
    void firstRunExecuted();

    int getThemeColor();

    boolean isEnergySavingMode();

    boolean isFirstRun();

    boolean isKeepScreenOn();

    boolean isShowAcceleration();

    boolean isShowAccuracy();

    boolean isShowMagnetic();

    boolean isShowOrientation();

    boolean isSimpleMode();

    void setAppThemeColor(int i);

    void setEnergySavingMode(boolean z);

    void setKeepScreenOn(boolean z);

    void setShowAcceleration(boolean z);

    void setShowAccuracy(boolean z);

    void setShowMagnetic(boolean z);

    void setShowOrientation(boolean z);

    void setSimpleMode(boolean z);
}
