package calldial.be.loctracker.Weather.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import calldial.be.loctracker.R;
import calldial.be.loctracker.Weather.models.DataObjectWeather;
import calldial.be.loctracker.Weather.utilities.ConstantsWeather;

/* loaded from: classes.dex */
public class CardAdapterWeather extends RecyclerView.Adapter<CardAdapterWeather.CardViewHolder> {
    private List<DataObjectWeather> dataSet;

    public CardAdapterWeather(List<DataObjectWeather> list) {
        this.dataSet = list;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public CardViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new CardViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.view_card_weather, viewGroup, false));
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:57:0x01b6, code lost:
        if (r2.equals("01d") == false) goto L_0x00d7;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void onBindViewHolder(CardViewHolder cardViewHolder, int i) {
        DataObjectWeather dataObjectWeather = this.dataSet.get(i);
        cardViewHolder.timeStamp.setText(getTime(Long.valueOf(dataObjectWeather.getDt() * 1000)));
        char c = 0;
        cardViewHolder.textViewDescription.setText(dataObjectWeather.getWeather().get(0).getDescription());
        TextView textView = cardViewHolder.textViewWind;
        textView.setText("Wind: " + dataObjectWeather.getWind().getSpeed() + " m/s");
        TextView textView2 = cardViewHolder.textViewPressure;
        textView2.setText("Pressure: " + dataObjectWeather.getMain().getPressure() + " hPa");
        TextView textView3 = cardViewHolder.textViewHumidity;
        textView3.setText("Humidity: " + dataObjectWeather.getMain().getHumidity() + " %");
        TextView textView4 = cardViewHolder.textViewTemperature;
        textView4.setText(dataObjectWeather.getMain().getTemp() + ConstantsWeather.TEMP_UNIT);
        String icon = dataObjectWeather.getWeather().get(0).getIcon();
        icon.hashCode();
        switch (icon.hashCode()) {
            case 47747:
                break;
            case 47757:
                if (icon.equals("01n")) {
                    c = 1;
                    break;
                }
                c = 65535;
                break;
            case 47778:
                if (icon.equals("02d")) {
                    c = 2;
                    break;
                }
                c = 65535;
                break;
            case 47788:
                if (icon.equals("02n")) {
                    c = 3;
                    break;
                }
                c = 65535;
                break;
            case 47809:
                if (icon.equals("03d")) {
                    c = 4;
                    break;
                }
                c = 65535;
                break;
            case 47819:
                if (icon.equals("03n")) {
                    c = 5;
                    break;
                }
                c = 65535;
                break;
            case 47840:
                if (icon.equals("04d")) {
                    c = 6;
                    break;
                }
                c = 65535;
                break;
            case 47850:
                if (icon.equals("04n")) {
                    c = 7;
                    break;
                }
                c = 65535;
                break;
            case 47995:
                if (icon.equals("09d")) {
                    c = '\b';
                    break;
                }
                c = 65535;
                break;
            case 48005:
                if (icon.equals("09n")) {
                    c = '\t';
                    break;
                }
                c = 65535;
                break;
            case 48677:
                if (icon.equals("10d")) {
                    c = '\n';
                    break;
                }
                c = 65535;
                break;
            case 48687:
                if (icon.equals("10n")) {
                    c = 11;
                    break;
                }
                c = 65535;
                break;
            case 48708:
                if (icon.equals("11d")) {
                    c = '\f';
                    break;
                }
                c = 65535;
                break;
            case 48718:
                if (icon.equals("11n")) {
                    c = '\r';
                    break;
                }
                c = 65535;
                break;
            case 48770:
                if (icon.equals("13d")) {
                    c = 14;
                    break;
                }
                c = 65535;
                break;
            case 48780:
                if (icon.equals("13n")) {
                    c = 15;
                    break;
                }
                c = 65535;
                break;
            case 48832:
                if (icon.equals("15d")) {
                    c = 16;
                    break;
                }
                c = 65535;
                break;
            case 48842:
                if (icon.equals("15n")) {
                    c = 17;
                    break;
                }
                c = 65535;
                break;
            default:
                c = 65535;
                break;
        }
        switch (c) {
            case 0:
                cardViewHolder.imageViewIcon.setImageResource(R.drawable.ic_weather_clear_sky);
                cardViewHolder.cardView.setBackgroundResource(R.color.color_clear_and_sunny);
                return;
            case 1:
                cardViewHolder.imageViewIcon.setImageResource(R.drawable.ic_weather_clear_sky);
                cardViewHolder.cardView.setBackgroundResource(R.color.color_clear_and_sunny);
                return;
            case 2:
                cardViewHolder.imageViewIcon.setImageResource(R.drawable.ic_weather_few_cloud);
                cardViewHolder.cardView.setBackgroundResource(R.color.color_partly_cloudy);
                return;
            case 3:
                cardViewHolder.imageViewIcon.setImageResource(R.drawable.ic_weather_few_cloud);
                cardViewHolder.cardView.setBackgroundResource(R.color.color_partly_cloudy);
                return;
            case 4:
                cardViewHolder.imageViewIcon.setImageResource(R.drawable.ic_weather_scattered_clouds);
                cardViewHolder.cardView.setBackgroundResource(R.color.color_gusty_winds);
                return;
            case 5:
                cardViewHolder.imageViewIcon.setImageResource(R.drawable.ic_weather_scattered_clouds);
                cardViewHolder.cardView.setBackgroundResource(R.color.color_gusty_winds);
                return;
            case 6:
                cardViewHolder.imageViewIcon.setImageResource(R.drawable.ic_weather_broken_clouds);
                cardViewHolder.cardView.setBackgroundResource(R.color.color_cloudy_overnight);
                return;
            case 7:
                cardViewHolder.imageViewIcon.setImageResource(R.drawable.ic_weather_broken_clouds);
                cardViewHolder.cardView.setBackgroundResource(R.color.color_cloudy_overnight);
                return;
            case '\b':
                cardViewHolder.imageViewIcon.setImageResource(R.drawable.ic_weather_shower_rain);
                cardViewHolder.cardView.setBackgroundResource(R.color.color_hail_stroms);
                return;
            case '\t':
                cardViewHolder.imageViewIcon.setImageResource(R.drawable.ic_weather_shower_rain);
                cardViewHolder.cardView.setBackgroundResource(R.color.color_hail_stroms);
                return;
            case '\n':
                cardViewHolder.imageViewIcon.setImageResource(R.drawable.ic_weather_rain);
                cardViewHolder.cardView.setBackgroundResource(R.color.color_heavy_rain);
                return;
            case 11:
                cardViewHolder.imageViewIcon.setImageResource(R.drawable.ic_weather_rain);
                cardViewHolder.cardView.setBackgroundResource(R.color.color_heavy_rain);
                return;
            case '\f':
                cardViewHolder.imageViewIcon.setImageResource(R.drawable.ic_weather_thunderstorm);
                cardViewHolder.cardView.setBackgroundResource(R.color.color_thunderstroms);
                return;
            case '\r':
                cardViewHolder.imageViewIcon.setImageResource(R.drawable.ic_weather_thunderstorm);
                cardViewHolder.cardView.setBackgroundResource(R.color.color_thunderstroms);
                return;
            case 14:
                cardViewHolder.imageViewIcon.setImageResource(R.drawable.ic_weather_snow);
                cardViewHolder.cardView.setBackgroundResource(R.color.color_snow);
                return;
            case 15:
                cardViewHolder.imageViewIcon.setImageResource(R.drawable.ic_weather_snow);
                cardViewHolder.cardView.setBackgroundResource(R.color.color_snow);
                return;
            case 16:
                cardViewHolder.imageViewIcon.setImageResource(R.drawable.ic_weather_mist);
                cardViewHolder.cardView.setBackgroundResource(R.color.color_mix_snow_and_rain);
                return;
            case 17:
                cardViewHolder.imageViewIcon.setImageResource(R.drawable.ic_weather_mist);
                cardViewHolder.cardView.setBackgroundResource(R.color.color_mix_snow_and_rain);
                return;
            default:
                return;
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.dataSet.size();
    }

    private String getTime(Long l) {
        return new SimpleDateFormat("E, dd.MM.yyyy - hh:mm a").format(new Date(l.longValue()));
    }

    /* loaded from: classes.dex */
    public static class CardViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        ImageView imageViewIcon;
        TextView textViewDescription;
        TextView textViewHumidity;
        TextView textViewPressure;
        TextView textViewTemperature;
        TextView textViewWind;
        TextView timeStamp;

        public CardViewHolder(View view) {
            super(view);
            this.cardView = (CardView) view.findViewById(R.id.card_view);
            this.timeStamp = (TextView) view.findViewById(R.id.timeStamp);
            this.textViewDescription = (TextView) view.findViewById(R.id.textDescription);
            this.textViewWind = (TextView) view.findViewById(R.id.wind);
            this.textViewPressure = (TextView) view.findViewById(R.id.pressure);
            this.textViewHumidity = (TextView) view.findViewById(R.id.humidity);
            this.textViewTemperature = (TextView) view.findViewById(R.id.temp);
            this.imageViewIcon = (ImageView) view.findViewById(R.id.icon);
        }
    }
}
