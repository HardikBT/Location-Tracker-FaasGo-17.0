package calldial.be.loctracker.MagicBold;

/* loaded from: classes.dex */
public interface onInterstitialAdsClose {
    void onAdsClose();
}
