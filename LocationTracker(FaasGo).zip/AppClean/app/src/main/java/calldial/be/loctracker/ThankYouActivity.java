package calldial.be.loctracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import calldial.be.loctracker.MagicBold.AllAdsKeyPlace;
import calldial.be.loctracker.MagicBold.AppPrefrence;
import calldial.be.loctracker.MagicQG.QG;


/* loaded from: classes.dex */
public class ThankYouActivity extends AppCompatActivity {
    RelativeLayout llMore;
    TextView llNo;
    RelativeLayout llRate;
    RelativeLayout llShare;
    TextView llYes;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_thank_you);
        AllAdsKeyPlace.ShowInterstitialAdsOnCreate(this);
        AllAdsKeyPlace.ShowNativeAd(this, (ViewGroup) findViewById(R.id.adsContainer));
        this.llShare = (RelativeLayout) findViewById(R.id.ll_share);
        this.llMore = (RelativeLayout) findViewById(R.id.ll_more);
        this.llRate = (RelativeLayout) findViewById(R.id.ll_rate);
        this.llYes = (TextView) findViewById(R.id.tv_yes);
        this.llNo = (TextView) findViewById(R.id.tv_no);
        Common.Animation((ViewGroup) this.llShare);
        Common.Animation((ViewGroup) this.llMore);
        Common.Animation((ViewGroup) this.llRate);
        Common.Animation(this.llYes);
        Common.Animation(this.llNo);
        this.llShare.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.ThankYouActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("text/plain");
                intent.putExtra("android.intent.extra.SUBJECT", ThankYouActivity.this.getString(R.string.app_name));
                intent.putExtra("android.intent.extra.TEXT", "\nLet me recommend you this application\n\nhttps://play.google.com/store/apps/details?id=" + ThankYouActivity.this.getPackageName());
                ThankYouActivity.this.startActivity(Intent.createChooser(intent, "Share App using"));
            }
        });
        this.llMore.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.ThankYouActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                ThankYouActivity.this.startActivity(new Intent(ThankYouActivity.this, MoreAdActivity.class));
            }
        });
        this.llRate.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.ThankYouActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Common.showRateDialog(ThankYouActivity.this);
            }
        });
        this.llYes.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.ThankYouActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                ThankYouActivity.this.onBackPressed();
            }
        });
        this.llNo.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.ThankYouActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                ThankYouActivity.this.startActivity(new Intent(ThankYouActivity.this, DashboardActivity.class).putExtra("my_boolean_key", true));
            }
        });
        if (Common.isNetworkConnected(this) && new AppPrefrence(getApplicationContext()).getQureka_ADS().equalsIgnoreCase("on")) {
            findViewById(R.id.lottie_gift).setVisibility(0);
        }
        findViewById(R.id.lottie_gift).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.ThankYouActivity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                QG.openQGAlternate(ThankYouActivity.this);
            }
        });
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        finishAffinity();
    }
}
