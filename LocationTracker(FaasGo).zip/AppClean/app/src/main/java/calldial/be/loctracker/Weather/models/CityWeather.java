package calldial.be.loctracker.Weather.models;

import com.facebook.appevents.UserDataStore;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/* loaded from: classes.dex */
public class CityWeather {
    @SerializedName("coord")
    @Expose
    private CoordWeather coord;
    @SerializedName(UserDataStore.COUNTRY)
    @Expose
    private String country;
    @SerializedName("id")
    @Expose
    private int id;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("population")
    @Expose
    private int population;

    public int getId() {
        return this.id;
    }

    public void setId(int i) {
        this.id = i;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String str) {
        this.name = str;
    }

    public CoordWeather getCoord() {
        return this.coord;
    }

    public void setCoord(CoordWeather coordWeather) {
        this.coord = coordWeather;
    }

    public String getCountry() {
        return this.country;
    }

    public void setCountry(String str) {
        this.country = str;
    }

    public int getPopulation() {
        return this.population;
    }

    public void setPopulation(int i) {
        this.population = i;
    }
}
