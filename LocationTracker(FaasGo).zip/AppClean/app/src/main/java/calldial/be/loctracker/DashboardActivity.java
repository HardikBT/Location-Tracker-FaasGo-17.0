package calldial.be.loctracker;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.core.widget.NestedScrollView;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.appbar.AppBarLayout;

import calldial.be.loctracker.MagicBold.AllAdsKeyPlace;
import calldial.be.loctracker.MagicBold.AppPrefrence;
import calldial.be.loctracker.MagicCode.GlobalMaintainer;
import calldial.be.loctracker.MagicQG.QG;

/* loaded from: classes.dex */
public class DashboardActivity extends AppCompatActivity {
    public static boolean IS_DOWN = true;
    public static boolean IS_UP = true;
    AppBarLayout appbarlay_tool;
    Animation down_anim_toolbar;
    ImageView imgDrawerLines;
    LinearLayout iv_moreads;
    LinearLayout ll_more;
    LinearLayout ll_rate;
    LinearLayout ll_share;
    LinearLayout ll_start;
    private DrawerLayout mDrawerLayout;
    NestedScrollView nested_scroll;
    Animation up_anim_toolbar;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_dashboard);
        if (getIntent().getBooleanExtra("my_boolean_key", false)) {
            AllAdsKeyPlace.ShowInterstitialAdsOnCreate(this);
        }
        AllAdsKeyPlace.ShowNativeAd(this, (ViewGroup) findViewById(R.id.nativeContainer));
//        QG.showAutoScrollBanner(this, (ViewGroup) findViewById(R.id.qg_autoscroll_banner));

        this.iv_moreads = (LinearLayout) findViewById(R.id.iv_moreads);
        if (Common.isNetworkConnected(this) && new AppPrefrence(getApplicationContext()).getQureka_ADS().equalsIgnoreCase("on")) {
            this.iv_moreads.setVisibility(0);
        }
        this.iv_moreads.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.DashboardActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                QG.openQGAlternate(DashboardActivity.this);
            }
        });
        this.mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        ImageView imageView = (ImageView) findViewById(R.id.imgDrawerLines);
        this.imgDrawerLines = imageView;
        Common.Animation(imageView);
        this.imgDrawerLines.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.DashboardActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (DashboardActivity.this.mDrawerLayout.isDrawerOpen(3)) {
                    DashboardActivity.this.mDrawerLayout.closeDrawer(5);
                } else {
                    DashboardActivity.this.mDrawerLayout.openDrawer(3);
                }
            }
        });
        findViewById(R.id.llhomeapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.DashboardActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                DashboardActivity.this.mDrawerLayout.closeDrawers();
            }
        });
        findViewById(R.id.llrateapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.DashboardActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                DashboardActivity.this.mDrawerLayout.closeDrawers();
                Common.showRateDialog(DashboardActivity.this);
            }
        });
        findViewById(R.id.llshareapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.DashboardActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                DashboardActivity.this.mDrawerLayout.closeDrawers();
                Common.ShareApp(DashboardActivity.this);
            }
        });
        findViewById(R.id.llpolicy__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.DashboardActivity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                DashboardActivity.this.mDrawerLayout.closeDrawers();
                Common.showPrivacyDialog(DashboardActivity.this);
            }
        });
        findViewById(R.id.llmoreapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.DashboardActivity.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                DashboardActivity.this.mDrawerLayout.closeDrawers();
                DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, MoreAdActivity.class));
            }
        });
        this.ll_start = (LinearLayout) findViewById(R.id.ll_start);
        this.ll_rate = (LinearLayout) findViewById(R.id.ll_rate);
        this.ll_share = (LinearLayout) findViewById(R.id.ll_share);
        this.ll_more = (LinearLayout) findViewById(R.id.ll_more);
        Common.Animation((ViewGroup) this.ll_start);
        Common.Animation((ViewGroup) this.ll_rate);
        Common.Animation((ViewGroup) this.ll_share);
        Common.Animation((ViewGroup) this.ll_more);
        this.appbarlay_tool = (AppBarLayout) findViewById(R.id.appbarlay_tool);
        this.nested_scroll = (NestedScrollView) findViewById(R.id.nested_scroll);
        this.down_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.down_anim_toolbar);
        this.up_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.up_anim_toolbar);
        NestedScrollView nestedScrollView = this.nested_scroll;
        if (nestedScrollView != null) {
            nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() { // from class: calldial.be.loctracker.DashboardActivity.8
                @Override // androidx.core.widget.NestedScrollView.OnScrollChangeListener
                public void onScrollChange(NestedScrollView nestedScrollView2, int i, int i2, int i3, int i4) {
                    if (i2 > i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling DOWN");
                        if (DashboardActivity.IS_UP) {
                            DashboardActivity.this.appbarlay_tool.startAnimation(DashboardActivity.this.up_anim_toolbar);
                            DashboardActivity.IS_UP = false;
                            DashboardActivity.IS_DOWN = true;
                        }
                    }
                    if (i2 < i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling UP");
                        if (DashboardActivity.IS_DOWN) {
                            DashboardActivity.this.appbarlay_tool.startAnimation(DashboardActivity.this.down_anim_toolbar);
                            DashboardActivity.IS_DOWN = false;
                            DashboardActivity.IS_UP = true;
                        }
                    }
                    if (i2 == 0) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to TOP SCROLL");
                    }
                    if (i2 == nestedScrollView2.getMeasuredHeight() - nestedScrollView2.getChildAt(0).getMeasuredHeight()) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to BOTTOM SCROLL");
                    }
                }
            });
        }
        this.ll_start.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.DashboardActivity.9
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, FreePremiumActivity.class));
            }
        });
        this.ll_rate.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.DashboardActivity.10
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Common.showRateDialog(DashboardActivity.this);
            }
        });
        this.ll_share.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.DashboardActivity.11
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Common.ShareApp(DashboardActivity.this);
            }
        });
        if (Common.isNetworkConnected(this) && new AppPrefrence(getApplicationContext()).getQureka_ADS().equalsIgnoreCase("on")) {
            this.ll_more.setVisibility(0);
        }
        this.ll_more.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.DashboardActivity.12
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                QG.openQGAlternate(DashboardActivity.this);
            }
        });
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (this.mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            this.mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            showBackDialog();
        }
    }

    public void showBackDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.layout_exit_dialog);
        dialog.setCancelable(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        dialog.getWindow().setLayout(-1, -2);
        AllAdsKeyPlace.ShowNativeBannerAd(this, (ViewGroup) dialog.findViewById(R.id.nativeContainer1));
        Button button = (Button) dialog.findViewById(R.id.btn_no);
        Button button2 = (Button) dialog.findViewById(R.id.btn_yes);
        ImageView imageView = (ImageView) dialog.findViewById(R.id.iv_rate);
        Common.Animation(button);
        Common.Animation(button2);
        Common.Animation(imageView);
        dialog.getWindow().setBackgroundDrawableResource(17170445);
        button.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.DashboardActivity.13
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        button2.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.DashboardActivity.14
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                dialog.dismiss();
                DashboardActivity.this.startActivity(new Intent(DashboardActivity.this, ThankYouActivity.class));
            }
        });
        imageView.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.DashboardActivity.15
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                dialog.dismiss();
                Common.showRateDialog(DashboardActivity.this);
            }
        });
        dialog.show();
    }
}
