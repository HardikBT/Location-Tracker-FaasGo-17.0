package calldial.be.loctracker.MagicBold;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

import calldial.be.loctracker.MagicQG.AdsQurekaDialog;

/* loaded from: classes.dex */
public class AllInterstitialAdsPriorityGroupTwo {
    private static InterstitialAd AMInterstitial = null;
    public static boolean FBCreateLoadedFlag = false;
    public static boolean FBCreateRequestFlag = false;
    private static String FinishTag = "";
    private static onInterstitialAdsClose adsListener1;
    private static AppPrefrence appPrefrence;
    private static Context mContext;

    public static void LoadInterstitialAd(Context context, String str) {
        try {
            mContext = context;
            AppPrefrence appPrefrence2 = new AppPrefrence(context);
            appPrefrence = appPrefrence2;
            if (appPrefrence2.getAds_On_Off().equalsIgnoreCase("on")) {
                MobileAds.initialize(context, new OnInitializationCompleteListener() { // from class: calldial.be.loctracker.MagicBold.AllInterstitialAdsPriorityGroupTwo.1
                    @Override
                    // com.google.android.gms.ads.initialization.OnInitializationCompleteListener
                    public void onInitializationComplete(InitializationStatus initializationStatus) {
                    }
                });
                MobileAds.setRequestConfiguration(new RequestConfiguration.Builder().setTestDeviceIds(AllAdsKeyPlace.TestDeviceID).build());
                if (!FBCreateLoadedFlag) {
                    Log.e("Ads1", "FB Req");
                    FinishTag = str;
                    FBCreateLoadedFlag = true;
                    FBCreateRequestFlag = true;
                    displayAdMobFourInAd();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void displayAdMobFourInAd() {
        AdRequest build = new AdRequest.Builder().build();
        try {
            Context context = mContext;
            InterstitialAd.load(context, new AppPrefrence(context).getAM_INTERTITIAL(), build, new InterstitialAdLoadCallback() { // from class: calldial.be.loctracker.MagicBold.AllInterstitialAdsPriorityGroupTwo.2
                public void onAdLoaded(InterstitialAd interstitialAd) {
                    super.onAdLoaded(interstitialAd);
                    InterstitialAd unused = AllInterstitialAdsPriorityGroupTwo.AMInterstitial = interstitialAd;
                    AllInterstitialAdsPriorityGroupTwo.FBCreateRequestFlag = false;
                    Log.e("Intertitial_four", "onAdLoaded.");
                    AllInterstitialAdsPriorityGroupTwo.AMCallBack();
                }

                @Override // com.google.android.gms.ads.AdLoadCallback
                public void onAdFailedToLoad(LoadAdError loadAdError) {
                    super.onAdFailedToLoad(loadAdError);
                    Log.e("Intertitial_four", "Error." + loadAdError.getCode() + "-" + loadAdError.toString());
                    AllInterstitialAdsPriorityGroupTwo.LoadSDKInterstitialAd();
                    InterstitialAd unused = AllInterstitialAdsPriorityGroupTwo.AMInterstitial = null;
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void AMCallBack() {
        AMInterstitial.setFullScreenContentCallback(new FullScreenContentCallback() { // from class: calldial.be.loctracker.MagicBold.AllInterstitialAdsPriorityGroupTwo.3
            @Override // com.google.android.gms.ads.FullScreenContentCallback
            public void onAdDismissedFullScreenContent() {
                if (!AllInterstitialAdsPriorityGroupTwo.FinishTag.equals("Fail")) {
                    AllInterstitialAdsPriorityGroupTwo.adsListener1.onAdsClose();
                }
                AllAdsKeyPlace.Strcheckad = "StrClosed";
                Log.e("TAG", "The ad was dismissed.");
                InterstitialAd unused = AllInterstitialAdsPriorityGroupTwo.AMInterstitial = null;
            }

            @Override // com.google.android.gms.ads.FullScreenContentCallback
            public void onAdFailedToShowFullScreenContent(AdError adError) {
                super.onAdFailedToShowFullScreenContent(adError);
                Log.e("TAG", "onAdFailedToShowFullScreenContent.");
                if (!AllInterstitialAdsPriorityGroupTwo.FinishTag.equals("Fail")) {
                    AllInterstitialAdsPriorityGroupTwo.adsListener1.onAdsClose();
                }
                AllAdsKeyPlace.Strcheckad = "StrClosed";
            }

            @Override // com.google.android.gms.ads.FullScreenContentCallback
            public void onAdShowedFullScreenContent() {
                Log.e("TAG", "The ad was shown.");
                if (AllAdsKeyPlace.Backprssornot == 0) {
                    AllAdsKeyPlace.FrontshowadsCounter++;
                } else {
                    AllAdsKeyPlace.BackshowadsCounter++;
                }
            }
        });
    }

    public static void ShowInterstitialAd(Context context, String str, onInterstitialAdsClose oninterstitialadsclose) {
        mContext = context;
        if (FBCreateLoadedFlag) {
            AllAdsKeyPlace.Strcheckad = "StrOpen";
            try {
                adsListener1 = oninterstitialadsclose;
                InterstitialAd interstitialAd = AMInterstitial;
                if (interstitialAd != null) {
                    FinishTag = str;
                    interstitialAd.show((Activity) context);
                    FBCreateLoadedFlag = false;
                    AllInterstitialAdsPriority1GroupTwo.LoadInterstitialAd(mContext, FinishTag);
                    return;
                }
                FBCreateLoadedFlag = false;
                FinishTag = str;
                if (appPrefrence.getQureka_ADS().equalsIgnoreCase("on")) {
                    Log.e("@@TAG", "ShowInterstitialAd: Qureka");
                    new AdsQurekaDialog((Activity) context, adsListener1).show();
                } else if (!FinishTag.equals("Fail")) {
                    adsListener1.onAdsClose();
                }
                AllInterstitialAdsPriority1GroupTwo.LoadInterstitialAd(mContext, FinishTag);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            adsListener1 = oninterstitialadsclose;
            FinishTag = str;
            AllInterstitialAdsPriority1GroupTwo.LoadInterstitialAd(context, str);
        }
    }

    public static void ChangeActivityWithAds(final Activity activity, final Class cls, final String str) {
        if (!FBCreateRequestFlag) {
            ShowInterstitialAd(activity, str, new onInterstitialAdsClose() { // from class: calldial.be.loctracker.MagicBold.AllInterstitialAdsPriorityGroupTwo.4
                @Override // calldial.be.loctracker.MagicBold.onInterstitialAdsClose
                public void onAdsClose() {
                    activity.startActivity(new Intent(activity, cls));
                    if (str.equals("true") || str.equals("True") || str.equals("TRUE")) {
                        activity.finish();
                    }
                }
            });
            return;
        }
        activity.startActivity(new Intent(activity, cls));
        if (str.equals("true") || str.equals("True") || str.equals("TRUE")) {
            activity.finish();
        }
    }

    public static void CloseActivityWithAds(final Activity activity, final String str) {
        if (!FBCreateRequestFlag) {
            ShowInterstitialAd(activity, str, new onInterstitialAdsClose() { // from class: calldial.be.loctracker.MagicBold.AllInterstitialAdsPriorityGroupTwo.5
                @Override // calldial.be.loctracker.MagicBold.onInterstitialAdsClose
                public void onAdsClose() {
                    if (str.equals("true") || str.equals("True") || str.equals("TRUE")) {
                        activity.finish();
                    }
                }
            });
        } else if (str.equals("true") || str.equals("True") || str.equals("TRUE")) {
            activity.finish();
        }
    }

    public static void ShowAdsOnCreate(Context context) {
        if (!FBCreateRequestFlag) {
            ShowInterstitialAd(context, "false", new onInterstitialAdsClose() { // from class: calldial.be.loctracker.MagicBold.AllInterstitialAdsPriorityGroupTwo.6
                @Override // calldial.be.loctracker.MagicBold.onInterstitialAdsClose
                public void onAdsClose() {
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void LoadSDKInterstitialAd() {
        try {
            Log.e("sdkInter1", "Load");
            FBCreateRequestFlag = false;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
