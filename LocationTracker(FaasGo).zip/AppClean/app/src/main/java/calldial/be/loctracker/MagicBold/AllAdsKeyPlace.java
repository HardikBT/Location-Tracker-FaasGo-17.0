package calldial.be.loctracker.MagicBold;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;

import java.util.Arrays;
import java.util.List;

import calldial.be.loctracker.R;

/* loaded from: classes.dex */
public class AllAdsKeyPlace {
    public static int DirectCall = 0;
    public static String Strcheckad = "";
    public static String TAG = "MagicCodeAM";
    public static int betaCounter;
    public static int intertitialCounter;
    public static NativeAd nativeBigAd;
    public static NativeAd nativeSmallAd;
    public static int sdkCounter;
    public static List<String> TestDeviceID = Arrays.asList("4F61F4EE6963DED455BB87F1A458613A");
    public static String CF = "";
    public static String CURL = "";
    public static String VideoURL = "";
    public static String RoomId = "";
    public static int FrontshowadsCounter = 0;
    public static int BackshowadsCounter = 0;
    public static int Backprssornot = 0;

    public static void LoadInterstitialAds(Context context) {
        if (new AppPrefrence(context).getAds_On_Off().equalsIgnoreCase("on")) {
            AllInterstitialAdsPriorityGroupTwo.LoadInterstitialAd(context, "Fail");
            AllInterstitialAdsPriority1GroupTwo.LoadInterstitialAd(context, "Fail");
        }
    }

    public static void ShowInterstitialAdsOnCreate(Context context) {
        if (new AppPrefrence(context).getAds_On_Off().equalsIgnoreCase("on")) {
            Backprssornot = 0;
            if (new AppPrefrence(context).getFront_cnt() == 0) {
                return;
            }
            if (FrontshowadsCounter % new AppPrefrence(context).getFront_cnt() == 0) {
                int i = intertitialCounter;
                if (i == 0) {
                    AllInterstitialAdsPriorityGroupTwo.ShowAdsOnCreate(context);
                    intertitialCounter++;
                } else if (i == 1) {
                    AllInterstitialAdsPriority1GroupTwo.ShowAdsOnCreate(context);
                    intertitialCounter = 0;
                }
            } else {
                FrontshowadsCounter++;
            }
        }
    }

    public static void ChangeActivityWithAds(Activity activity, Class cls, String str) {
        if (new AppPrefrence(activity).getAds_On_Off().equalsIgnoreCase("on")) {
            int i = intertitialCounter;
            if (i == 0) {
                AllInterstitialAdsPriorityGroupTwo.ChangeActivityWithAds(activity, cls, str);
                intertitialCounter++;
            } else if (i == 1) {
                AllInterstitialAdsPriority1GroupTwo.ChangeActivityWithAds(activity, cls, str);
                intertitialCounter = 0;
            }
        } else {
            intertitialCounter = 0;
            activity.startActivity(new Intent(activity, cls));
            if (str.equals("true") || str.equals("True") || str.equals("TRUE")) {
                activity.finish();
            }
        }
    }

    public static void CloseActivityWithAds(Activity activity, String str) {
        if (new AppPrefrence(activity).getAds_On_Off().equalsIgnoreCase("on")) {
            Backprssornot = 1;
            if (!new AppPrefrence(activity).getBackPress_Priority().equalsIgnoreCase("Inter")) {
                intertitialCounter = 0;
                betaCounter = 0;
                sdkCounter = 0;
                if (str.equals("true") || str.equals("True") || str.equals("TRUE")) {
                    activity.finish();
                }
            } else if (new AppPrefrence(activity).getBack_cnt() != 0) {
                if (BackshowadsCounter % new AppPrefrence(activity).getBack_cnt() == 0) {
                    int i = intertitialCounter;
                    if (i == 0) {
                        AllInterstitialAdsPriorityGroupTwo.CloseActivityWithAds(activity, str);
                        intertitialCounter++;
                    } else if (i == 1) {
                        AllInterstitialAdsPriority1GroupTwo.CloseActivityWithAds(activity, str);
                        intertitialCounter = 0;
                    }
                } else {
                    BackshowadsCounter++;
                    if (str.equals("true") || str.equals("True") || str.equals("TRUE")) {
                        activity.finish();
                    }
                }
            } else if (str.equals("true") || str.equals("True") || str.equals("TRUE")) {
                activity.finish();
            }
        } else {
            intertitialCounter = 0;
            betaCounter = 0;
            sdkCounter = 0;
            if (str.equals("true") || str.equals("True") || str.equals("TRUE")) {
                activity.finish();
            }
        }
    }

    public static void ShowNativeAd(final Context context, final ViewGroup viewGroup) {
        final AppPrefrence appPrefrence = new AppPrefrence(context);
        if (appPrefrence.getAds_On_Off().equalsIgnoreCase("on")) {
            View inflate = LayoutInflater.from(context).inflate(R.layout.admob_temp_loading_native, viewGroup, false);
            viewGroup.removeAllViews();
            viewGroup.addView(inflate);
            if (!appPrefrence.getAM_NATIVE_BIG_HOME().equalsIgnoreCase("")) {
                AdLoader.Builder builder = new AdLoader.Builder(context, appPrefrence.getAM_NATIVE_BIG_HOME());
                builder.forNativeAd(new NativeAd.OnNativeAdLoadedListener() { // from class: calldial.be.loctracker.MagicBold.AllAdsKeyPlace.1
                    @Override // com.google.android.gms.ads.nativead.NativeAd.OnNativeAdLoadedListener
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        AllAdsKeyPlace.nativeBigAd = nativeAd;
                        NativeAdView nativeAdView = (NativeAdView) LayoutInflater.from(context).inflate(R.layout.admob_native_big, (ViewGroup) null);
                        nativeAdView.setMediaView((MediaView) nativeAdView.findViewById(R.id.ad_media));
                        if (AllAdsKeyPlace.nativeBigAd.getMediaContent().getAspectRatio() > 1.0f) {
                            ((MediaView) nativeAdView.findViewById(R.id.ad_media)).setImageScaleType(ImageView.ScaleType.FIT_XY);
                        } else {
                            ((MediaView) nativeAdView.findViewById(R.id.ad_media)).setImageScaleType(ImageView.ScaleType.CENTER_INSIDE);
                        }
                        nativeAdView.setHeadlineView(nativeAdView.findViewById(R.id.ad_headline));
                        nativeAdView.setBodyView(nativeAdView.findViewById(R.id.ad_body));
                        nativeAdView.setCallToActionView(nativeAdView.findViewById(R.id.ad_call_to_action));
                        nativeAdView.setIconView(nativeAdView.findViewById(R.id.ad_app_icon));
                        ((TextView) nativeAdView.getHeadlineView()).setText(AllAdsKeyPlace.nativeBigAd.getHeadline());
                        nativeAdView.getMediaView().setMediaContent(AllAdsKeyPlace.nativeBigAd.getMediaContent());
                        if (AllAdsKeyPlace.nativeBigAd.getBody() == null) {
                            nativeAdView.getBodyView().setVisibility(4);
                        } else {
                            nativeAdView.getBodyView().setVisibility(0);
                            ((TextView) nativeAdView.getBodyView()).setText(AllAdsKeyPlace.nativeBigAd.getBody());
                        }
                        if (AllAdsKeyPlace.nativeBigAd.getCallToAction() == null) {
                            nativeAdView.getCallToActionView().setVisibility(4);
                        } else {
                            nativeAdView.getCallToActionView().setVisibility(0);
                            ((Button) nativeAdView.getCallToActionView()).setText(AllAdsKeyPlace.nativeBigAd.getCallToAction());
                        }
                        if (AllAdsKeyPlace.nativeBigAd.getIcon() == null) {
                            nativeAdView.getIconView().setVisibility(8);
                        } else {
                            ((ImageView) nativeAdView.getIconView()).setImageDrawable(AllAdsKeyPlace.nativeBigAd.getIcon().getDrawable());
                            nativeAdView.getIconView().setVisibility(0);
                        }
                        nativeAdView.setNativeAd(AllAdsKeyPlace.nativeBigAd);
                        VideoController videoController = AllAdsKeyPlace.nativeBigAd.getMediaContent().getVideoController();
                        if (videoController.hasVideoContent()) {
                            videoController.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() { // from class: calldial.be.loctracker.MagicBold.AllAdsKeyPlace.1.1
                                @Override // com.google.android.gms.ads.VideoController.VideoLifecycleCallbacks
                                public void onVideoEnd() {
                                    super.onVideoEnd();
                                }
                            });
                        }
                        viewGroup.removeAllViews();
                        viewGroup.addView(nativeAdView);
                    }
                });
                builder.withNativeAdOptions(new NativeAdOptions.Builder().setVideoOptions(new VideoOptions.Builder().setStartMuted(false).build()).build());
                builder.withAdListener(new AdListener() { // from class: calldial.be.loctracker.MagicBold.AllAdsKeyPlace.2
                    @Override // com.google.android.gms.ads.AdListener
                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        String str = AllAdsKeyPlace.TAG;
                        Log.d(str, "onAdFailedToLoad: " + loadAdError.getMessage());
                        if (!appPrefrence.getAM_RECT_BIG_HOME().equalsIgnoreCase("")) {
                            final AdView adView = new AdView(context);
                            adView.setAdUnitId(appPrefrence.getAM_RECT_BIG_HOME());
                            adView.setAdSize(AdSize.MEDIUM_RECTANGLE);
                            adView.setAdListener(new AdListener() { // from class: calldial.be.loctracker.MagicBold.AllAdsKeyPlace.2.1
                                @Override // com.google.android.gms.ads.AdListener
                                public void onAdClicked() {
                                }

                                @Override // com.google.android.gms.ads.AdListener
                                public void onAdClosed() {
                                }

                                @Override // com.google.android.gms.ads.AdListener
                                public void onAdOpened() {
                                }

                                @Override // com.google.android.gms.ads.AdListener
                                public void onAdLoaded() {
                                    viewGroup.removeAllViews();
                                    viewGroup.addView(adView);
                                }

                                @Override // com.google.android.gms.ads.AdListener
                                public void onAdFailedToLoad(LoadAdError loadAdError2) {
                                    Log.e("Medium_Rect", loadAdError2.getMessage() + "-" + loadAdError2.getCode());
                                }
                            });
                            adView.loadAd(new AdRequest.Builder().build());
                        }
                    }

                    @Override // com.google.android.gms.ads.AdListener
                    public void onAdImpression() {
                        Log.d(AllAdsKeyPlace.TAG, "Impression.....");
                    }
                }).build().loadAd(new AdRequest.Builder().build());
            } else if (!appPrefrence.getAM_RECT_BIG_HOME().equalsIgnoreCase("")) {
                final AdView adView = new AdView(context);
                adView.setAdUnitId(appPrefrence.getAM_RECT_BIG_HOME());
                adView.setAdSize(AdSize.MEDIUM_RECTANGLE);
                adView.setAdListener(new AdListener() { // from class: calldial.be.loctracker.MagicBold.AllAdsKeyPlace.3
                    @Override // com.google.android.gms.ads.AdListener
                    public void onAdClicked() {
                    }

                    @Override // com.google.android.gms.ads.AdListener
                    public void onAdClosed() {
                    }

                    @Override // com.google.android.gms.ads.AdListener
                    public void onAdOpened() {
                    }

                    @Override // com.google.android.gms.ads.AdListener
                    public void onAdLoaded() {
                        viewGroup.removeAllViews();
                        viewGroup.addView(adView);
                    }

                    @Override // com.google.android.gms.ads.AdListener
                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        Log.e("Medium_Rect", loadAdError.getMessage() + "-" + loadAdError.getCode());
                    }
                });
                adView.loadAd(new AdRequest.Builder().build());
            }
        }
    }

    public static void ShowNativeBannerAd(final Context context, final ViewGroup viewGroup) {
        final AppPrefrence appPrefrence = new AppPrefrence(context);
        if (appPrefrence.getAds_On_Off().equalsIgnoreCase("on")) {
            View inflate = LayoutInflater.from(context).inflate(R.layout.admob_temp_loading_native_banner, viewGroup, false);
            viewGroup.removeAllViews();
            viewGroup.addView(inflate);
            if (!appPrefrence.getAM_NATIVE_BANNER_HOME().equalsIgnoreCase("")) {
                AdLoader.Builder builder = new AdLoader.Builder(context, appPrefrence.getAM_NATIVE_BANNER_HOME());
                builder.forNativeAd(new NativeAd.OnNativeAdLoadedListener() { // from class: calldial.be.loctracker.MagicBold.AllAdsKeyPlace.4
                    @Override // com.google.android.gms.ads.nativead.NativeAd.OnNativeAdLoadedListener
                    public void onNativeAdLoaded(NativeAd nativeAd) {
                        AllAdsKeyPlace.nativeSmallAd = nativeAd;
                        NativeAdView nativeAdView = (NativeAdView) LayoutInflater.from(context).inflate(R.layout.admob_native_small, (ViewGroup) null);
                        nativeAdView.setHeadlineView(nativeAdView.findViewById(R.id.ad_headline));
                        nativeAdView.setBodyView(nativeAdView.findViewById(R.id.ad_body));
                        nativeAdView.setCallToActionView(nativeAdView.findViewById(R.id.ad_call_to_action));
                        nativeAdView.setIconView(nativeAdView.findViewById(R.id.ad_app_icon));
                        ((TextView) nativeAdView.getHeadlineView()).setText(AllAdsKeyPlace.nativeSmallAd.getHeadline());
                        if (AllAdsKeyPlace.nativeSmallAd.getBody() == null) {
                            nativeAdView.getBodyView().setVisibility(4);
                        } else {
                            nativeAdView.getBodyView().setVisibility(0);
                            ((TextView) nativeAdView.getBodyView()).setText(AllAdsKeyPlace.nativeSmallAd.getBody());
                        }
                        if (AllAdsKeyPlace.nativeSmallAd.getCallToAction() == null) {
                            nativeAdView.getCallToActionView().setVisibility(4);
                        } else {
                            nativeAdView.getCallToActionView().setVisibility(0);
                            ((Button) nativeAdView.getCallToActionView()).setText(AllAdsKeyPlace.nativeSmallAd.getCallToAction());
                        }
                        if (AllAdsKeyPlace.nativeSmallAd.getIcon() == null) {
                            nativeAdView.getIconView().setVisibility(8);
                        } else {
                            ((ImageView) nativeAdView.getIconView()).setImageDrawable(AllAdsKeyPlace.nativeSmallAd.getIcon().getDrawable());
                            nativeAdView.getIconView().setVisibility(0);
                        }
                        nativeAdView.setNativeAd(AllAdsKeyPlace.nativeSmallAd);
                        viewGroup.removeAllViews();
                        viewGroup.addView(nativeAdView);
                    }
                });
                builder.withAdListener(new AdListener() { // from class: calldial.be.loctracker.MagicBold.AllAdsKeyPlace.5
                    @Override // com.google.android.gms.ads.AdListener
                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        String str = AllAdsKeyPlace.TAG;
                        Log.d(str, "onAdFailedToLoad: " + loadAdError.getMessage());
                        if (!appPrefrence.getAM_RECT_BIG_HOME().equalsIgnoreCase("")) {
                            final AdView adView = new AdView(context);
                            adView.setAdUnitId(appPrefrence.getAM_RECT_BIG_HOME());
                            adView.setAdSize(AdSize.LARGE_BANNER);
                            adView.setAdListener(new AdListener() { // from class: calldial.be.loctracker.MagicBold.AllAdsKeyPlace.5.1
                                @Override // com.google.android.gms.ads.AdListener
                                public void onAdClicked() {
                                }

                                @Override // com.google.android.gms.ads.AdListener
                                public void onAdClosed() {
                                }

                                @Override // com.google.android.gms.ads.AdListener
                                public void onAdOpened() {
                                }

                                @Override // com.google.android.gms.ads.AdListener
                                public void onAdLoaded() {
                                    viewGroup.removeAllViews();
                                    viewGroup.addView(adView);
                                }

                                @Override // com.google.android.gms.ads.AdListener
                                public void onAdFailedToLoad(LoadAdError loadAdError2) {
                                    Log.e("Medium_Rect", loadAdError2.getMessage() + "-" + loadAdError2.getCode());
                                }
                            });
                            adView.loadAd(new AdRequest.Builder().build());
                        }
                    }

                    @Override // com.google.android.gms.ads.AdListener
                    public void onAdImpression() {
                        Log.d(AllAdsKeyPlace.TAG, "Impression.....");
                    }
                }).build().loadAd(new AdRequest.Builder().build());
            } else if (!appPrefrence.getAM_RECT_BIG_HOME().equalsIgnoreCase("")) {
                final AdView adView = new AdView(context);
                adView.setAdUnitId(appPrefrence.getAM_RECT_BIG_HOME());
                adView.setAdSize(AdSize.LARGE_BANNER);
                adView.setAdListener(new AdListener() { // from class: calldial.be.loctracker.MagicBold.AllAdsKeyPlace.6
                    @Override // com.google.android.gms.ads.AdListener
                    public void onAdClicked() {
                    }

                    @Override // com.google.android.gms.ads.AdListener
                    public void onAdClosed() {
                    }

                    @Override // com.google.android.gms.ads.AdListener
                    public void onAdOpened() {
                    }

                    @Override // com.google.android.gms.ads.AdListener
                    public void onAdLoaded() {
                        viewGroup.removeAllViews();
                        viewGroup.addView(adView);
                    }

                    @Override // com.google.android.gms.ads.AdListener
                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        Log.e("Medium_Rect", loadAdError.getMessage() + "-" + loadAdError.getCode());
                    }
                });
                adView.loadAd(new AdRequest.Builder().build());
            }
        }
    }
}
