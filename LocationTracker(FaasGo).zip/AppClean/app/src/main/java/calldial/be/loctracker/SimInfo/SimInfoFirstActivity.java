package calldial.be.loctracker.SimInfo;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.core.widget.NestedScrollView;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.appbar.AppBarLayout;

import calldial.be.loctracker.Common;
import calldial.be.loctracker.DashboardActivity;
import calldial.be.loctracker.MagicBold.AllAdsKeyPlace;
import calldial.be.loctracker.MagicBold.AppPrefrence;
import calldial.be.loctracker.MagicQG.QG;
import calldial.be.loctracker.MoreAdActivity;
import calldial.be.loctracker.R;

/* loaded from: classes.dex */
public class SimInfoFirstActivity extends AppCompatActivity implements View.OnClickListener {
    public static boolean IS_DOWN = true;
    public static boolean IS_UP = true;
    AppBarLayout appbarlay_tool;
    Animation down_anim_toolbar;
    ImageView imgDrawerLines;
    LinearLayout iv_moreads;
    LinearLayout ll_aircel;
    LinearLayout ll_airtel;
    LinearLayout ll_bsnl;
    LinearLayout ll_docomo;
    LinearLayout ll_idea;
    LinearLayout ll_jio;
    LinearLayout ll_telenor;
    LinearLayout ll_vodafone;
    private DrawerLayout mDrawerLayout;
    NestedScrollView nested_scroll;
    Animation up_anim_toolbar;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override
    // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_sim_info_first);
        AllAdsKeyPlace.ShowInterstitialAdsOnCreate(this);
        AllAdsKeyPlace.ShowNativeAd(this, (ViewGroup) findViewById(R.id.nativeContainer));
        this.iv_moreads = (LinearLayout) findViewById(R.id.iv_moreads);
        if (Common.isNetworkConnected(this) && new AppPrefrence(getApplicationContext()).getQureka_ADS().equalsIgnoreCase("on")) {
            this.iv_moreads.setVisibility(0);
        }
        this.iv_moreads.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.SimInfo.SimInfoFirstActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                QG.openQGAlternate(SimInfoFirstActivity.this);
            }
        });
        this.mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        ImageView imageView = (ImageView) findViewById(R.id.imgDrawerLines);
        this.imgDrawerLines = imageView;
        Common.Animation(imageView);
        this.imgDrawerLines.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.SimInfo.SimInfoFirstActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (SimInfoFirstActivity.this.mDrawerLayout.isDrawerOpen(3)) {
                    SimInfoFirstActivity.this.mDrawerLayout.closeDrawer(5);
                } else {
                    SimInfoFirstActivity.this.mDrawerLayout.openDrawer(3);
                }
            }
        });
        findViewById(R.id.llhomeapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.SimInfo.SimInfoFirstActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                SimInfoFirstActivity.this.mDrawerLayout.closeDrawers();
                SimInfoFirstActivity.this.startActivity(new Intent(SimInfoFirstActivity.this, DashboardActivity.class));
            }
        });
        findViewById(R.id.llrateapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.SimInfo.SimInfoFirstActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                SimInfoFirstActivity.this.mDrawerLayout.closeDrawers();
                Common.showRateDialog(SimInfoFirstActivity.this);
            }
        });
        findViewById(R.id.llshareapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.SimInfo.SimInfoFirstActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                SimInfoFirstActivity.this.mDrawerLayout.closeDrawers();
                Common.ShareApp(SimInfoFirstActivity.this);
            }
        });
        findViewById(R.id.llpolicy__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.SimInfo.SimInfoFirstActivity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                SimInfoFirstActivity.this.mDrawerLayout.closeDrawers();
                Common.showPrivacyDialog(SimInfoFirstActivity.this);
            }
        });
        findViewById(R.id.llmoreapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.SimInfo.SimInfoFirstActivity.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                SimInfoFirstActivity.this.mDrawerLayout.closeDrawers();
                SimInfoFirstActivity.this.startActivity(new Intent(SimInfoFirstActivity.this, MoreAdActivity.class));
            }
        });
        this.ll_airtel = (LinearLayout) findViewById(R.id.ll_airtel);
        this.ll_jio = (LinearLayout) findViewById(R.id.ll_jio);
        this.ll_aircel = (LinearLayout) findViewById(R.id.ll_aircel);
        this.ll_idea = (LinearLayout) findViewById(R.id.ll_idea);
        this.ll_vodafone = (LinearLayout) findViewById(R.id.ll_vodafone);
        this.ll_telenor = (LinearLayout) findViewById(R.id.ll_telenor);
        this.ll_docomo = (LinearLayout) findViewById(R.id.ll_docomo);
        this.ll_bsnl = (LinearLayout) findViewById(R.id.ll_bsnl);
        Common.Animation((ViewGroup) this.ll_airtel);
        Common.Animation((ViewGroup) this.ll_jio);
        Common.Animation((ViewGroup) this.ll_aircel);
        Common.Animation((ViewGroup) this.ll_idea);
        Common.Animation((ViewGroup) this.ll_vodafone);
        Common.Animation((ViewGroup) this.ll_telenor);
        Common.Animation((ViewGroup) this.ll_docomo);
        Common.Animation((ViewGroup) this.ll_bsnl);
        this.ll_airtel.setOnClickListener(this);
        this.ll_jio.setOnClickListener(this);
        this.ll_aircel.setOnClickListener(this);
        this.ll_idea.setOnClickListener(this);
        this.ll_vodafone.setOnClickListener(this);
        this.ll_telenor.setOnClickListener(this);
        this.ll_docomo.setOnClickListener(this);
        this.ll_bsnl.setOnClickListener(this);
        this.appbarlay_tool = (AppBarLayout) findViewById(R.id.appbarlay_tool);
        this.nested_scroll = (NestedScrollView) findViewById(R.id.nested_scroll);
        this.down_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.down_anim_toolbar);
        this.up_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.up_anim_toolbar);
        NestedScrollView nestedScrollView = this.nested_scroll;
        if (nestedScrollView != null) {
            nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() { // from class: calldial.be.loctracker.SimInfo.SimInfoFirstActivity.8
                @Override // androidx.core.widget.NestedScrollView.OnScrollChangeListener
                public void onScrollChange(NestedScrollView nestedScrollView2, int i, int i2, int i3, int i4) {
                    if (i2 > i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling DOWN");
                        if (SimInfoFirstActivity.IS_UP) {
                            SimInfoFirstActivity.this.appbarlay_tool.startAnimation(SimInfoFirstActivity.this.up_anim_toolbar);
                            SimInfoFirstActivity.IS_UP = false;
                            SimInfoFirstActivity.IS_DOWN = true;
                        }
                    }
                    if (i2 < i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling UP");
                        if (SimInfoFirstActivity.IS_DOWN) {
                            SimInfoFirstActivity.this.appbarlay_tool.startAnimation(SimInfoFirstActivity.this.down_anim_toolbar);
                            SimInfoFirstActivity.IS_DOWN = false;
                            SimInfoFirstActivity.IS_UP = true;
                        }
                    }
                    if (i2 == 0) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to TOP SCROLL");
                    }
                    if (i2 == nestedScrollView2.getMeasuredHeight() - nestedScrollView2.getChildAt(0).getMeasuredHeight()) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to BOTTOM SCROLL");
                    }
                }
            });
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ll_aircel /* 2131362202 */:
                Intent intent = new Intent(this, SimInfoSecondActivity.class);
                intent.putExtra("HOW_TO_RECHARGE", "*124*(16 digits code)#");
                intent.putExtra("MAIN_BALANCE_ENQUIRY", "*125#");
                intent.putExtra("MESSAGE_BALANCE_ENQUIRY", "*111*5#and*111*12#");
                intent.putExtra("NET_BALANCE_ENQUIRY", "*123*1#");
                intent.putExtra("HOW_TO_KNOW_YOUR_NUMBER", "*1#");
                intent.putExtra("CUSTOMER_CARE_NUMBER", "121 or 198");
                startActivity(intent);
                return;
            case R.id.ll_airtel /* 2131362203 */:
                Intent intent2 = new Intent(this, SimInfoSecondActivity.class);
                intent2.putExtra("HOW_TO_RECHARGE", "*120*(16 digits code)#");
                intent2.putExtra("MAIN_BALANCE_ENQUIRY", "*123#");
                intent2.putExtra("MESSAGE_BALANCE_ENQUIRY", "*555#");
                intent2.putExtra("NET_BALANCE_ENQUIRY", "*123*10#/*123*11#");
                intent2.putExtra("HOW_TO_KNOW_YOUR_NUMBER", "*121*9#");
                intent2.putExtra("CUSTOMER_CARE_NUMBER", "121 or 198");
                startActivity(intent2);
                return;
            case R.id.ll_bsnl /* 2131362214 */:
                Intent intent3 = new Intent(this, SimInfoSecondActivity.class);
                intent3.putExtra("HOW_TO_RECHARGE", "*124*2*(16 digits code)#");
                intent3.putExtra("MAIN_BALANCE_ENQUIRY", "*123#");
                intent3.putExtra("MESSAGE_BALANCE_ENQUIRY", "*123*10#");
                intent3.putExtra("NET_BALANCE_ENQUIRY", "*124#");
                intent3.putExtra("HOW_TO_KNOW_YOUR_NUMBER", "*1#");
                intent3.putExtra("CUSTOMER_CARE_NUMBER", "1503 or 1800-345-1500");
                startActivity(intent3);
                return;
            case R.id.ll_docomo /* 2131362225 */:
                Intent intent4 = new Intent(this, SimInfoSecondActivity.class);
                intent4.putExtra("HOW_TO_RECHARGE", "*135*2*(16 digits code)#");
                intent4.putExtra("MAIN_BALANCE_ENQUIRY", "*111#");
                intent4.putExtra("MESSAGE_BALANCE_ENQUIRY", "*111*1#");
                intent4.putExtra("NET_BALANCE_ENQUIRY", "*123*1#");
                intent4.putExtra("HOW_TO_KNOW_YOUR_NUMBER", "*580#");
                intent4.putExtra("CUSTOMER_CARE_NUMBER", "121");
                startActivity(intent4);
                return;
            case R.id.ll_idea /* 2131362234 */:
                Intent intent5 = new Intent(this, SimInfoSecondActivity.class);
                intent5.putExtra("HOW_TO_RECHARGE", "*124*(16 digits code)#");
                intent5.putExtra("MAIN_BALANCE_ENQUIRY", "*111#");
                intent5.putExtra("MESSAGE_BALANCE_ENQUIRY", "*167*3*#");
                intent5.putExtra("NET_BALANCE_ENQUIRY", "*125#");
                intent5.putExtra("HOW_TO_KNOW_YOUR_NUMBER", "*1#");
                intent5.putExtra("CUSTOMER_CARE_NUMBER", "12345");
                startActivity(intent5);
                return;
            case R.id.ll_jio /* 2131362238 */:
                Intent intent6 = new Intent(this, SimInfoSecondActivity.class);
                intent6.putExtra("HOW_TO_RECHARGE", "*123*(16 digits code)#");
                intent6.putExtra("MAIN_BALANCE_ENQUIRY", "*333#");
                intent6.putExtra("MESSAGE_BALANCE_ENQUIRY", "*112# then press 3");
                intent6.putExtra("NET_BALANCE_ENQUIRY", "*333# then press 2");
                intent6.putExtra("HOW_TO_KNOW_YOUR_NUMBER", "*1#");
                intent6.putExtra("CUSTOMER_CARE_NUMBER", "1800 889 9999");
                startActivity(intent6);
                return;
            case R.id.ll_telenor /* 2131362256 */:
                Intent intent7 = new Intent(this, SimInfoSecondActivity.class);
                intent7.putExtra("HOW_TO_RECHARGE", "*222*3*(16 digits code)#");
                intent7.putExtra("MAIN_BALANCE_ENQUIRY", "*222*2#");
                intent7.putExtra("MESSAGE_BALANCE_ENQUIRY", "*222*2#");
                intent7.putExtra("NET_BALANCE_ENQUIRY", "*123#");
                intent7.putExtra("HOW_TO_KNOW_YOUR_NUMBER", "*1#");
                intent7.putExtra("CUSTOMER_CARE_NUMBER", "121 or 9059090590");
                startActivity(intent7);
                return;
            case R.id.ll_vodafone /* 2131362262 */:
                Intent intent8 = new Intent(this, SimInfoSecondActivity.class);
                intent8.putExtra("HOW_TO_RECHARGE", "*140*(16 digits code)#");
                intent8.putExtra("MAIN_BALANCE_ENQUIRY", "*145# or *146#");
                intent8.putExtra("MESSAGE_BALANCE_ENQUIRY", "*142#");
                intent8.putExtra("NET_BALANCE_ENQUIRY", "*111*6# or *111*6*2#");
                intent8.putExtra("HOW_TO_KNOW_YOUR_NUMBER", "*777*0#");
                intent8.putExtra("CUSTOMER_CARE_NUMBER", "198 or 9825098250");
                startActivity(intent8);
                return;
            default:
                return;
        }
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (this.mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            this.mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            AllAdsKeyPlace.CloseActivityWithAds(this, "true");
        }
    }
}
