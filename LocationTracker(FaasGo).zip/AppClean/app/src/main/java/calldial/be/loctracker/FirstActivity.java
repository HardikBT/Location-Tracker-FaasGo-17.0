package calldial.be.loctracker;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.core.widget.NestedScrollView;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.appbar.AppBarLayout;

import calldial.be.loctracker.BankInfo.BankInfoFirstActivity;
import calldial.be.loctracker.GoogleMap.LiveLocationMapActivity;
import calldial.be.loctracker.MagicBold.AllAdsKeyPlace;
import calldial.be.loctracker.MagicBold.AppPrefrence;
import calldial.be.loctracker.MagicCode.GlobalMaintainer;
import calldial.be.loctracker.MagicQG.QG;
import calldial.be.loctracker.SimInfo.SimInfoFirstActivity;

/* loaded from: classes.dex */
public class FirstActivity extends AppCompatActivity {
    public static boolean IS_DOWN = true;
    public static boolean IS_UP = true;
    AppBarLayout appbarlay_tool;
    ImageView btn_bank_info;
    ImageView btn_location_info;
    ImageView btn_mobile_tools;
    ImageView btn_number_locator;
    ImageView btn_simcard_info;
    ImageView btn_traffic_finder;
    Animation down_anim_toolbar;
    ImageView imgDrawerLines;
    LinearLayout iv_moreads;
    private DrawerLayout mDrawerLayout;
    NestedScrollView nested_scroll;
    Animation up_anim_toolbar;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_first);
        AllAdsKeyPlace.ShowInterstitialAdsOnCreate(this);
        AllAdsKeyPlace.ShowNativeAd(this, (ViewGroup) findViewById(R.id.nativeContainer));

        this.iv_moreads = (LinearLayout) findViewById(R.id.iv_moreads);
        if (Common.isNetworkConnected(this) && new AppPrefrence(getApplicationContext()).getQureka_ADS().equalsIgnoreCase("on")) {
            this.iv_moreads.setVisibility(0);
        }
        this.iv_moreads.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.FirstActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                QG.openQGAlternate(FirstActivity.this);
            }
        });
        this.mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        ImageView imageView = (ImageView) findViewById(R.id.imgDrawerLines);
        this.imgDrawerLines = imageView;
        Common.Animation(imageView);
        this.imgDrawerLines.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.FirstActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (FirstActivity.this.mDrawerLayout.isDrawerOpen(3)) {
                    FirstActivity.this.mDrawerLayout.closeDrawer(5);
                } else {
                    FirstActivity.this.mDrawerLayout.openDrawer(3);
                }
            }
        });
        findViewById(R.id.llhomeapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.FirstActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FirstActivity.this.mDrawerLayout.closeDrawers();
                FirstActivity.this.startActivity(new Intent(FirstActivity.this, DashboardActivity.class));
            }
        });
        findViewById(R.id.llrateapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.FirstActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FirstActivity.this.mDrawerLayout.closeDrawers();
                Common.showRateDialog(FirstActivity.this);
            }
        });
        findViewById(R.id.llshareapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.FirstActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FirstActivity.this.mDrawerLayout.closeDrawers();
                Common.ShareApp(FirstActivity.this);
            }
        });
        findViewById(R.id.llpolicy__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.FirstActivity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FirstActivity.this.mDrawerLayout.closeDrawers();
                Common.showPrivacyDialog(FirstActivity.this);
            }
        });
        findViewById(R.id.llmoreapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.FirstActivity.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FirstActivity.this.mDrawerLayout.closeDrawers();
                FirstActivity.this.startActivity(new Intent(FirstActivity.this, MoreAdActivity.class));
            }
        });
        this.btn_location_info = (ImageView) findViewById(R.id.btn_location_info);
        this.btn_number_locator = (ImageView) findViewById(R.id.btn_number_locator);
        this.btn_mobile_tools = (ImageView) findViewById(R.id.btn_mobile_tools);
        this.btn_simcard_info = (ImageView) findViewById(R.id.btn_simcard_info);
        this.btn_traffic_finder = (ImageView) findViewById(R.id.btn_traffic_finder);
        this.btn_bank_info = (ImageView) findViewById(R.id.btn_bank_info);
        Common.Animation(this.btn_location_info);
        Common.Animation(this.btn_number_locator);
        Common.Animation(this.btn_mobile_tools);
        Common.Animation(this.btn_simcard_info);
        Common.Animation(this.btn_traffic_finder);
        Common.Animation(this.btn_bank_info);
        Common.Animation((ViewGroup) findViewById(R.id.rl_qureka_button_1));
        Common.Animation((ViewGroup) findViewById(R.id.rl_qureka_button_2));
        this.appbarlay_tool = (AppBarLayout) findViewById(R.id.appbarlay_tool);
        this.nested_scroll = (NestedScrollView) findViewById(R.id.nested_scroll);
        this.down_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.down_anim_toolbar);
        this.up_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.up_anim_toolbar);
        NestedScrollView nestedScrollView = this.nested_scroll;
        if (nestedScrollView != null) {
            nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() { // from class: calldial.be.loctracker.FirstActivity.8
                @Override // androidx.core.widget.NestedScrollView.OnScrollChangeListener
                public void onScrollChange(NestedScrollView nestedScrollView2, int i, int i2, int i3, int i4) {
                    if (i2 > i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling DOWN");
                        if (FirstActivity.IS_UP) {
                            FirstActivity.this.appbarlay_tool.startAnimation(FirstActivity.this.up_anim_toolbar);
                            FirstActivity.IS_UP = false;
                            FirstActivity.IS_DOWN = true;
                        }
                    }
                    if (i2 < i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling UP");
                        if (FirstActivity.IS_DOWN) {
                            FirstActivity.this.appbarlay_tool.startAnimation(FirstActivity.this.down_anim_toolbar);
                            FirstActivity.IS_DOWN = false;
                            FirstActivity.IS_UP = true;
                        }
                    }
                    if (i2 == 0) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to TOP SCROLL");
                    }
                    if (i2 == nestedScrollView2.getMeasuredHeight() - nestedScrollView2.getChildAt(0).getMeasuredHeight()) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to BOTTOM SCROLL");
                    }
                }
            });
        }
        this.btn_location_info.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.FirstActivity.9
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FirstActivity.this.startActivity(new Intent(FirstActivity.this, LocationInfoActivity.class));
            }
        });
        this.btn_number_locator.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.FirstActivity.10
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FirstActivity.this.startActivity(new Intent(FirstActivity.this, NumberLocatorActivity.class));
            }
        });
        this.btn_mobile_tools.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.FirstActivity.11
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FirstActivity.this.startActivity(new Intent(FirstActivity.this, MobileToolsActivity.class));
            }
        });
        this.btn_simcard_info.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.FirstActivity.12
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FirstActivity.this.startActivity(new Intent(FirstActivity.this, SimInfoFirstActivity.class));
            }
        });
        this.btn_traffic_finder.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.FirstActivity.13
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Intent intent = new Intent(FirstActivity.this, LiveLocationMapActivity.class);
                intent.putExtra("IS_TRAFFIC_ENABLED", true);
                FirstActivity.this.startActivity(intent);
            }
        });
        this.btn_bank_info.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.FirstActivity.14
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FirstActivity.this.startActivity(new Intent(FirstActivity.this, BankInfoFirstActivity.class));
            }
        });
        if (Common.isNetworkConnected(this) && new AppPrefrence(getApplicationContext()).getQureka_ADS().equalsIgnoreCase("on")) {
            findViewById(R.id.rl_qureka_button_1).setVisibility(0);
        }
        findViewById(R.id.rl_qureka_button_1).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.FirstActivity.15
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (Common.isNetworkConnected(FirstActivity.this)) {
                    QG.openQGAlternate(FirstActivity.this);
                } else {
                    Toast.makeText(FirstActivity.this, "No internet connection...", 0).show();
                }
            }
        });
        if (Common.isNetworkConnected(this) && new AppPrefrence(getApplicationContext()).getQureka_ADS().equalsIgnoreCase("on")) {
            findViewById(R.id.rl_qureka_button_2).setVisibility(0);
        }
        findViewById(R.id.rl_qureka_button_2).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.FirstActivity.16
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (Common.isNetworkConnected(FirstActivity.this)) {
                    QG.openQGAlternate(FirstActivity.this);
                } else {
                    Toast.makeText(FirstActivity.this, "No internet connection...", 0).show();
                }
            }
        });
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (this.mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            this.mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            AllAdsKeyPlace.CloseActivityWithAds(this, "true");
        }
    }
}
