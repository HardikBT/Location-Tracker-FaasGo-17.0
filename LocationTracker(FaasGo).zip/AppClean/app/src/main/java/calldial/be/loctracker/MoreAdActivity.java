package calldial.be.loctracker;

import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import calldial.be.loctracker.MagicBold.AllAdsKeyPlace;

/* loaded from: classes.dex */
public class MoreAdActivity extends AppCompatActivity {
    private RecyclerView recycler_view;
    private TextView txt_no_internet;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_more_ad);
        AllAdsKeyPlace.ShowInterstitialAdsOnCreate(this);
        AllAdsKeyPlace.ShowNativeBannerAd(this, (ViewGroup) findViewById(R.id.adsContainer));
        this.recycler_view = (RecyclerView) findViewById(R.id.recycler_view);
        this.txt_no_internet = (TextView) findViewById(R.id.txt_no_internet);
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        AllAdsKeyPlace.CloseActivityWithAds(this, "true");
    }
}
