package calldial.be.loctracker.Compass.app.widget;

import android.content.Context;
import android.content.res.Resources;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import android.widget.TextView;

import calldial.be.loctracker.R;

/* loaded from: classes.dex */
public class CompassCompoundViewCompass extends FrameLayout {
    public static final String DEGREE_SIGN = "°";
    private static final int UPDATE_INTERVAL_DIRECTION = 120;
    private CompassBackgroundViewCompass compassBackgroundView;
    private CompassClockFaceViewCompass compassClockfaceView;
    private long directionUpdatePrevTime = 0;
    private String e;
    private String n;
    private String ne;
    private String nw;
    private String s;
    private String se;
    private String sw;
    private TextView txtDirection;
    private String w;

    public CompassCompoundViewCompass(Context context) {
        super(context);
        init(context);
    }

    public CompassCompoundViewCompass(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(context);
    }

    public CompassCompoundViewCompass(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init(context);
    }

    private void init(Context context) {
        inflate(context, R.layout.compass_view_compound_compass, this);
        this.compassClockfaceView = (CompassClockFaceViewCompass) findViewById(R.id.compass_clockface_view);
        this.compassBackgroundView = (CompassBackgroundViewCompass) findViewById(R.id.compass_background_view);
        this.txtDirection = (TextView) findViewById(R.id.txt_direction);
        Resources resources = context.getResources();
        this.n = resources.getString(R.string.n);
        this.e = resources.getString(R.string.e);
        this.s = resources.getString(R.string.s);
        this.w = resources.getString(R.string.w);
        this.ne = resources.getString(R.string.ne);
        this.se = resources.getString(R.string.se);
        this.sw = resources.getString(R.string.sw);
        this.nw = resources.getString(R.string.nw);
    }

    public void updateRotation(float f) {
        this.compassClockfaceView.updateAzimuth(f);
        long currentTimeMillis = System.currentTimeMillis();
        if (currentTimeMillis - this.directionUpdatePrevTime > 120) {
            this.txtDirection.setText(((int) f) + "° " + getDirectionText(f));
            this.directionUpdatePrevTime = currentTimeMillis;
        }
    }

    public void setSimpleMode(boolean z) {
        this.compassBackgroundView.setSimpleMode(z);
    }

    private String getDirectionText(float f) {
        if ((f >= 0.0f && f < 22.5f) || f > 337.5f) {
            return this.n;
        }
        if (f >= 22.5f && f < 67.5f) {
            return this.ne;
        }
        if (f >= 67.5f && f < 112.5f) {
            return this.e;
        }
        if (f >= 112.5f && f < 157.5f) {
            return this.se;
        }
        if (f >= 157.5f && f < 202.5f) {
            return this.s;
        }
        if (f >= 202.5f && f < 247.5f) {
            return this.sw;
        }
        if (f < 247.5f || f >= 292.5f) {
            return (f < 292.5f || f >= 337.5f) ? "" : this.nw;
        }
        return this.w;
    }
}
