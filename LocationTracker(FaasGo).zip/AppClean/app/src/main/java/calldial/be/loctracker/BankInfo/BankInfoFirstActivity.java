package calldial.be.loctracker.BankInfo;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.core.widget.NestedScrollView;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.appbar.AppBarLayout;

import calldial.be.loctracker.Common;
import calldial.be.loctracker.DashboardActivity;
import calldial.be.loctracker.MagicBold.AllAdsKeyPlace;
import calldial.be.loctracker.MagicBold.AppPrefrence;
import calldial.be.loctracker.MagicQG.QG;
import calldial.be.loctracker.MoreAdActivity;
import calldial.be.loctracker.R;

/* loaded from: classes.dex */
public class BankInfoFirstActivity extends AppCompatActivity implements View.OnClickListener {
    public static boolean IS_DOWN = true;
    public static boolean IS_UP = true;
    AppBarLayout appbarlay_tool;
    Animation down_anim_toolbar;
    ImageView imgDrawerLines;
    LinearLayout iv_moreads;
    LinearLayout ll_abn_amro;
    LinearLayout ll_allahabad_bank;
    LinearLayout ll_american_express;
    LinearLayout ll_andhra_bank;
    LinearLayout ll_anz_bank;
    LinearLayout ll_axis_bank;
    LinearLayout ll_bank_of_baroda;
    LinearLayout ll_bank_of_india;
    LinearLayout ll_bank_of_maharashtra;
    LinearLayout ll_barclays_bank;
    LinearLayout ll_bharatiya_mahila_bank;
    LinearLayout ll_canara_bank;
    LinearLayout ll_cashnet_india;
    LinearLayout ll_central_bank_of_india;
    LinearLayout ll_centurion_bank_of_punjab;
    LinearLayout ll_citi_bank;
    LinearLayout ll_corporation_bank;
    LinearLayout ll_dena_bank;
    LinearLayout ll_deutsche_bank;
    LinearLayout ll_dhanalakshmi_bank;
    LinearLayout ll_federal_bank;
    LinearLayout ll_hdfc_bank;
    LinearLayout ll_hsbc_bank;
    LinearLayout ll_idbi_bank;
    LinearLayout ll_indian_bank;
    LinearLayout ll_indian_overseas_bank;
    LinearLayout ll_ing_vysya_bank;
    LinearLayout ll_karnataka_bank;
    LinearLayout ll_karur_vysya_bank;
    LinearLayout ll_kotak_mahindra_bank;
    LinearLayout ll_punjab_and_sind_bank;
    LinearLayout ll_punjab_national_bank;
    LinearLayout ll_saraswat_bank;
    LinearLayout ll_south_indian_bank;
    LinearLayout ll_standard_chartered_bank;
    LinearLayout ll_state_bank_of_bikaner_and_jaipur;
    LinearLayout ll_state_bank_of_india;
    LinearLayout ll_state_bank_of_travancore;
    LinearLayout ll_syndicate_bank;
    LinearLayout ll_uco_bank;
    LinearLayout ll_union_bank_of_india;
    LinearLayout ll_united_bank_of_india;
    LinearLayout ll_vijaya_bank;
    LinearLayout ll_yes_bank;
    private DrawerLayout mDrawerLayout;
    NestedScrollView nested_scroll;
    Animation up_anim_toolbar;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_bank_info_first);
        AllAdsKeyPlace.ShowInterstitialAdsOnCreate(this);
        AllAdsKeyPlace.ShowNativeAd(this, (ViewGroup) findViewById(R.id.nativeContainer));
        this.iv_moreads = (LinearLayout) findViewById(R.id.iv_moreads);
        if (Common.isNetworkConnected(this) && new AppPrefrence(getApplicationContext()).getQureka_ADS().equalsIgnoreCase("on")) {
            this.iv_moreads.setVisibility(0);
        }
        this.iv_moreads.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.BankInfo.BankInfoFirstActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                QG.openQGAlternate(BankInfoFirstActivity.this);
            }
        });
        this.mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        ImageView imageView = (ImageView) findViewById(R.id.imgDrawerLines);
        this.imgDrawerLines = imageView;
        Common.Animation(imageView);
        this.imgDrawerLines.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.BankInfo.BankInfoFirstActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (BankInfoFirstActivity.this.mDrawerLayout.isDrawerOpen(3)) {
                    BankInfoFirstActivity.this.mDrawerLayout.closeDrawer(5);
                } else {
                    BankInfoFirstActivity.this.mDrawerLayout.openDrawer(3);
                }
            }
        });
        findViewById(R.id.llhomeapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.BankInfo.BankInfoFirstActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BankInfoFirstActivity.this.mDrawerLayout.closeDrawers();
                BankInfoFirstActivity.this.startActivity(new Intent(BankInfoFirstActivity.this, DashboardActivity.class));
            }
        });
        findViewById(R.id.llrateapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.BankInfo.BankInfoFirstActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BankInfoFirstActivity.this.mDrawerLayout.closeDrawers();
                Common.showRateDialog(BankInfoFirstActivity.this);
            }
        });
        findViewById(R.id.llshareapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.BankInfo.BankInfoFirstActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BankInfoFirstActivity.this.mDrawerLayout.closeDrawers();
                Common.ShareApp(BankInfoFirstActivity.this);
            }
        });
        findViewById(R.id.llpolicy__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.BankInfo.BankInfoFirstActivity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BankInfoFirstActivity.this.mDrawerLayout.closeDrawers();
                Common.showPrivacyDialog(BankInfoFirstActivity.this);
            }
        });
        findViewById(R.id.llmoreapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.BankInfo.BankInfoFirstActivity.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BankInfoFirstActivity.this.mDrawerLayout.closeDrawers();
                BankInfoFirstActivity.this.startActivity(new Intent(BankInfoFirstActivity.this, MoreAdActivity.class));
            }
        });
        this.ll_state_bank_of_india = (LinearLayout) findViewById(R.id.ll_state_bank_of_india);
        this.ll_idbi_bank = (LinearLayout) findViewById(R.id.ll_idbi_bank);
        this.ll_bank_of_baroda = (LinearLayout) findViewById(R.id.ll_bank_of_baroda);
        this.ll_central_bank_of_india = (LinearLayout) findViewById(R.id.ll_central_bank_of_india);
        this.ll_hdfc_bank = (LinearLayout) findViewById(R.id.ll_hdfc_bank);
        this.ll_citi_bank = (LinearLayout) findViewById(R.id.ll_citi_bank);
        this.ll_axis_bank = (LinearLayout) findViewById(R.id.ll_axis_bank);
        this.ll_kotak_mahindra_bank = (LinearLayout) findViewById(R.id.ll_kotak_mahindra_bank);
        this.ll_yes_bank = (LinearLayout) findViewById(R.id.ll_yes_bank);
        this.ll_punjab_national_bank = (LinearLayout) findViewById(R.id.ll_punjab_national_bank);
        this.ll_dena_bank = (LinearLayout) findViewById(R.id.ll_dena_bank);
        this.ll_canara_bank = (LinearLayout) findViewById(R.id.ll_canara_bank);
        this.ll_bank_of_india = (LinearLayout) findViewById(R.id.ll_bank_of_india);
        this.ll_corporation_bank = (LinearLayout) findViewById(R.id.ll_corporation_bank);
        this.ll_union_bank_of_india = (LinearLayout) findViewById(R.id.ll_union_bank_of_india);
        Common.Animation((ViewGroup) this.ll_state_bank_of_india);
        Common.Animation((ViewGroup) this.ll_idbi_bank);
        Common.Animation((ViewGroup) this.ll_bank_of_baroda);
        Common.Animation((ViewGroup) this.ll_central_bank_of_india);
        Common.Animation((ViewGroup) this.ll_hdfc_bank);
        Common.Animation((ViewGroup) this.ll_citi_bank);
        Common.Animation((ViewGroup) this.ll_axis_bank);
        Common.Animation((ViewGroup) this.ll_kotak_mahindra_bank);
        Common.Animation((ViewGroup) this.ll_yes_bank);
        Common.Animation((ViewGroup) this.ll_punjab_national_bank);
        Common.Animation((ViewGroup) this.ll_dena_bank);
        Common.Animation((ViewGroup) this.ll_canara_bank);
        Common.Animation((ViewGroup) this.ll_bank_of_india);
        Common.Animation((ViewGroup) this.ll_corporation_bank);
        Common.Animation((ViewGroup) this.ll_union_bank_of_india);
        this.ll_state_bank_of_india.setOnClickListener(this);
        this.ll_idbi_bank.setOnClickListener(this);
        this.ll_bank_of_baroda.setOnClickListener(this);
        this.ll_central_bank_of_india.setOnClickListener(this);
        this.ll_hdfc_bank.setOnClickListener(this);
        this.ll_citi_bank.setOnClickListener(this);
        this.ll_axis_bank.setOnClickListener(this);
        this.ll_kotak_mahindra_bank.setOnClickListener(this);
        this.ll_yes_bank.setOnClickListener(this);
        this.ll_punjab_national_bank.setOnClickListener(this);
        this.ll_dena_bank.setOnClickListener(this);
        this.ll_canara_bank.setOnClickListener(this);
        this.ll_bank_of_india.setOnClickListener(this);
        this.ll_corporation_bank.setOnClickListener(this);
        this.ll_union_bank_of_india.setOnClickListener(this);
        this.ll_uco_bank = (LinearLayout) findViewById(R.id.ll_uco_bank);
        this.ll_vijaya_bank = (LinearLayout) findViewById(R.id.ll_vijaya_bank);
        this.ll_south_indian_bank = (LinearLayout) findViewById(R.id.ll_south_indian_bank);
        this.ll_american_express = (LinearLayout) findViewById(R.id.ll_american_express);
        this.ll_hsbc_bank = (LinearLayout) findViewById(R.id.ll_hsbc_bank);
        this.ll_federal_bank = (LinearLayout) findViewById(R.id.ll_federal_bank);
        this.ll_indian_overseas_bank = (LinearLayout) findViewById(R.id.ll_indian_overseas_bank);
        this.ll_ing_vysya_bank = (LinearLayout) findViewById(R.id.ll_ing_vysya_bank);
        this.ll_karur_vysya_bank = (LinearLayout) findViewById(R.id.ll_karur_vysya_bank);
        this.ll_abn_amro = (LinearLayout) findViewById(R.id.ll_abn_amro);
        this.ll_allahabad_bank = (LinearLayout) findViewById(R.id.ll_allahabad_bank);
        this.ll_andhra_bank = (LinearLayout) findViewById(R.id.ll_andhra_bank);
        this.ll_anz_bank = (LinearLayout) findViewById(R.id.ll_anz_bank);
        this.ll_bank_of_maharashtra = (LinearLayout) findViewById(R.id.ll_bank_of_maharashtra);
        this.ll_barclays_bank = (LinearLayout) findViewById(R.id.ll_barclays_bank);
        Common.Animation((ViewGroup) this.ll_uco_bank);
        Common.Animation((ViewGroup) this.ll_vijaya_bank);
        Common.Animation((ViewGroup) this.ll_south_indian_bank);
        Common.Animation((ViewGroup) this.ll_american_express);
        Common.Animation((ViewGroup) this.ll_hsbc_bank);
        Common.Animation((ViewGroup) this.ll_federal_bank);
        Common.Animation((ViewGroup) this.ll_indian_overseas_bank);
        Common.Animation((ViewGroup) this.ll_ing_vysya_bank);
        Common.Animation((ViewGroup) this.ll_karur_vysya_bank);
        Common.Animation((ViewGroup) this.ll_abn_amro);
        Common.Animation((ViewGroup) this.ll_allahabad_bank);
        Common.Animation((ViewGroup) this.ll_andhra_bank);
        Common.Animation((ViewGroup) this.ll_anz_bank);
        Common.Animation((ViewGroup) this.ll_bank_of_maharashtra);
        Common.Animation((ViewGroup) this.ll_barclays_bank);
        this.ll_uco_bank.setOnClickListener(this);
        this.ll_vijaya_bank.setOnClickListener(this);
        this.ll_south_indian_bank.setOnClickListener(this);
        this.ll_american_express.setOnClickListener(this);
        this.ll_hsbc_bank.setOnClickListener(this);
        this.ll_federal_bank.setOnClickListener(this);
        this.ll_indian_overseas_bank.setOnClickListener(this);
        this.ll_ing_vysya_bank.setOnClickListener(this);
        this.ll_karur_vysya_bank.setOnClickListener(this);
        this.ll_abn_amro.setOnClickListener(this);
        this.ll_allahabad_bank.setOnClickListener(this);
        this.ll_andhra_bank.setOnClickListener(this);
        this.ll_anz_bank.setOnClickListener(this);
        this.ll_bank_of_maharashtra.setOnClickListener(this);
        this.ll_barclays_bank.setOnClickListener(this);
        this.ll_indian_bank = (LinearLayout) findViewById(R.id.ll_indian_bank);
        this.ll_bharatiya_mahila_bank = (LinearLayout) findViewById(R.id.ll_bharatiya_mahila_bank);
        this.ll_punjab_and_sind_bank = (LinearLayout) findViewById(R.id.ll_punjab_and_sind_bank);
        this.ll_cashnet_india = (LinearLayout) findViewById(R.id.ll_cashnet_india);
        this.ll_saraswat_bank = (LinearLayout) findViewById(R.id.ll_saraswat_bank);
        this.ll_centurion_bank_of_punjab = (LinearLayout) findViewById(R.id.ll_centurion_bank_of_punjab);
        this.ll_standard_chartered_bank = (LinearLayout) findViewById(R.id.ll_standard_chartered_bank);
        this.ll_state_bank_of_bikaner_and_jaipur = (LinearLayout) findViewById(R.id.ll_state_bank_of_bikaner_and_jaipur);
        this.ll_deutsche_bank = (LinearLayout) findViewById(R.id.ll_deutsche_bank);
        this.ll_state_bank_of_travancore = (LinearLayout) findViewById(R.id.ll_state_bank_of_travancore);
        this.ll_syndicate_bank = (LinearLayout) findViewById(R.id.ll_syndicate_bank);
        this.ll_dhanalakshmi_bank = (LinearLayout) findViewById(R.id.ll_dhanalakshmi_bank);
        this.ll_united_bank_of_india = (LinearLayout) findViewById(R.id.ll_united_bank_of_india);
        this.ll_karnataka_bank = (LinearLayout) findViewById(R.id.ll_karnataka_bank);
        Common.Animation((ViewGroup) this.ll_indian_bank);
        Common.Animation((ViewGroup) this.ll_bharatiya_mahila_bank);
        Common.Animation((ViewGroup) this.ll_punjab_and_sind_bank);
        Common.Animation((ViewGroup) this.ll_cashnet_india);
        Common.Animation((ViewGroup) this.ll_saraswat_bank);
        Common.Animation((ViewGroup) this.ll_centurion_bank_of_punjab);
        Common.Animation((ViewGroup) this.ll_standard_chartered_bank);
        Common.Animation((ViewGroup) this.ll_state_bank_of_bikaner_and_jaipur);
        Common.Animation((ViewGroup) this.ll_deutsche_bank);
        Common.Animation((ViewGroup) this.ll_state_bank_of_travancore);
        Common.Animation((ViewGroup) this.ll_syndicate_bank);
        Common.Animation((ViewGroup) this.ll_dhanalakshmi_bank);
        Common.Animation((ViewGroup) this.ll_united_bank_of_india);
        Common.Animation((ViewGroup) this.ll_karnataka_bank);
        this.ll_indian_bank.setOnClickListener(this);
        this.ll_bharatiya_mahila_bank.setOnClickListener(this);
        this.ll_punjab_and_sind_bank.setOnClickListener(this);
        this.ll_cashnet_india.setOnClickListener(this);
        this.ll_saraswat_bank.setOnClickListener(this);
        this.ll_centurion_bank_of_punjab.setOnClickListener(this);
        this.ll_standard_chartered_bank.setOnClickListener(this);
        this.ll_state_bank_of_bikaner_and_jaipur.setOnClickListener(this);
        this.ll_deutsche_bank.setOnClickListener(this);
        this.ll_state_bank_of_travancore.setOnClickListener(this);
        this.ll_syndicate_bank.setOnClickListener(this);
        this.ll_dhanalakshmi_bank.setOnClickListener(this);
        this.ll_united_bank_of_india.setOnClickListener(this);
        this.ll_karnataka_bank.setOnClickListener(this);
        this.appbarlay_tool = (AppBarLayout) findViewById(R.id.appbarlay_tool);
        this.nested_scroll = (NestedScrollView) findViewById(R.id.nested_scroll);
        this.down_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.down_anim_toolbar);
        this.up_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.up_anim_toolbar);
        NestedScrollView nestedScrollView = this.nested_scroll;
        if (nestedScrollView != null) {
            nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() { // from class: calldial.be.loctracker.BankInfo.BankInfoFirstActivity.8
                @Override // androidx.core.widget.NestedScrollView.OnScrollChangeListener
                public void onScrollChange(NestedScrollView nestedScrollView2, int i, int i2, int i3, int i4) {
                    if (i2 > i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling DOWN");
                        if (BankInfoFirstActivity.IS_UP) {
                            BankInfoFirstActivity.this.appbarlay_tool.startAnimation(BankInfoFirstActivity.this.up_anim_toolbar);
                            BankInfoFirstActivity.IS_UP = false;
                            BankInfoFirstActivity.IS_DOWN = true;
                        }
                    }
                    if (i2 < i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling UP");
                        if (BankInfoFirstActivity.IS_DOWN) {
                            BankInfoFirstActivity.this.appbarlay_tool.startAnimation(BankInfoFirstActivity.this.down_anim_toolbar);
                            BankInfoFirstActivity.IS_DOWN = false;
                            BankInfoFirstActivity.IS_UP = true;
                        }
                    }
                    if (i2 == 0) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to TOP SCROLL");
                    }
                    if (i2 == nestedScrollView2.getMeasuredHeight() - nestedScrollView2.getChildAt(0).getMeasuredHeight()) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to BOTTOM SCROLL");
                    }
                }
            });
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ll_abn_amro /* 2131362201 */:
                Intent intent = new Intent(this, BankInfoSecondActivity.class);
                intent.putExtra("BANK_LOGO", R.drawable.bank_abn_amro);
                intent.putExtra("BANK_NAME", "ABN AMRO");
                intent.putExtra("CHECK_BALANCE", "1800112224");
                intent.putExtra("CUSTOMER_CARE", "1800112224");
                startActivity(intent);
                return;
            case R.id.ll_aircel /* 2131362202 */:
            case R.id.ll_airtel /* 2131362203 */:
            case R.id.ll_bsnl /* 2131362214 */:
            case R.id.ll_call_now /* 2131362215 */:
            case R.id.ll_docomo /* 2131362225 */:
            case R.id.ll_find_by_city /* 2131362227 */:
            case R.id.ll_find_by_city_et /* 2131362228 */:
            case R.id.ll_find_by_std_code /* 2131362229 */:
            case R.id.ll_find_by_std_code_et /* 2131362230 */:
            case R.id.ll_idea /* 2131362234 */:
            case R.id.ll_jio /* 2131362238 */:
            case R.id.ll_live_location_google_map /* 2131362242 */:
            case R.id.ll_more /* 2131362243 */:
            case R.id.ll_rate /* 2131362246 */:
            case R.id.ll_share /* 2131362248 */:
            case R.id.ll_start /* 2131362251 */:
            case R.id.ll_telenor /* 2131362256 */:
//            case R.id.ll_top /* 2131362257 */:
            case R.id.ll_vodafone /* 2131362262 */:
            default:
                return;
            case R.id.ll_allahabad_bank /* 2131362204 */:
                Intent intent2 = new Intent(this, BankInfoSecondActivity.class);
                intent2.putExtra("BANK_LOGO", R.drawable.bank_allhabad_bank);
                intent2.putExtra("BANK_NAME", "Allahabad Bank");
                intent2.putExtra("CHECK_BALANCE", "1800226061");
                intent2.putExtra("CUSTOMER_CARE", "09224150150");
                startActivity(intent2);
                return;
            case R.id.ll_american_express /* 2131362205 */:
                Intent intent3 = new Intent(this, BankInfoSecondActivity.class);
                intent3.putExtra("BANK_LOGO", R.drawable.bank_american_express);
                intent3.putExtra("BANK_NAME", "American Express");
                intent3.putExtra("CHECK_BALANCE", "1800446630");
                intent3.putExtra("CUSTOMER_CARE", "1800446630");
                startActivity(intent3);
                return;
            case R.id.ll_andhra_bank /* 2131362206 */:
                Intent intent4 = new Intent(this, BankInfoSecondActivity.class);
                intent4.putExtra("BANK_LOGO", R.drawable.bank_andhra_bank);
                intent4.putExtra("BANK_NAME", "Andhra Bank");
                intent4.putExtra("CHECK_BALANCE", "18004251515");
                intent4.putExtra("CUSTOMER_CARE", "09223011300");
                startActivity(intent4);
                return;
            case R.id.ll_anz_bank /* 2131362207 */:
                Intent intent5 = new Intent(this, BankInfoSecondActivity.class);
                intent5.putExtra("BANK_LOGO", R.drawable.bank_anz_bank);
                intent5.putExtra("BANK_NAME", "ANZ Bank");
                intent5.putExtra("CHECK_BALANCE", "18002000269");
                intent5.putExtra("CUSTOMER_CARE", "18002000269");
                startActivity(intent5);
                return;
            case R.id.ll_axis_bank /* 2131362208 */:
                Intent intent6 = new Intent(this, BankInfoSecondActivity.class);
                intent6.putExtra("BANK_LOGO", R.drawable.bank_axis_bank);
                intent6.putExtra("BANK_NAME", "Axis Bank");
                intent6.putExtra("CHECK_BALANCE", "18002095577");
                intent6.putExtra("CUSTOMER_CARE", "18004195959");
                startActivity(intent6);
                return;
            case R.id.ll_bank_of_baroda /* 2131362209 */:
                Intent intent7 = new Intent(this, BankInfoSecondActivity.class);
                intent7.putExtra("BANK_LOGO", R.drawable.bank_of_baroda);
                intent7.putExtra("BANK_NAME", "IDBI Bank");
                intent7.putExtra("CHECK_BALANCE", "18002001947");
                intent7.putExtra("CUSTOMER_CARE", "18008431122");
                startActivity(intent7);
                return;
            case R.id.ll_bank_of_india /* 2131362210 */:
                Intent intent8 = new Intent(this, BankInfoSecondActivity.class);
                intent8.putExtra("BANK_LOGO", R.drawable.bank_of_india);
                intent8.putExtra("BANK_NAME", "Bank of India");
                intent8.putExtra("CHECK_BALANCE", "1800220229");
                intent8.putExtra("CUSTOMER_CARE", "09015135135");
                startActivity(intent8);
                return;
            case R.id.ll_bank_of_maharashtra /* 2131362211 */:
                Intent intent9 = new Intent(this, BankInfoSecondActivity.class);
                intent9.putExtra("BANK_LOGO", R.drawable.bank_of_maharashtra);
                intent9.putExtra("BANK_NAME", "Bank Of Maharastra");
                intent9.putExtra("CHECK_BALANCE", "18002334526");
                intent9.putExtra("CUSTOMER_CARE", "09222281818");
                startActivity(intent9);
                return;
            case R.id.ll_barclays_bank /* 2131362212 */:
                Intent intent10 = new Intent(this, BankInfoSecondActivity.class);
                intent10.putExtra("BANK_LOGO", R.drawable.bank_barclays_bank);
                intent10.putExtra("BANK_NAME", "Barclays Bank");
                intent10.putExtra("CHECK_BALANCE", "00442476842100");
                intent10.putExtra("CUSTOMER_CARE", "18002336565");
                startActivity(intent10);
                return;
            case R.id.ll_bharatiya_mahila_bank /* 2131362213 */:
                Intent intent11 = new Intent(this, BankInfoSecondActivity.class);
                intent11.putExtra("BANK_LOGO", R.drawable.bank_bharatiya_mahila_bank);
                intent11.putExtra("BANK_NAME", "Bharatiya Mahila Bank");
                intent11.putExtra("CHECK_BALANCE", "01147472100");
                intent11.putExtra("CUSTOMER_CARE", "09212438888");
                startActivity(intent11);
                return;
            case R.id.ll_canara_bank /* 2131362216 */:
                Intent intent12 = new Intent(this, BankInfoSecondActivity.class);
                intent12.putExtra("BANK_LOGO", R.drawable.bank_canara_bank);
                intent12.putExtra("BANK_NAME", "Canara Bank");
                intent12.putExtra("CHECK_BALANCE", "18004250018");
                intent12.putExtra("CUSTOMER_CARE", "09015483483");
                startActivity(intent12);
                return;
            case R.id.ll_cashnet_india /* 2131362217 */:
                Intent intent13 = new Intent(this, BankInfoSecondActivity.class);
                intent13.putExtra("BANK_LOGO", R.drawable.bank_cashnet_bank);
                intent13.putExtra("BANK_NAME", "Cashnet India");
                intent13.putExtra("CHECK_BALANCE", "1800225087");
                intent13.putExtra("CUSTOMER_CARE", "1800225087");
                startActivity(intent13);
                return;
            case R.id.ll_central_bank_of_india /* 2131362218 */:
                Intent intent14 = new Intent(this, BankInfoSecondActivity.class);
                intent14.putExtra("BANK_LOGO", R.drawable.bank_central_bank_of_india);
                intent14.putExtra("BANK_NAME", "Central Bank Of India");
                intent14.putExtra("CHECK_BALANCE", "18002001911");
                intent14.putExtra("CUSTOMER_CARE", "09222250000");
                startActivity(intent14);
                return;
            case R.id.ll_centurion_bank_of_punjab /* 2131362219 */:
                Intent intent15 = new Intent(this, BankInfoSecondActivity.class);
                intent15.putExtra("BANK_LOGO", R.drawable.bank_centurion_bank_of_punjab);
                intent15.putExtra("BANK_NAME", "Centurion Bank of Punjab");
                intent15.putExtra("CHECK_BALANCE", "18004253555");
                intent15.putExtra("CUSTOMER_CARE", "1800443555");
                startActivity(intent15);
                return;
            case R.id.ll_citi_bank /* 2131362220 */:
                Intent intent16 = new Intent(this, BankInfoSecondActivity.class);
                intent16.putExtra("BANK_LOGO", R.drawable.bank_citi_bank);
                intent16.putExtra("BANK_NAME", "Citi Bank");
                intent16.putExtra("CHECK_BALANCE", "1800226747");
                intent16.putExtra("CUSTOMER_CARE", "18004252484");
                startActivity(intent16);
                return;
            case R.id.ll_corporation_bank /* 2131362221 */:
                Intent intent17 = new Intent(this, BankInfoSecondActivity.class);
                intent17.putExtra("BANK_LOGO", R.drawable.bank_corporation_bank);
                intent17.putExtra("BANK_NAME", "Corporation Bank");
                intent17.putExtra("CHECK_BALANCE", "18004253555");
                intent17.putExtra("CUSTOMER_CARE", "09268892688");
                startActivity(intent17);
                return;
            case R.id.ll_dena_bank /* 2131362222 */:
                Intent intent18 = new Intent(this, BankInfoSecondActivity.class);
                intent18.putExtra("BANK_LOGO", R.drawable.bank_dena_bank);
                intent18.putExtra("BANK_NAME", "Dena Bank");
                intent18.putExtra("CHECK_BALANCE", "18002336427");
                intent18.putExtra("CUSTOMER_CARE", "09289356677");
                startActivity(intent18);
                return;
            case R.id.ll_deutsche_bank /* 2131362223 */:
                Intent intent19 = new Intent(this, BankInfoSecondActivity.class);
                intent19.putExtra("BANK_LOGO", R.drawable.bank_deutsche_bank);
                intent19.putExtra("BANK_NAME", "Deutsche Bank");
                intent19.putExtra("CHECK_BALANCE", "18001236601");
                intent19.putExtra("CUSTOMER_CARE", "18001236601");
                startActivity(intent19);
                return;
            case R.id.ll_dhanalakshmi_bank /* 2131362224 */:
                Intent intent20 = new Intent(this, BankInfoSecondActivity.class);
                intent20.putExtra("BANK_LOGO", R.drawable.bank_dhanlaxmi_bank);
                intent20.putExtra("BANK_NAME", "Dhanalakshmi Bank");
                intent20.putExtra("CHECK_BALANCE", "18004251747");
                intent20.putExtra("CUSTOMER_CARE", "0867747700");
                startActivity(intent20);
                return;
            case R.id.ll_federal_bank /* 2131362226 */:
                Intent intent21 = new Intent(this, BankInfoSecondActivity.class);
                intent21.putExtra("BANK_LOGO", R.drawable.bank_federal_bank);
                intent21.putExtra("BANK_NAME", "Federal Bank");
                intent21.putExtra("CHECK_BALANCE", "18004251199");
                intent21.putExtra("CUSTOMER_CARE", "8431900900");
                startActivity(intent21);
                return;
            case R.id.ll_hdfc_bank /* 2131362231 */:
                Intent intent22 = new Intent(this, BankInfoSecondActivity.class);
                intent22.putExtra("BANK_LOGO", R.drawable.bank_hdfc_bank);
                intent22.putExtra("BANK_NAME", "HDFC Bank");
                intent22.putExtra("CHECK_BALANCE", "1800255488");
                intent22.putExtra("CUSTOMER_CARE", "1900888888");
                startActivity(intent22);
                return;
            case R.id.ll_hsbc_bank /* 2131362232 */:
                Intent intent23 = new Intent(this, BankInfoSecondActivity.class);
                intent23.putExtra("BANK_LOGO", R.drawable.bank_hsbc_bank);
                intent23.putExtra("BANK_NAME", "HSBC Bank");
                intent23.putExtra("CHECK_BALANCE", "18001034722");
                intent23.putExtra("CUSTOMER_CARE", "18001034722");
                startActivity(intent23);
                return;
            case R.id.ll_idbi_bank /* 2131362233 */:
                Intent intent24 = new Intent(this, BankInfoSecondActivity.class);
                intent24.putExtra("BANK_LOGO", R.drawable.bank_idbi_bank);
                intent24.putExtra("BANK_NAME", "HelloWorld");
                intent24.putExtra("CHECK_BALANCE", "1800255488");
                intent24.putExtra("CUSTOMER_CARE", "1900888888");
                startActivity(intent24);
                return;
            case R.id.ll_indian_bank /* 2131362235 */:
                Intent intent25 = new Intent(this, BankInfoSecondActivity.class);
                intent25.putExtra("BANK_LOGO", R.drawable.bank_indian_bank);
                intent25.putExtra("BANK_NAME", "Indian Bank");
                intent25.putExtra("CHECK_BALANCE", "180042500000");
                intent25.putExtra("CUSTOMER_CARE", "09289592895");
                startActivity(intent25);
                return;
            case R.id.ll_indian_overseas_bank /* 2131362236 */:
                Intent intent26 = new Intent(this, BankInfoSecondActivity.class);
                intent26.putExtra("BANK_LOGO", R.drawable.bank_indian_overseas_bank);
                intent26.putExtra("BANK_NAME", "Indian Overseas Bank");
                intent26.putExtra("CHECK_BALANCE", "18004254445");
                intent26.putExtra("CUSTOMER_CARE", "18004254445");
                startActivity(intent26);
                return;
            case R.id.ll_ing_vysya_bank /* 2131362237 */:
                Intent intent27 = new Intent(this, BankInfoSecondActivity.class);
                intent27.putExtra("BANK_LOGO", R.drawable.bank_ing_bank);
                intent27.putExtra("BANK_NAME", "ING Vysya Bank");
                intent27.putExtra("CHECK_BALANCE", "18004209900");
                intent27.putExtra("CUSTOMER_CARE", "18004209900");
                startActivity(intent27);
                return;
            case R.id.ll_karnataka_bank /* 2131362239 */:
                Intent intent28 = new Intent(this, BankInfoSecondActivity.class);
                intent28.putExtra("BANK_LOGO", R.drawable.bank_karnataka_bank);
                intent28.putExtra("BANK_NAME", "Karnataka Bank");
                intent28.putExtra("CHECK_BALANCE", "18004251444");
                intent28.putExtra("CUSTOMER_CARE", "18004251445");
                startActivity(intent28);
                return;
            case R.id.ll_karur_vysya_bank /* 2131362240 */:
                Intent intent29 = new Intent(this, BankInfoSecondActivity.class);
                intent29.putExtra("BANK_LOGO", R.drawable.bank_karur_vysya_bank);
                intent29.putExtra("BANK_NAME", "Karur Vysya Bank");
                intent29.putExtra("CHECK_BALANCE", "18602001916");
                intent29.putExtra("CUSTOMER_CARE", "09266292666");
                startActivity(intent29);
                return;
            case R.id.ll_kotak_mahindra_bank /* 2131362241 */:
                Intent intent30 = new Intent(this, BankInfoSecondActivity.class);
                intent30.putExtra("BANK_LOGO", R.drawable.bank_kotak_bank);
                intent30.putExtra("BANK_NAME", "Kotak Mahindra Bank");
                intent30.putExtra("CHECK_BALANCE", "18602662666");
                intent30.putExtra("CUSTOMER_CARE", "18002740110");
                startActivity(intent30);
                return;
            case R.id.ll_punjab_and_sind_bank /* 2131362244 */:
                Intent intent31 = new Intent(this, BankInfoSecondActivity.class);
                intent31.putExtra("BANK_LOGO", R.drawable.bank_punjab_and_sind_bank);
                intent31.putExtra("BANK_NAME", "Punjab and Sind Bank");
                intent31.putExtra("CHECK_BALANCE", "1800221908");
                intent31.putExtra("CUSTOMER_CARE", "1800221908");
                startActivity(intent31);
                return;
            case R.id.ll_punjab_national_bank /* 2131362245 */:
                Intent intent32 = new Intent(this, BankInfoSecondActivity.class);
                intent32.putExtra("BANK_LOGO", R.drawable.bank_punjab_national_bank);
                intent32.putExtra("BANK_NAME", "Punjab National Bank");
                intent32.putExtra("CHECK_BALANCE", "18001802222");
                intent32.putExtra("CUSTOMER_CARE", "18001802222");
                startActivity(intent32);
                return;
            case R.id.ll_saraswat_bank /* 2131362247 */:
                Intent intent33 = new Intent(this, BankInfoSecondActivity.class);
                intent33.putExtra("BANK_LOGO", R.drawable.bank_saraswat_bank);
                intent33.putExtra("BANK_NAME", "Saraswat Bank");
                intent33.putExtra("CHECK_BALANCE", "1800229999");
                intent33.putExtra("CUSTOMER_CARE", "9223040000");
                startActivity(intent33);
                return;
            case R.id.ll_south_indian_bank /* 2131362249 */:
                Intent intent34 = new Intent(this, BankInfoSecondActivity.class);
                intent34.putExtra("BANK_LOGO", R.drawable.bank_south_indian_bank);
                intent34.putExtra("BANK_NAME", "South India Bank");
                intent34.putExtra("CHECK_BALANCE", "18008431800");
                intent34.putExtra("CUSTOMER_CARE", "09223008488");
                startActivity(intent34);
                return;
            case R.id.ll_standard_chartered_bank /* 2131362250 */:
                Intent intent35 = new Intent(this, BankInfoSecondActivity.class);
                intent35.putExtra("BANK_LOGO", R.drawable.bank_standard_chartered_bank);
                intent35.putExtra("BANK_NAME", "Standard Chartered Bank");
                intent35.putExtra("CHECK_BALANCE", "18003455000");
                intent35.putExtra("CUSTOMER_CARE", "18003451212");
                startActivity(intent35);
                return;
            case R.id.ll_state_bank_of_bikaner_and_jaipur /* 2131362252 */:
                Intent intent36 = new Intent(this, BankInfoSecondActivity.class);
                intent36.putExtra("BANK_LOGO", R.drawable.bank_state_bank_of_bikaner_and_jaipur);
                intent36.putExtra("BANK_NAME", "State Bank Of Bikaner and Jaipur");
                intent36.putExtra("CHECK_BALANCE", "18001806005");
                intent36.putExtra("CUSTOMER_CARE", "09223866666");
                startActivity(intent36);
                return;
            case R.id.ll_state_bank_of_india /* 2131362253 */:
                Intent intent37 = new Intent(this, BankInfoSecondActivity.class);
                intent37.putExtra("BANK_LOGO", R.drawable.bank_state_bank_of_india);
                intent37.putExtra("BANK_NAME", "State Bank Of India");
                intent37.putExtra("CHECK_BALANCE", "18004253800");
                intent37.putExtra("CUSTOMER_CARE", "09223766666");
                startActivity(intent37);
                return;
            case R.id.ll_state_bank_of_travancore /* 2131362254 */:
                Intent intent38 = new Intent(this, BankInfoSecondActivity.class);
                intent38.putExtra("BANK_LOGO", R.drawable.bank_state_bank_of_travancore);
                intent38.putExtra("BANK_NAME", "State Bank of Travancore");
                intent38.putExtra("CHECK_BALANCE", "18004255566");
                intent38.putExtra("CUSTOMER_CARE", "09223866666");
                startActivity(intent38);
                return;
            case R.id.ll_syndicate_bank /* 2131362255 */:
                Intent intent39 = new Intent(this, BankInfoSecondActivity.class);
                intent39.putExtra("BANK_LOGO", R.drawable.bank_syndicate_bank);
                intent39.putExtra("BANK_NAME", "Syndicate Bank");
                intent39.putExtra("CHECK_BALANCE", "08026639966");
                intent39.putExtra("CUSTOMER_CARE", "09664552255");
                startActivity(intent39);
                return;
            case R.id.ll_uco_bank /* 2131362258 */:
                Intent intent40 = new Intent(this, BankInfoSecondActivity.class);
                intent40.putExtra("BANK_LOGO", R.drawable.bank_uco_bank);
                intent40.putExtra("BANK_NAME", "UCO Bank");
                intent40.putExtra("CHECK_BALANCE", "18001030123");
                intent40.putExtra("CUSTOMER_CARE", "09278792787");
                startActivity(intent40);
                return;
            case R.id.ll_union_bank_of_india /* 2131362259 */:
                Intent intent41 = new Intent(this, BankInfoSecondActivity.class);
                intent41.putExtra("BANK_LOGO", R.drawable.bank_union_bank_of_india);
                intent41.putExtra("BANK_NAME", "Union Bank Of India");
                intent41.putExtra("CHECK_BALANCE", "18001030123");
                intent41.putExtra("CUSTOMER_CARE", "09278792787");
                startActivity(intent41);
                return;
            case R.id.ll_united_bank_of_india /* 2131362260 */:
                Intent intent42 = new Intent(this, BankInfoSecondActivity.class);
                intent42.putExtra("BANK_LOGO", R.drawable.bank_united_bank_of_india);
                intent42.putExtra("BANK_NAME", "United Bank Of India");
                intent42.putExtra("CHECK_BALANCE", "18003450345");
                intent42.putExtra("CUSTOMER_CARE", "09015431345");
                startActivity(intent42);
                return;
            case R.id.ll_vijaya_bank /* 2131362261 */:
                Intent intent43 = new Intent(this, BankInfoSecondActivity.class);
                intent43.putExtra("BANK_LOGO", R.drawable.bank_vijaya_bank);
                intent43.putExtra("BANK_NAME", "Vijay Bank");
                intent43.putExtra("CHECK_BALANCE", "18004255885");
                intent43.putExtra("CUSTOMER_CARE", "18002665555");
                startActivity(intent43);
                return;
            case R.id.ll_yes_bank /* 2131362263 */:
                Intent intent44 = new Intent(this, BankInfoSecondActivity.class);
                intent44.putExtra("BANK_LOGO", R.drawable.bank_yes_bank);
                intent44.putExtra("BANK_NAME", "Yes Bank");
                intent44.putExtra("CHECK_BALANCE", "18002000");
                intent44.putExtra("CUSTOMER_CARE", "09840909000");
                startActivity(intent44);
                return;
        }
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (this.mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            this.mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            AllAdsKeyPlace.CloseActivityWithAds(this, "true");
        }
    }
}
