package calldial.be.loctracker.Compass.util;

import android.content.res.Resources;

/* loaded from: classes.dex */
public class AndroidUtilsCompass {
    private AndroidUtilsCompass() {
    }

    public static float dpToPx(int i) {
        return dpToPx(i);
    }

    public static float dpToPx(float f) {
        return f * Resources.getSystem().getDisplayMetrics().density;
    }

    public static float pxToDp(int i) {
        return pxToDp(i);
    }

    public static float pxToDp(float f) {
        return f / Resources.getSystem().getDisplayMetrics().density;
    }
}
