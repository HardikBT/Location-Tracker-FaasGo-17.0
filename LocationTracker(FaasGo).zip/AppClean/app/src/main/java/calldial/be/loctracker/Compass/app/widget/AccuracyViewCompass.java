package calldial.be.loctracker.Compass.app.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;

/* loaded from: classes.dex */
public class AccuracyViewCompass extends View {
    private ViewDrawerCompass<Integer> drawer;
    private int accuracy = 0;
    private boolean isSimple = false;

    public AccuracyViewCompass(Context context) {
        super(context);
        init(context);
    }

    public AccuracyViewCompass(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(context);
    }

    public AccuracyViewCompass(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init(context);
    }

    private void init(Context context) {
        if (this.isSimple) {
            this.drawer = new AccuracyDrawerSimpleCompass(context);
        } else {
            this.drawer = new AccuracyDrawerCompass(context);
        }
    }

    @Override // android.view.View
    protected void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        int size = MeasureSpec.getSize(i);
        int size2 = MeasureSpec.getSize(i2);
        if (size > size2) {
            size = size2;
        }
        setMeasuredDimension(resolveSize(size, i), resolveSize(size, i2));
    }

    @Override // android.view.View
    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        this.drawer.layout(getWidth(), getHeight());
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.drawer.draw(canvas);
    }

    public void updateAccuracyField(int i) {
        if (this.accuracy != i) {
            this.accuracy = i;
            this.drawer.update(Integer.valueOf(i));
            invalidate();
        }
    }

    public void setSimpleMode(boolean z) {
        if (this.isSimple != z) {
            this.isSimple = z;
            if (z) {
                this.drawer = new AccuracyDrawerSimpleCompass(getContext());
            } else {
                this.drawer = new AccuracyDrawerCompass(getContext());
            }
            this.drawer.update(Integer.valueOf(this.accuracy));
            requestLayout();
        }
    }
}
