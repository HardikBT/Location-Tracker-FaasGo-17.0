package calldial.be.loctracker.Compass.app.settings;

import android.app.Activity;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

import calldial.be.loctracker.R;

/* loaded from: classes.dex */
public class ThemeColorAdapterCompass extends ArrayAdapter<ThemeColorAdapterCompass.ThemeItem> {
    private List<ThemeItem> data;
    private LayoutInflater inflater;

    /* JADX INFO: Access modifiers changed from: package-private */
    public ThemeColorAdapterCompass(Activity activity, int i, int i2, List<ThemeItem> list) {
        super(activity, i, i2, list);
        this.inflater = activity.getLayoutInflater();
        this.data = list;
    }

    @Override // android.widget.ArrayAdapter, android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        return getView(view, i, viewGroup, true);
    }

    @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
    public View getDropDownView(int i, View view, ViewGroup viewGroup) {
        return getView(view, i, viewGroup, false);
    }

    private View getView(View view, int i, ViewGroup viewGroup, boolean z) {
        if (view == null) {
            view = this.inflater.inflate(R.layout.list_item_spinner_compass, viewGroup, false);
        }
        TextView textView = (TextView) view.findViewById(R.id.txtColor);
        textView.setText(this.data.get(i).getColorName());
        if (!z) {
            textView.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, 0, 0);
            Resources resources = getContext().getResources();
            int dimension = (int) resources.getDimension(R.dimen.spacing_normal);
            textView.setPadding((int) resources.getDimension(R.dimen.spacing_huge), dimension, dimension, dimension);
            textView.setBackgroundColor(this.data.get(i).getColor());
        } else {
            textView.setBackgroundColor(getContext().getResources().getColor(R.color.transparent));
        }
        return textView;
    }

    /* loaded from: classes.dex */
    public static class ThemeItem {
        private int color;
        private String colorName;

        /* JADX INFO: Access modifiers changed from: package-private */
        public ThemeItem(String str, int i) {
            this.colorName = str;
            this.color = i;
        }

        String getColorName() {
            return this.colorName;
        }

        public int getColor() {
            return this.color;
        }
    }
}
