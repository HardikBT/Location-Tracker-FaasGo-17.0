package calldial.be.loctracker.InfoFromMobileNumber;

/* loaded from: classes.dex */
public class Information {
    public String company;
    public String state;

    public String getCopany() {
        return this.company;
    }

    public void setCopany(String str) {
        this.company = str;
    }

    public String getState() {
        return this.state;
    }

    public void setState(String str) {
        this.state = str;
    }

    public Information(String str, String str2) {
        this.company = str;
        this.state = str2;
    }

    public Information() {
    }
}
