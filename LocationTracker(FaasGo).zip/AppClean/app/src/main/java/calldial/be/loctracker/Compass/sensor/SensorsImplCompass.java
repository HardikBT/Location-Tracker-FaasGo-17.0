package calldial.be.loctracker.Compass.sensor;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

/* loaded from: classes.dex */
public class SensorsImplCompass implements SensorsContractCompass.Sensors {
    private static float ALPHA = 0.96f;
    private static float ALPHA2 = 0.8f;
    private static int SAMPLING_PERIOD = 1;
    private static int UPDATE_INTERVAL = 10;
    private static int UPDATE_INTERVAL2 = 40;
    private Sensor accelerometerSensor;
    private SensorsContractCompass.SensorsCallback callback;
    private boolean energySavingMode;
    private Sensor gravitySensor;
    private Sensor magneticSensor;
    private SensorEventListener sensorEventListener;
    private SensorManager sensorManager;
    private float[] acceleration = new float[3];
    private float[] gravity = new float[3];
    private float[] geomagnetic = new float[3];
    private float[] rotationMatrixR = new float[9];
    private float[] orientation = new float[3];
    private long accelerometerPrevTime = 0;
    private long linearAccelerometerPrevTime = 0;
    private long magneticPrevTime = 0;

    @Override // calldial.be.loctracker.Compass.sensor.SensorsContractCompass.Sensors
    public void setEnergySavingMode(boolean z) {
        this.energySavingMode = z;
        if (z) {
            ALPHA = 0.92f;
            ALPHA2 = 0.75f;
            UPDATE_INTERVAL = 30;
            UPDATE_INTERVAL2 = 120;
            SAMPLING_PERIOD = 2;
        } else {
            ALPHA = 0.96f;
            ALPHA2 = 0.8f;
            UPDATE_INTERVAL = 10;
            UPDATE_INTERVAL2 = 40;
            SAMPLING_PERIOD = 1;
        }
        init();
    }

    public SensorsImplCompass(Context context) {
        this.sensorManager = (SensorManager) context.getSystemService("sensor");
        init();
    }

    private void init() {
        this.accelerometerSensor = this.sensorManager.getDefaultSensor(1);
        this.magneticSensor = this.sensorManager.getDefaultSensor(2);
        if (this.energySavingMode) {
            this.gravitySensor = null;
        } else {
            this.gravitySensor = this.sensorManager.getDefaultSensor(9);
        }
        this.sensorEventListener = new SensorEventListener() { // from class: calldial.be.loctracker.Compass.sensor.SensorsImplCompass.1
            @Override // android.hardware.SensorEventListener
            public void onSensorChanged(SensorEvent sensorEvent) {
                if (SensorsImplCompass.this.callback != null) {
                    long currentTimeMillis = System.currentTimeMillis();
                    int type = sensorEvent.sensor.getType();
                    if (type == 1) {
                        if (SensorsImplCompass.this.gravitySensor == null) {
                            SensorsImplCompass.this.gravity[0] = (SensorsImplCompass.ALPHA * SensorsImplCompass.this.gravity[0]) + ((1.0f - SensorsImplCompass.ALPHA) * sensorEvent.values[0]);
                            SensorsImplCompass.this.gravity[1] = (SensorsImplCompass.ALPHA * SensorsImplCompass.this.gravity[1]) + ((1.0f - SensorsImplCompass.ALPHA) * sensorEvent.values[1]);
                            SensorsImplCompass.this.gravity[2] = (SensorsImplCompass.ALPHA * SensorsImplCompass.this.gravity[2]) + ((1.0f - SensorsImplCompass.ALPHA) * sensorEvent.values[2]);
                            SensorsImplCompass.this.updateOrientation(currentTimeMillis);
                        }
                        SensorsImplCompass.this.acceleration[0] = (SensorsImplCompass.ALPHA2 * SensorsImplCompass.this.acceleration[0]) + ((1.0f - SensorsImplCompass.ALPHA2) * (sensorEvent.values[0] - SensorsImplCompass.this.gravity[0]));
                        SensorsImplCompass.this.acceleration[1] = (SensorsImplCompass.ALPHA2 * SensorsImplCompass.this.acceleration[1]) + ((1.0f - SensorsImplCompass.ALPHA2) * (sensorEvent.values[1] - SensorsImplCompass.this.gravity[1]));
                        SensorsImplCompass.this.acceleration[2] = (SensorsImplCompass.ALPHA2 * SensorsImplCompass.this.acceleration[2]) + ((1.0f - SensorsImplCompass.ALPHA2) * (sensorEvent.values[2] - SensorsImplCompass.this.gravity[2]));
                        if (currentTimeMillis - SensorsImplCompass.this.linearAccelerometerPrevTime > SensorsImplCompass.UPDATE_INTERVAL) {
                            SensorsImplCompass.this.callback.onLinearAccelerationChange(SensorsImplCompass.this.acceleration[0], SensorsImplCompass.this.acceleration[1], SensorsImplCompass.this.acceleration[2]);
                            SensorsImplCompass.this.linearAccelerometerPrevTime = currentTimeMillis;
                        }
                    } else if (type == 2) {
                        SensorsImplCompass.this.geomagnetic[0] = (SensorsImplCompass.ALPHA * SensorsImplCompass.this.geomagnetic[0]) + ((1.0f - SensorsImplCompass.ALPHA) * sensorEvent.values[0]);
                        SensorsImplCompass.this.geomagnetic[1] = (SensorsImplCompass.ALPHA * SensorsImplCompass.this.geomagnetic[1]) + ((1.0f - SensorsImplCompass.ALPHA) * sensorEvent.values[1]);
                        SensorsImplCompass.this.geomagnetic[2] = (SensorsImplCompass.ALPHA * SensorsImplCompass.this.geomagnetic[2]) + ((1.0f - SensorsImplCompass.ALPHA) * sensorEvent.values[2]);
                        float sqrt = (float) Math.sqrt((SensorsImplCompass.this.geomagnetic[0] * SensorsImplCompass.this.geomagnetic[0]) + (SensorsImplCompass.this.geomagnetic[1] * SensorsImplCompass.this.geomagnetic[1]) + (SensorsImplCompass.this.geomagnetic[2] * SensorsImplCompass.this.geomagnetic[2]));
                        if (currentTimeMillis - SensorsImplCompass.this.magneticPrevTime > SensorsImplCompass.UPDATE_INTERVAL2) {
                            SensorsImplCompass.this.callback.onMagneticFieldChange(sqrt);
                            SensorsImplCompass.this.magneticPrevTime = currentTimeMillis;
                        }
                    } else if (type == 9 && SensorsImplCompass.this.gravitySensor != null) {
                        SensorsImplCompass.this.gravity[0] = sensorEvent.values[0];
                        SensorsImplCompass.this.gravity[1] = sensorEvent.values[1];
                        SensorsImplCompass.this.gravity[2] = sensorEvent.values[2];
                        SensorsImplCompass.this.updateOrientation(currentTimeMillis);
                    }
                }
            }

            @Override // android.hardware.SensorEventListener
            public void onAccuracyChanged(Sensor sensor, int i) {
                if (sensor.getType() == 2 && SensorsImplCompass.this.callback != null) {
                    SensorsImplCompass.this.callback.onAccuracyChanged(i);
                }
            }
        };
    }

    @Override // calldial.be.loctracker.Compass.sensor.SensorsContractCompass.Sensors
    public void setSensorsCallback(SensorsContractCompass.SensorsCallback sensorsCallback) {
        this.callback = sensorsCallback;
        if (this.accelerometerSensor == null || this.magneticSensor == null) {
            sensorsCallback.onSensorsNotFound();
        }
    }

    @Override // calldial.be.loctracker.Compass.sensor.SensorsContractCompass.Sensors
    public void start() {
        this.sensorManager.registerListener(this.sensorEventListener, this.accelerometerSensor, SAMPLING_PERIOD);
        this.sensorManager.registerListener(this.sensorEventListener, this.magneticSensor, SAMPLING_PERIOD);
        this.sensorManager.registerListener(this.sensorEventListener, this.gravitySensor, SAMPLING_PERIOD);
    }

    @Override // calldial.be.loctracker.Compass.sensor.SensorsContractCompass.Sensors
    public void stop() {
        this.sensorManager.unregisterListener(this.sensorEventListener);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateOrientation(long j) {
        SensorsContractCompass.SensorsCallback sensorsCallback;
        if (SensorManager.getRotationMatrix(this.rotationMatrixR, null, this.gravity, this.geomagnetic)) {
            float[] orientation = SensorManager.getOrientation(this.rotationMatrixR, this.orientation);
            this.orientation = orientation;
            if (j - this.accelerometerPrevTime > UPDATE_INTERVAL && (sensorsCallback = this.callback) != null) {
                sensorsCallback.onRotationChange((float) Math.toDegrees(orientation[0]), (float) Math.toDegrees(this.orientation[1]), (float) Math.toDegrees(this.orientation[2]));
                this.accelerometerPrevTime = j;
            }
        }
    }
}
