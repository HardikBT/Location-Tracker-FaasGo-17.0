package calldial.be.loctracker.Weather.activities;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import calldial.be.loctracker.R;

/* loaded from: classes.dex */
public class SplashActivityWeather extends AppCompatActivity {
    static final int PERMISSION_ACCESS_FINE_LOCATION = 0;
    AlertDialog.Builder builder;
    ConnectivityManager connectivityManager;
    boolean isConnected;
    LocationManager locationManager;
    NetworkInfo networkInfo;
    int permissionRequestResult;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_splash_weather);
        initMembers();
        checkPermissionAndConnectivity(this.permissionRequestResult, this.locationManager, this.isConnected);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onStart() {
        super.onStart();
        initMembers();
        checkPermissionAndConnectivity(this.permissionRequestResult, this.locationManager, this.isConnected);
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onResume() {
        super.onResume();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onDestroy() {
        super.onDestroy();
    }

    private void checkPermissionAndConnectivity(int i, LocationManager locationManager, boolean z) {
        if (i != 0) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.ACCESS_FINE_LOCATION"}, 0);
        } else if (!locationManager.isProviderEnabled("gps")) {
            this.builder.setMessage(R.string.msg_gps).setCancelable(false).setPositiveButton(R.string.ok_weather, new DialogInterface.OnClickListener() { // from class: calldial.be.loctracker.Weather.activities.SplashActivityWeather.2
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialogInterface, int i2) {
                    SplashActivityWeather.this.finish();
                }
            });
            this.builder.create().show();
        } else if (z) {
            startWheatherActivity();
        } else {
            this.builder.setMessage(R.string.msg_internet).setCancelable(false).setPositiveButton(R.string.ok_weather, new DialogInterface.OnClickListener() { // from class: calldial.be.loctracker.Weather.activities.SplashActivityWeather.1
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialogInterface, int i2) {
                    SplashActivityWeather.this.finish();
                }
            });
            this.builder.create().show();
        }
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i == 0) {
            if (iArr.length <= 0 || iArr[0] != 0) {
                this.builder.setMessage(R.string.msg_location_services).setCancelable(false).setPositiveButton(R.string.ok_weather, new DialogInterface.OnClickListener() { // from class: calldial.be.loctracker.Weather.activities.SplashActivityWeather.3
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialogInterface, int i2) {
                        SplashActivityWeather.this.finish();
                    }
                });
                this.builder.create().show();
                return;
            }
            initMembers();
            checkPermissionAndConnectivity(this.permissionRequestResult, this.locationManager, this.isConnected);
        }
    }

    private void startWheatherActivity() {
        new Handler().postDelayed(new Runnable() { // from class: calldial.be.loctracker.Weather.activities.SplashActivityWeather.4
            @Override // java.lang.Runnable
            public void run() {
                SplashActivityWeather.this.startActivity(new Intent(SplashActivityWeather.this, ForecastActivityWeather.class));
                SplashActivityWeather.this.finish();
            }
        }, 100L);
    }

    private void initMembers() {
        this.builder = new AlertDialog.Builder(this);
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService("connectivity");
        this.connectivityManager = connectivityManager;
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        this.networkInfo = activeNetworkInfo;
        this.isConnected = activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
        this.locationManager = (LocationManager) getSystemService("location");
        this.permissionRequestResult = checkCallingOrSelfPermission("android.permission.ACCESS_FINE_LOCATION");
    }
}
