package calldial.be.loctracker.Compass.app.main;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import calldial.be.loctracker.Compass.ColorMapCompass;
import calldial.be.loctracker.Compass.app.settings.SettingsActivityCompass;
import calldial.be.loctracker.Compass.app.widget.AccelerometerViewCompass;
import calldial.be.loctracker.Compass.app.widget.AccuracyViewCompass;
import calldial.be.loctracker.Compass.app.widget.CompassCompoundViewCompass;
import calldial.be.loctracker.Compass.app.widget.MagneticFieldViewCompass;
import calldial.be.loctracker.MagicBold.AllAdsKeyPlace;
import calldial.be.loctracker.MagicCode.GlobalMaintainer;
import calldial.be.loctracker.R;

/* loaded from: classes.dex */
public class MainActivityCompass extends Activity implements MainContractCompass.View, View.OnClickListener {
    private AccuracyViewCompass accuracyView;
    private TextView btnSettings;
    private ColorMapCompass colorMap;
    private CompassCompoundViewCompass compassCompoundView;
    private AccelerometerViewCompass linearAccelerationView;
    private String mT;
    private MagneticFieldViewCompass magneticFieldView;
    private ColorMapCompass.OnThemeColorChangeListener onThemeColorChangeListener;
    private AccelerometerViewCompass orientationView;
    private MainContractCompass.UserActionsListener presenter;
    private TextView txtAcceleration;
    private TextView txtAccuracy;
    private TextView txtAccuracyAlert;
    private TextView txtMagnetic;
    private TextView txtOrientation;

    @Override // calldial.be.loctracker.Compass.ContractCompass.View
    public void hideProgress() {
    }

    @Override // calldial.be.loctracker.Compass.ContractCompass.View
    public void showProgress() {
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        ColorMapCompass provideColorMap = GlobalMaintainer.getInjector().provideColorMap();
        this.colorMap = provideColorMap;
        setTheme(provideColorMap.getAppThemeResource());
        super.onCreate(bundle);
        setContentView(R.layout.activity_main_compass);
        AllAdsKeyPlace.ShowInterstitialAdsOnCreate(this);
        this.mT = getResources().getString(R.string.mt_val);
        this.compassCompoundView = (CompassCompoundViewCompass) findViewById(R.id.compass_view_compound);
        this.magneticFieldView = (MagneticFieldViewCompass) findViewById(R.id.magnetic_field_view);
        this.txtAccuracyAlert = (TextView) findViewById(R.id.txt_accuracy_calibration);
        this.txtAcceleration = (TextView) findViewById(R.id.txt_acceleration);
        this.txtOrientation = (TextView) findViewById(R.id.txt_orientation);
        this.accuracyView = (AccuracyViewCompass) findViewById(R.id.accuracy_view);
        this.orientationView = (AccelerometerViewCompass) findViewById(R.id.accelerometer_view);
        this.linearAccelerationView = (AccelerometerViewCompass) findViewById(R.id.accelerometer_view2);
        this.txtAccuracy = (TextView) findViewById(R.id.txt_accuracy);
        this.txtMagnetic = (TextView) findViewById(R.id.txt_magnetic);
        TextView textView = (TextView) findViewById(R.id.btn_settings);
        this.btnSettings = textView;
        textView.setOnClickListener(this);
        this.presenter = GlobalMaintainer.getInjector().provideMainPresenter();
        ColorMapCompass.OnThemeColorChangeListener onThemeColorChangeListener = new ColorMapCompass.OnThemeColorChangeListener() { // from class: calldial.be.loctracker.Compass.app.main.MainActivityCompass.1
            @Override // calldial.be.loctracker.Compass.ColorMapCompass.OnThemeColorChangeListener
            public void onThemeColorChange(int i) {
                MainActivityCompass mainActivityCompass = MainActivityCompass.this;
                mainActivityCompass.setTheme(mainActivityCompass.colorMap.getAppThemeResource());
                MainActivityCompass.this.recreate();
            }
        };
        this.onThemeColorChangeListener = onThemeColorChangeListener;
        this.colorMap.addOnThemeColorChangeListener(onThemeColorChangeListener);
    }

    @Override // android.app.Activity
    public void onStart() {
        super.onStart();
        this.presenter.bindView(this);
    }

    @Override // android.app.Activity
    public void onStop() {
        MainContractCompass.UserActionsListener userActionsListener = this.presenter;
        if (userActionsListener != null) {
            userActionsListener.unbindView();
        }
        super.onStop();
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        super.onDestroy();
        this.colorMap.removeOnThemeColorChangeListener(this.onThemeColorChangeListener);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        if (view.getId() == R.id.btn_settings) {
            startActivity(SettingsActivityCompass.getStartIntent(getApplicationContext()));
        }
    }

    @Override // calldial.be.loctracker.Compass.app.main.MainContractCompass.View
    public void keepScreenOn(boolean z) {
        if (z) {
            getWindow().addFlags(128);
        } else {
            getWindow().clearFlags(128);
        }
    }

    @Override // calldial.be.loctracker.Compass.app.main.MainContractCompass.View
    public void showAccelerationView(boolean z) {
        if (z) {
            this.txtAcceleration.setVisibility(0);
            this.linearAccelerationView.setVisibility(0);
            return;
        }
        this.txtAcceleration.setVisibility(8);
        this.linearAccelerationView.setVisibility(8);
    }

    @Override // calldial.be.loctracker.Compass.app.main.MainContractCompass.View
    public void showOrientationView(boolean z) {
        if (z) {
            this.txtOrientation.setVisibility(0);
            this.orientationView.setVisibility(0);
            return;
        }
        this.txtOrientation.setVisibility(8);
        this.orientationView.setVisibility(8);
    }

    @Override // calldial.be.loctracker.Compass.app.main.MainContractCompass.View
    public void showAccuracyView(boolean z) {
        if (z) {
            this.accuracyView.setVisibility(0);
        } else {
            this.accuracyView.setVisibility(8);
        }
    }

    @Override // calldial.be.loctracker.Compass.app.main.MainContractCompass.View
    public void showMagneticView(boolean z) {
        if (z) {
            this.magneticFieldView.setVisibility(0);
        } else {
            this.magneticFieldView.setVisibility(8);
        }
    }

    @Override // calldial.be.loctracker.Compass.app.main.MainContractCompass.View
    public void showAccuracyViewSimple(boolean z) {
        if (z) {
            this.txtAccuracy.setVisibility(0);
        } else {
            this.txtAccuracy.setVisibility(8);
        }
    }

    @Override // calldial.be.loctracker.Compass.app.main.MainContractCompass.View
    public void showMagneticViewSimple(boolean z) {
        if (z) {
            this.txtMagnetic.setVisibility(0);
        } else {
            this.txtMagnetic.setVisibility(8);
        }
    }

    @Override // calldial.be.loctracker.Compass.app.main.MainContractCompass.View
    public void updateRotation(float f) {
        this.compassCompoundView.updateRotation((f + 360.0f) % 360.0f);
    }

    @Override // calldial.be.loctracker.Compass.app.main.MainContractCompass.View
    public void updateOrientation(float f, float f2) {
        this.orientationView.updateOrientation(f, f2);
    }

    @Override // calldial.be.loctracker.Compass.app.main.MainContractCompass.View
    public void updateMagneticField(float f) {
        this.magneticFieldView.updateMagneticField(f);
    }

    @Override // calldial.be.loctracker.Compass.app.main.MainContractCompass.View
    public void updateMagneticFieldSimple(float f) {
        this.txtMagnetic.setText(getResources().getString(R.string.magnetic_field2, Integer.valueOf((int) f), this.mT));
    }

    @Override // calldial.be.loctracker.Compass.app.main.MainContractCompass.View
    public void updateLinearAcceleration(float f, float f2) {
        this.linearAccelerationView.updateLinearAcceleration(f, f2);
    }

    @Override // calldial.be.loctracker.Compass.app.main.MainContractCompass.View
    public void updateAccuracy(int i) {
        this.accuracyView.updateAccuracyField(i);
    }

    @Override // calldial.be.loctracker.Compass.app.main.MainContractCompass.View
    public void updateAccuracySimple(int i) {
        String str;
        if (i == 1) {
            str = getResources().getString(R.string.accuracy_low);
        } else if (i == 2) {
            str = getResources().getString(R.string.accuracy_medium);
        } else if (i != 3) {
            str = getResources().getString(R.string.accuracy_unreliable);
        } else {
            str = getResources().getString(R.string.accuracy_high);
        }
        this.txtAccuracy.setText(getResources().getString(R.string.accuracy3, str));
    }

    @Override // calldial.be.loctracker.Compass.app.main.MainContractCompass.View
    public void alertPoorAccuracy() {
        this.txtAccuracyAlert.setVisibility(0);
    }

    @Override // calldial.be.loctracker.Compass.app.main.MainContractCompass.View
    public void hideAlertPoorAccuracy() {
        this.txtAccuracyAlert.setVisibility(8);
    }

    @Override // calldial.be.loctracker.Compass.app.main.MainContractCompass.View
    public void showSensorsNotFound() {
        new AlertDialog.Builder(this).setTitle(R.string.error).setMessage(R.string.unable_to_init_sensor).setNegativeButton(R.string.btn_ok, new DialogInterface.OnClickListener() { // from class: calldial.be.loctracker.Compass.app.main.MainActivityCompass.2
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
                MainActivityCompass.this.finish();
            }
        }).create().show();
    }

    @Override // calldial.be.loctracker.Compass.app.main.MainContractCompass.View
    public void showSimpleMode(boolean z) {
        this.linearAccelerationView.setSimpleMode(z);
        this.orientationView.setSimpleMode(z);
        this.compassCompoundView.setSimpleMode(z);
        if (z) {
            this.txtOrientation.setVisibility(8);
            this.txtAcceleration.setVisibility(8);
            this.txtAccuracy.setVisibility(0);
            this.txtMagnetic.setVisibility(0);
            this.magneticFieldView.setVisibility(8);
            this.accuracyView.setVisibility(8);
            this.btnSettings.setText("");
            return;
        }
        this.txtOrientation.setVisibility(0);
        this.txtAcceleration.setVisibility(0);
        this.txtAccuracy.setVisibility(8);
        this.txtMagnetic.setVisibility(8);
        this.magneticFieldView.setVisibility(0);
        this.accuracyView.setVisibility(0);
        this.btnSettings.setText(R.string.settings);
    }

    @Override // calldial.be.loctracker.Compass.ContractCompass.View
    public void showError(String str) {
        Toast.makeText(getApplicationContext(), str, 1).show();
    }

    @Override // calldial.be.loctracker.Compass.ContractCompass.View
    public void showError(int i) {
        Toast.makeText(getApplicationContext(), i, 1).show();
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        AllAdsKeyPlace.CloseActivityWithAds(this, "true");
    }
}
