package calldial.be.loctracker.BatteryInfo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.core.widget.NestedScrollView;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.appbar.AppBarLayout;

import calldial.be.loctracker.Common;
import calldial.be.loctracker.DashboardActivity;
import calldial.be.loctracker.MagicBold.AllAdsKeyPlace;
import calldial.be.loctracker.MagicBold.AppPrefrence;
import calldial.be.loctracker.MagicQG.QG;
import calldial.be.loctracker.MoreAdActivity;
import calldial.be.loctracker.R;

/* loaded from: classes.dex */
public class BatteryInfoActivity extends AppCompatActivity {
    public static boolean IS_DOWN = true;
    public static boolean IS_UP = true;
    public static final int PERMISSION_CAMERA = 40;
    AppBarLayout appbarlay_tool;
    private BroadcastReceiver batteryInfoReceiver = new BroadcastReceiver() { // from class: calldial.be.loctracker.BatteryInfo.BatteryInfoActivity.9
        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            BatteryInfoActivity.this.updateBatteryData(intent);
        }
    };
    Animation down_anim_toolbar;
    ImageView imgDrawerLines;
    LinearLayout iv_moreads;
    private DrawerLayout mDrawerLayout;
    NestedScrollView nested_scroll;
    TextView tv_battery_capacity;
    TextView tv_battery_charging_status;
    TextView tv_battery_health;
    TextView tv_battery_percentage;
    TextView tv_battery_plugged_status;
    TextView tv_battery_technology;
    TextView tv_battery_temp;
    TextView tv_battery_voltage;
    Animation up_anim_toolbar;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_battery_info);
        AllAdsKeyPlace.ShowInterstitialAdsOnCreate(this);
        AllAdsKeyPlace.ShowNativeAd(this, (ViewGroup) findViewById(R.id.nativeContainer));
        this.iv_moreads = (LinearLayout) findViewById(R.id.iv_moreads);
        if (Common.isNetworkConnected(this) && new AppPrefrence(getApplicationContext()).getQureka_ADS().equalsIgnoreCase("on")) {
            this.iv_moreads.setVisibility(0);
        }
        this.iv_moreads.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.BatteryInfo.BatteryInfoActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                QG.openQGAlternate(BatteryInfoActivity.this);
            }
        });
        this.mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        ImageView imageView = (ImageView) findViewById(R.id.imgDrawerLines);
        this.imgDrawerLines = imageView;
        Common.Animation(imageView);
        this.imgDrawerLines.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.BatteryInfo.BatteryInfoActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (BatteryInfoActivity.this.mDrawerLayout.isDrawerOpen(3)) {
                    BatteryInfoActivity.this.mDrawerLayout.closeDrawer(5);
                } else {
                    BatteryInfoActivity.this.mDrawerLayout.openDrawer(3);
                }
            }
        });
        findViewById(R.id.llhomeapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.BatteryInfo.BatteryInfoActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BatteryInfoActivity.this.mDrawerLayout.closeDrawers();
                BatteryInfoActivity.this.startActivity(new Intent(BatteryInfoActivity.this, DashboardActivity.class));
            }
        });
        findViewById(R.id.llrateapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.BatteryInfo.BatteryInfoActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BatteryInfoActivity.this.mDrawerLayout.closeDrawers();
                Common.showRateDialog(BatteryInfoActivity.this);
            }
        });
        findViewById(R.id.llshareapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.BatteryInfo.BatteryInfoActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BatteryInfoActivity.this.mDrawerLayout.closeDrawers();
                Common.ShareApp(BatteryInfoActivity.this);
            }
        });
        findViewById(R.id.llpolicy__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.BatteryInfo.BatteryInfoActivity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BatteryInfoActivity.this.mDrawerLayout.closeDrawers();
                Common.showPrivacyDialog(BatteryInfoActivity.this);
            }
        });
        findViewById(R.id.llmoreapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.BatteryInfo.BatteryInfoActivity.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BatteryInfoActivity.this.mDrawerLayout.closeDrawers();
                BatteryInfoActivity.this.startActivity(new Intent(BatteryInfoActivity.this, MoreAdActivity.class));
            }
        });
        this.tv_battery_health = (TextView) findViewById(R.id.tv_battery_health);
        this.tv_battery_percentage = (TextView) findViewById(R.id.tv_battery_percentage);
        this.tv_battery_plugged_status = (TextView) findViewById(R.id.tv_battery_plugged_status);
        this.tv_battery_charging_status = (TextView) findViewById(R.id.tv_battery_charging_status);
        this.tv_battery_technology = (TextView) findViewById(R.id.tv_battery_technology);
        this.tv_battery_temp = (TextView) findViewById(R.id.tv_battery_temp);
        this.tv_battery_voltage = (TextView) findViewById(R.id.tv_battery_voltage);
        this.tv_battery_capacity = (TextView) findViewById(R.id.tv_battery_capacity);
        getAllBatteryInfo();
        this.appbarlay_tool = (AppBarLayout) findViewById(R.id.appbarlay_tool);
        this.nested_scroll = (NestedScrollView) findViewById(R.id.nested_scroll);
        this.down_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.down_anim_toolbar);
        this.up_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.up_anim_toolbar);
        NestedScrollView nestedScrollView = this.nested_scroll;
        if (nestedScrollView != null) {
            nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() { // from class: calldial.be.loctracker.BatteryInfo.BatteryInfoActivity.8
                @Override // androidx.core.widget.NestedScrollView.OnScrollChangeListener
                public void onScrollChange(NestedScrollView nestedScrollView2, int i, int i2, int i3, int i4) {
                    if (i2 > i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling DOWN");
                        if (BatteryInfoActivity.IS_UP) {
                            BatteryInfoActivity.this.appbarlay_tool.startAnimation(BatteryInfoActivity.this.up_anim_toolbar);
                            BatteryInfoActivity.IS_UP = false;
                            BatteryInfoActivity.IS_DOWN = true;
                        }
                    }
                    if (i2 < i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling UP");
                        if (BatteryInfoActivity.IS_DOWN) {
                            BatteryInfoActivity.this.appbarlay_tool.startAnimation(BatteryInfoActivity.this.down_anim_toolbar);
                            BatteryInfoActivity.IS_DOWN = false;
                            BatteryInfoActivity.IS_UP = true;
                        }
                    }
                    if (i2 == 0) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to TOP SCROLL");
                    }
                    if (i2 == nestedScrollView2.getMeasuredHeight() - nestedScrollView2.getChildAt(0).getMeasuredHeight()) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to BOTTOM SCROLL");
                    }
                }
            });
        }
    }

    private void getAllBatteryInfo() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.ACTION_POWER_CONNECTED");
        intentFilter.addAction("android.intent.action.ACTION_POWER_DISCONNECTED");
        intentFilter.addAction("android.intent.action.BATTERY_CHANGED");
        registerReceiver(this.batteryInfoReceiver, intentFilter);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code restructure failed: missing block: B:46:0x00c3, code lost:
        if ("".equals(r6) == false) goto L_0x00c7;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void updateBatteryData(Intent intent) {
        String str;
        String str2;
        String str3;
        String str4;
        String str5;
        String str6;
        int i;
        String str7 = "N/A";
        if (intent.getBooleanExtra("present", false)) {
            switch (intent.getIntExtra("health", 0)) {
                case 2:
                    i = R.string.battery_health_good;
                    break;
                case 3:
                    i = R.string.battery_health_overheat;
                    break;
                case 4:
                    i = R.string.battery_health_dead;
                    break;
                case 5:
                    i = R.string.battery_health_over_voltage;
                    break;
                case 6:
                    i = R.string.battery_health_unspecified_failure;
                    break;
                case 7:
                    i = R.string.battery_health_cold;
                    break;
                default:
                    i = -1;
                    break;
            }
            str7 = i != -1 ? getString(i) : str7;
            int intExtra = intent.getIntExtra("level", -1);
            int intExtra2 = intent.getIntExtra("scale", -1);
            if (intExtra == -1 || intExtra2 == -1) {
                str5 = str7;
            } else {
                str5 = ((int) ((intExtra / intExtra2) * 100.0f)) + " %";
            }
            int intExtra3 = intent.getIntExtra("plugged", 0);
            str4 = getString(intExtra3 != 1 ? intExtra3 != 2 ? intExtra3 != 4 ? R.string.battery_plugged_none : R.string.battery_plugged_wireless : R.string.battery_plugged_usb : R.string.battery_plugged_ac);
            int intExtra4 = intent.getIntExtra("status", -1);
            int i2 = R.string.battery_status_discharging;
            if (intExtra4 == 1) {
                i2 = -1;
            } else if (intExtra4 == 2) {
                i2 = R.string.battery_status_charging;
            } else if (intExtra4 != 3 && intExtra4 == 5) {
                i2 = R.string.battery_status_full;
            }
            str6 = i2 != -1 ? getString(i2) : str7;
            if (intent.getExtras() != null) {
                str3 = intent.getExtras().getString("technology");
            }
            str3 = str7;
            int intExtra5 = intent.getIntExtra("temperature", 0);
            if (intExtra5 > 0) {
                str2 = (intExtra5 / 10.0f) + "°C";
            } else {
                str2 = str7;
            }
            int intExtra6 = intent.getIntExtra("voltage", 0);
            if (intExtra6 > 0) {
                str = intExtra6 + " mV";
            } else {
                str = str7;
            }
            long batteryCapacity = getBatteryCapacity(this);
            if (batteryCapacity > 0) {
                str7 = batteryCapacity + " mAh";
            }
        } else {
            Toast.makeText(this, "No Battery present!", 0).show();
            str = str7;
            str7 = str;
            str6 = str7;
            str5 = str6;
            str4 = str5;
            str3 = str4;
            str2 = str3;
        }
        this.tv_battery_health.setText(str7);
        this.tv_battery_percentage.setText(str5);
        this.tv_battery_plugged_status.setText(str4);
        this.tv_battery_charging_status.setText(str6);
        this.tv_battery_technology.setText(str3);
        this.tv_battery_temp.setText(str2);
        this.tv_battery_voltage.setText(str);
        this.tv_battery_capacity.setText(str7);
    }

    public long getBatteryCapacity(Context context) {
        if (Build.VERSION.SDK_INT < 21) {
            return 0L;
        }
        BatteryManager batteryManager = (BatteryManager) context.getSystemService("batterymanager");
        Long valueOf = Long.valueOf(batteryManager.getLongProperty(1));
        Long valueOf2 = Long.valueOf(batteryManager.getLongProperty(4));
        if (valueOf == null || valueOf2 == null) {
            return 0L;
        }
        return (long) ((((float) valueOf.longValue()) / ((float) valueOf2.longValue())) * 100.0f);
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (this.mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            this.mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            AllAdsKeyPlace.CloseActivityWithAds(this, "true");
        }
    }
}
