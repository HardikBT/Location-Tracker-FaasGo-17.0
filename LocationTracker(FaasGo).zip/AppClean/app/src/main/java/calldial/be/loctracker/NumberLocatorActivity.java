package calldial.be.loctracker;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.core.widget.NestedScrollView;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.appbar.AppBarLayout;

import calldial.be.loctracker.ISDCodes.IsdCodesActivity;
import calldial.be.loctracker.InfoFromMobileNumber.MobileNumberInfoActivity;
import calldial.be.loctracker.MagicBold.AllAdsKeyPlace;
import calldial.be.loctracker.MagicBold.AppPrefrence;
import calldial.be.loctracker.MagicQG.QG;
import calldial.be.loctracker.STDCodes.StdCodesActivity;

/* loaded from: classes.dex */
public class NumberLocatorActivity extends AppCompatActivity {
    public static boolean IS_DOWN = true;
    public static boolean IS_UP = true;
    AppBarLayout appbarlay_tool;
    ImageView btn_current_location;
    ImageView btn_isd_codes;
    ImageView btn_number_locator_inside;
    ImageView btn_std_codes;
    Animation down_anim_toolbar;
    ImageView imgDrawerLines;
    LinearLayout iv_moreads;
    private DrawerLayout mDrawerLayout;
    NestedScrollView nested_scroll;
    Animation up_anim_toolbar;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_number_locator);
        AllAdsKeyPlace.ShowInterstitialAdsOnCreate(this);
        AllAdsKeyPlace.ShowNativeAd(this, (ViewGroup) findViewById(R.id.nativeContainer));
        this.iv_moreads = (LinearLayout) findViewById(R.id.iv_moreads);
        if (Common.isNetworkConnected(this) && new AppPrefrence(getApplicationContext()).getQureka_ADS().equalsIgnoreCase("on")) {
            this.iv_moreads.setVisibility(0);
        }
        this.iv_moreads.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.NumberLocatorActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                QG.openQGAlternate(NumberLocatorActivity.this);
            }
        });
        this.mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        ImageView imageView = (ImageView) findViewById(R.id.imgDrawerLines);
        this.imgDrawerLines = imageView;
        Common.Animation(imageView);
        this.imgDrawerLines.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.NumberLocatorActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (NumberLocatorActivity.this.mDrawerLayout.isDrawerOpen(3)) {
                    NumberLocatorActivity.this.mDrawerLayout.closeDrawer(5);
                } else {
                    NumberLocatorActivity.this.mDrawerLayout.openDrawer(3);
                }
            }
        });
        findViewById(R.id.llhomeapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.NumberLocatorActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                NumberLocatorActivity.this.mDrawerLayout.closeDrawers();
                NumberLocatorActivity.this.startActivity(new Intent(NumberLocatorActivity.this, DashboardActivity.class));
            }
        });
        findViewById(R.id.llrateapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.NumberLocatorActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                NumberLocatorActivity.this.mDrawerLayout.closeDrawers();
                Common.showRateDialog(NumberLocatorActivity.this);
            }
        });
        findViewById(R.id.llshareapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.NumberLocatorActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                NumberLocatorActivity.this.mDrawerLayout.closeDrawers();
                Common.ShareApp(NumberLocatorActivity.this);
            }
        });
        findViewById(R.id.llpolicy__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.NumberLocatorActivity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                NumberLocatorActivity.this.mDrawerLayout.closeDrawers();
                Common.showPrivacyDialog(NumberLocatorActivity.this);
            }
        });
        findViewById(R.id.llmoreapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.NumberLocatorActivity.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                NumberLocatorActivity.this.mDrawerLayout.closeDrawers();
                NumberLocatorActivity.this.startActivity(new Intent(NumberLocatorActivity.this, MoreAdActivity.class));
            }
        });
        this.btn_number_locator_inside = (ImageView) findViewById(R.id.btn_number_locator_inside);
        this.btn_isd_codes = (ImageView) findViewById(R.id.btn_isd_codes);
        this.btn_std_codes = (ImageView) findViewById(R.id.btn_std_codes);
        Common.Animation(this.btn_number_locator_inside);
        Common.Animation(this.btn_isd_codes);
        Common.Animation(this.btn_std_codes);
        this.appbarlay_tool = (AppBarLayout) findViewById(R.id.appbarlay_tool);
        this.nested_scroll = (NestedScrollView) findViewById(R.id.nested_scroll);
        this.down_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.down_anim_toolbar);
        this.up_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.up_anim_toolbar);
        NestedScrollView nestedScrollView = this.nested_scroll;
        if (nestedScrollView != null) {
            nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() { // from class: calldial.be.loctracker.NumberLocatorActivity.8
                @Override // androidx.core.widget.NestedScrollView.OnScrollChangeListener
                public void onScrollChange(NestedScrollView nestedScrollView2, int i, int i2, int i3, int i4) {
                    if (i2 > i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling DOWN");
                        if (NumberLocatorActivity.IS_UP) {
                            NumberLocatorActivity.this.appbarlay_tool.startAnimation(NumberLocatorActivity.this.up_anim_toolbar);
                            NumberLocatorActivity.IS_UP = false;
                            NumberLocatorActivity.IS_DOWN = true;
                        }
                    }
                    if (i2 < i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling UP");
                        if (NumberLocatorActivity.IS_DOWN) {
                            NumberLocatorActivity.this.appbarlay_tool.startAnimation(NumberLocatorActivity.this.down_anim_toolbar);
                            NumberLocatorActivity.IS_DOWN = false;
                            NumberLocatorActivity.IS_UP = true;
                        }
                    }
                    if (i2 == 0) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to TOP SCROLL");
                    }
                    if (i2 == nestedScrollView2.getMeasuredHeight() - nestedScrollView2.getChildAt(0).getMeasuredHeight()) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to BOTTOM SCROLL");
                    }
                }
            });
        }
        this.btn_number_locator_inside.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.NumberLocatorActivity.9
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                NumberLocatorActivity.this.startActivity(new Intent(NumberLocatorActivity.this, MobileNumberInfoActivity.class));
            }
        });
        this.btn_isd_codes.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.NumberLocatorActivity.10
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                NumberLocatorActivity.this.startActivity(new Intent(NumberLocatorActivity.this, IsdCodesActivity.class));
            }
        });
        this.btn_std_codes.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.NumberLocatorActivity.11
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                NumberLocatorActivity.this.startActivity(new Intent(NumberLocatorActivity.this, StdCodesActivity.class));
            }
        });
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (this.mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            this.mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            AllAdsKeyPlace.CloseActivityWithAds(this, "true");
        }
    }
}
