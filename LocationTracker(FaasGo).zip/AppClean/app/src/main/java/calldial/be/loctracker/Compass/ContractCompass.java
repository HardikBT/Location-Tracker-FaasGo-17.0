package calldial.be.loctracker.Compass;

/* loaded from: classes.dex */
public interface ContractCompass {

    /* loaded from: classes.dex */
    public interface UserActionsListener<T extends View> {
        void bindView(T t);

        void unbindView();
    }

    /* loaded from: classes.dex */
    public interface View {
        void hideProgress();

        void showError(int i);

        void showError(String str);

        void showProgress();
    }
}
