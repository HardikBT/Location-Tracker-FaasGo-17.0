package calldial.be.loctracker.BankInfo;

import android.content.Intent;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.core.widget.NestedScrollView;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.appbar.AppBarLayout;

import calldial.be.loctracker.Common;
import calldial.be.loctracker.DashboardActivity;
import calldial.be.loctracker.MagicBold.AllAdsKeyPlace;
import calldial.be.loctracker.MagicBold.AppPrefrence;
import calldial.be.loctracker.MagicQG.QG;
import calldial.be.loctracker.MoreAdActivity;
import calldial.be.loctracker.R;

/* loaded from: classes.dex */
public class BankInfoSecondActivity extends AppCompatActivity {
    public static boolean IS_DOWN = true;
    public static boolean IS_UP = true;
    private static final int REQUEST_LOCATION_CODE = 1;
    AppBarLayout appbarlay_tool;
    Animation down_anim_toolbar;
    ImageView imgDrawerLines;
    ImageView iv_call_customer_care;
    ImageView iv_logo;
    ImageView iv_mobile_check_balance;
    LinearLayout iv_moreads;
    String latitude;
    LocationManager locationManager;
    String longitude;
    private DrawerLayout mDrawerLayout;
    NestedScrollView nested_scroll;
    TextView tv_bank_name;
    TextView tv_call_customer_care;
    TextView tv_mobile_check_balance;
    Animation up_anim_toolbar;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_bank_info_second);
        AllAdsKeyPlace.ShowInterstitialAdsOnCreate(this);
        AllAdsKeyPlace.ShowNativeAd(this, (ViewGroup) findViewById(R.id.nativeContainer));
        this.iv_moreads = (LinearLayout) findViewById(R.id.iv_moreads);
        if (Common.isNetworkConnected(this) && new AppPrefrence(getApplicationContext()).getQureka_ADS().equalsIgnoreCase("on")) {
            this.iv_moreads.setVisibility(0);
        }
        this.iv_moreads.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.BankInfo.BankInfoSecondActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                QG.openQGAlternate(BankInfoSecondActivity.this);
            }
        });
        this.mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        ImageView imageView = (ImageView) findViewById(R.id.imgDrawerLines);
        this.imgDrawerLines = imageView;
        Common.Animation(imageView);
        this.imgDrawerLines.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.BankInfo.BankInfoSecondActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (BankInfoSecondActivity.this.mDrawerLayout.isDrawerOpen(3)) {
                    BankInfoSecondActivity.this.mDrawerLayout.closeDrawer(5);
                } else {
                    BankInfoSecondActivity.this.mDrawerLayout.openDrawer(3);
                }
            }
        });
        findViewById(R.id.llhomeapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.BankInfo.BankInfoSecondActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BankInfoSecondActivity.this.mDrawerLayout.closeDrawers();
                BankInfoSecondActivity.this.startActivity(new Intent(BankInfoSecondActivity.this, DashboardActivity.class));
            }
        });
        findViewById(R.id.llrateapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.BankInfo.BankInfoSecondActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BankInfoSecondActivity.this.mDrawerLayout.closeDrawers();
                Common.showRateDialog(BankInfoSecondActivity.this);
            }
        });
        findViewById(R.id.llshareapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.BankInfo.BankInfoSecondActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BankInfoSecondActivity.this.mDrawerLayout.closeDrawers();
                Common.ShareApp(BankInfoSecondActivity.this);
            }
        });
        findViewById(R.id.llpolicy__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.BankInfo.BankInfoSecondActivity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BankInfoSecondActivity.this.mDrawerLayout.closeDrawers();
                Common.showPrivacyDialog(BankInfoSecondActivity.this);
            }
        });
        findViewById(R.id.llmoreapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.BankInfo.BankInfoSecondActivity.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BankInfoSecondActivity.this.mDrawerLayout.closeDrawers();
                BankInfoSecondActivity.this.startActivity(new Intent(BankInfoSecondActivity.this, MoreAdActivity.class));
            }
        });
        this.iv_logo = (ImageView) findViewById(R.id.iv_logo);
        this.tv_bank_name = (TextView) findViewById(R.id.tv_bank_name);
        this.tv_mobile_check_balance = (TextView) findViewById(R.id.tv_mobile_check_balance);
        this.iv_mobile_check_balance = (ImageView) findViewById(R.id.iv_mobile_check_balance);
        this.tv_call_customer_care = (TextView) findViewById(R.id.tv_call_customer_care);
        this.iv_call_customer_care = (ImageView) findViewById(R.id.iv_call_customer_care);
        Common.Animation(this.iv_mobile_check_balance);
        Common.Animation(this.iv_call_customer_care);
        this.appbarlay_tool = (AppBarLayout) findViewById(R.id.appbarlay_tool);
        this.nested_scroll = (NestedScrollView) findViewById(R.id.nested_scroll);
        this.down_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.down_anim_toolbar);
        this.up_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.up_anim_toolbar);
        NestedScrollView nestedScrollView = this.nested_scroll;
        if (nestedScrollView != null) {
            nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() { // from class: calldial.be.loctracker.BankInfo.BankInfoSecondActivity.8
                @Override // androidx.core.widget.NestedScrollView.OnScrollChangeListener
                public void onScrollChange(NestedScrollView nestedScrollView2, int i, int i2, int i3, int i4) {
                    if (i2 > i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling DOWN");
                        if (BankInfoSecondActivity.IS_UP) {
                            BankInfoSecondActivity.this.appbarlay_tool.startAnimation(BankInfoSecondActivity.this.up_anim_toolbar);
                            BankInfoSecondActivity.IS_UP = false;
                            BankInfoSecondActivity.IS_DOWN = true;
                        }
                    }
                    if (i2 < i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling UP");
                        if (BankInfoSecondActivity.IS_DOWN) {
                            BankInfoSecondActivity.this.appbarlay_tool.startAnimation(BankInfoSecondActivity.this.down_anim_toolbar);
                            BankInfoSecondActivity.IS_DOWN = false;
                            BankInfoSecondActivity.IS_UP = true;
                        }
                    }
                    if (i2 == 0) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to TOP SCROLL");
                    }
                    if (i2 == nestedScrollView2.getMeasuredHeight() - nestedScrollView2.getChildAt(0).getMeasuredHeight()) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to BOTTOM SCROLL");
                    }
                }
            });
        }
        Bundle extras = getIntent().getExtras();
        int i = extras.getInt("BANK_LOGO");
        String string = extras.getString("BANK_NAME");
        final String string2 = extras.getString("CHECK_BALANCE");
        final String string3 = extras.getString("CUSTOMER_CARE");
        this.iv_logo.setBackgroundResource(i);
        this.tv_bank_name.setText(string);
        this.tv_mobile_check_balance.setText(string2);
        this.tv_call_customer_care.setText(string3);
        this.iv_mobile_check_balance.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.BankInfo.BankInfoSecondActivity.9
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BankInfoSecondActivity.this.startActivity(new Intent("android.intent.action.DIAL", Uri.parse("tel:" + string2)));
            }
        });
        this.iv_call_customer_care.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.BankInfo.BankInfoSecondActivity.10
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BankInfoSecondActivity.this.startActivity(new Intent("android.intent.action.DIAL", Uri.parse("tel:" + string3)));
            }
        });
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (this.mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            this.mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            AllAdsKeyPlace.CloseActivityWithAds(this, "true");
        }
    }
}
