package calldial.be.loctracker.Weather.utilities;

/* loaded from: classes.dex */
public class UtilityWeather {
    private static final String TAG = "UtilityWeather";

    public static ApisWeather getApis() {
        return (ApisWeather) ClientWeather.getClient().create(ApisWeather.class);
    }
}
