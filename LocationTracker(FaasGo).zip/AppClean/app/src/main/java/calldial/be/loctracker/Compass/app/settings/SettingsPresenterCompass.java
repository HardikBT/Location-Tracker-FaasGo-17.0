package calldial.be.loctracker.Compass.app.settings;

import calldial.be.loctracker.Compass.data.PrefsCompass;

/* loaded from: classes.dex */
public class SettingsPresenterCompass implements SettingsContractCompass.UserActionsListener {
    private final PrefsCompass prefs;
    private boolean showAdvanced = false;
    private SettingsContractCompass.View view;

    public SettingsPresenterCompass(PrefsCompass prefsCompass) {
        this.prefs = prefsCompass;
    }

    @Override // calldial.be.loctracker.Compass.app.settings.SettingsContractCompass.UserActionsListener
    public void loadSettings() {
        this.view.showProgress();
        this.view.showKeepScreenOnSetting(this.prefs.isKeepScreenOn());
        this.view.showEnergySavingModeSetting(this.prefs.isEnergySavingMode());
        this.view.showSimpleModeSetting(this.prefs.isSimpleMode());
        this.view.setShowAccelerationView(this.prefs.isShowAcceleration());
        this.view.setShowOrientationView(this.prefs.isShowOrientation());
        this.view.setShowAccuracyView(this.prefs.isShowAccuracy());
        this.view.setShowMagneticView(this.prefs.isShowMagnetic());
    }

    @Override // calldial.be.loctracker.Compass.app.settings.SettingsContractCompass.UserActionsListener
    public void keepScreenOn(boolean z) {
        this.prefs.setKeepScreenOn(z);
    }

    @Override // calldial.be.loctracker.Compass.app.settings.SettingsContractCompass.UserActionsListener
    public void simpleMode(boolean z) {
        this.prefs.setSimpleMode(z);
    }

    @Override // calldial.be.loctracker.Compass.app.settings.SettingsContractCompass.UserActionsListener
    public void energySavingMode(boolean z) {
        this.prefs.setEnergySavingMode(z);
    }

    @Override // calldial.be.loctracker.Compass.app.settings.SettingsContractCompass.UserActionsListener
    public void showAccelerationView(boolean z) {
        this.prefs.setShowAcceleration(z);
    }

    @Override // calldial.be.loctracker.Compass.app.settings.SettingsContractCompass.UserActionsListener
    public void showOrientationView(boolean z) {
        this.prefs.setShowOrientation(z);
    }

    @Override // calldial.be.loctracker.Compass.app.settings.SettingsContractCompass.UserActionsListener
    public void showAccuracyView(boolean z) {
        this.prefs.setShowAccuracy(z);
    }

    @Override // calldial.be.loctracker.Compass.app.settings.SettingsContractCompass.UserActionsListener
    public void showMagneticView(boolean z) {
        this.prefs.setShowMagnetic(z);
    }

    @Override // calldial.be.loctracker.Compass.app.settings.SettingsContractCompass.UserActionsListener
    public void showAdvancedClicked() {
        boolean z = !this.showAdvanced;
        this.showAdvanced = z;
        if (z) {
            this.view.showAdvanced();
        } else {
            this.view.hideAdvanced();
        }
    }

    public void bindView(SettingsContractCompass.View view) {
        this.view = view;
        view.hideAdvanced();
    }

    @Override // calldial.be.loctracker.Compass.ContractCompass.UserActionsListener
    public void unbindView() {
        this.view = null;
    }
}
