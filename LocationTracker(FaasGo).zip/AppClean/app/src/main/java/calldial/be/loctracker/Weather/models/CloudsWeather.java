package calldial.be.loctracker.Weather.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/* loaded from: classes.dex */
public class CloudsWeather {
    @SerializedName("all")
    @Expose
    private int all;

    public int getAll() {
        return this.all;
    }

    public void setAll(int i) {
        this.all = i;
    }
}
