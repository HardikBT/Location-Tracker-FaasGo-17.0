package calldial.be.loctracker;

/* loaded from: classes.dex */
public interface PushDown {
}
