package calldial.be.loctracker;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.core.widget.NestedScrollView;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.AppBarLayout;

import calldial.be.loctracker.MagicBold.AllAdsKeyPlace;
import calldial.be.loctracker.MagicBold.AppPrefrence;
import calldial.be.loctracker.MagicCode.GlobalMaintainer;
import calldial.be.loctracker.MagicQG.QG;

/* loaded from: classes.dex */
public class FreePremiumActivity extends AppCompatActivity {
    public static boolean IS_DOWN = true;
    public static boolean IS_UP = true;
    AppBarLayout appbarlay_tool;
    Animation down_anim_toolbar;
    ImageView imgDrawerLines;
    LinearLayout iv_moreads;
    private DrawerLayout mDrawerLayout;
    NestedScrollView nested_scroll;
    private RecyclerView recycler_view;
    RelativeLayout rl_free;
    RelativeLayout rl_premium;
    private TextView txt_no_internet;
    Animation up_anim_toolbar;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_free_premium);
        AllAdsKeyPlace.ShowInterstitialAdsOnCreate(this);
        AllAdsKeyPlace.ShowNativeAd(this, (ViewGroup) findViewById(R.id.nativeContainer));

        this.iv_moreads = (LinearLayout) findViewById(R.id.iv_moreads);
        if (Common.isNetworkConnected(this) && new AppPrefrence(getApplicationContext()).getQureka_ADS().equalsIgnoreCase("on")) {
            this.iv_moreads.setVisibility(0);
        }
        this.iv_moreads.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.FreePremiumActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                QG.openQGAlternate(FreePremiumActivity.this);
            }
        });
        this.mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        ImageView imageView = (ImageView) findViewById(R.id.imgDrawerLines);
        this.imgDrawerLines = imageView;
        Common.Animation(imageView);
        this.imgDrawerLines.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.FreePremiumActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (FreePremiumActivity.this.mDrawerLayout.isDrawerOpen(3)) {
                    FreePremiumActivity.this.mDrawerLayout.closeDrawer(5);
                } else {
                    FreePremiumActivity.this.mDrawerLayout.openDrawer(3);
                }
            }
        });
        findViewById(R.id.llhomeapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.FreePremiumActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FreePremiumActivity.this.mDrawerLayout.closeDrawers();
                FreePremiumActivity.this.startActivity(new Intent(FreePremiumActivity.this, DashboardActivity.class));
            }
        });
        findViewById(R.id.llrateapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.FreePremiumActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FreePremiumActivity.this.mDrawerLayout.closeDrawers();
                Common.showRateDialog(FreePremiumActivity.this);
            }
        });
        findViewById(R.id.llshareapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.FreePremiumActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FreePremiumActivity.this.mDrawerLayout.closeDrawers();
                Common.ShareApp(FreePremiumActivity.this);
            }
        });
        findViewById(R.id.llpolicy__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.FreePremiumActivity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FreePremiumActivity.this.mDrawerLayout.closeDrawers();
                Common.showPrivacyDialog(FreePremiumActivity.this);
            }
        });
        findViewById(R.id.llmoreapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.FreePremiumActivity.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FreePremiumActivity.this.mDrawerLayout.closeDrawers();
                FreePremiumActivity.this.startActivity(new Intent(FreePremiumActivity.this, MoreAdActivity.class));
            }
        });
        this.rl_premium = (RelativeLayout) findViewById(R.id.rl_premium);
        this.rl_free = (RelativeLayout) findViewById(R.id.rl_free);
        Common.Animation((ViewGroup) this.rl_premium);
        Common.Animation((ViewGroup) this.rl_free);
        Common.Animation((ViewGroup) findViewById(R.id.rl_qureka_button));
        this.appbarlay_tool = (AppBarLayout) findViewById(R.id.appbarlay_tool);
        this.nested_scroll = (NestedScrollView) findViewById(R.id.nested_scroll);
        this.down_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.down_anim_toolbar);
        this.up_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.up_anim_toolbar);
        NestedScrollView nestedScrollView = this.nested_scroll;
        if (nestedScrollView != null) {
            nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() { // from class: calldial.be.loctracker.FreePremiumActivity.8
                @Override // androidx.core.widget.NestedScrollView.OnScrollChangeListener
                public void onScrollChange(NestedScrollView nestedScrollView2, int i, int i2, int i3, int i4) {
                    if (i2 > i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling DOWN");
                        if (FreePremiumActivity.IS_UP) {
                            FreePremiumActivity.this.appbarlay_tool.startAnimation(FreePremiumActivity.this.up_anim_toolbar);
                            FreePremiumActivity.IS_UP = false;
                            FreePremiumActivity.IS_DOWN = true;
                        }
                    }
                    if (i2 < i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling UP");
                        if (FreePremiumActivity.IS_DOWN) {
                            FreePremiumActivity.this.appbarlay_tool.startAnimation(FreePremiumActivity.this.down_anim_toolbar);
                            FreePremiumActivity.IS_DOWN = false;
                            FreePremiumActivity.IS_UP = true;
                        }
                    }
                    if (i2 == 0) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to TOP SCROLL");
                    }
                    if (i2 == nestedScrollView2.getMeasuredHeight() - nestedScrollView2.getChildAt(0).getMeasuredHeight()) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to BOTTOM SCROLL");
                    }
                }
            });
        }
        this.rl_premium.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.FreePremiumActivity.9
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FreePremiumActivity.this.startActivity(new Intent(FreePremiumActivity.this, HindiEnglishActivity.class));
            }
        });
        this.rl_free.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.FreePremiumActivity.10
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FreePremiumActivity.this.startActivity(new Intent(FreePremiumActivity.this, HindiEnglishActivity.class));
            }
        });
        if (Common.isNetworkConnected(this) && new AppPrefrence(getApplicationContext()).getQureka_ADS().equalsIgnoreCase("on")) {
            findViewById(R.id.rl_qureka_button).setVisibility(0);
        }
        findViewById(R.id.rl_qureka_button).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.FreePremiumActivity.11
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (Common.isNetworkConnected(FreePremiumActivity.this)) {
                    QG.openQGAlternate(FreePremiumActivity.this);
                } else {
                    Toast.makeText(FreePremiumActivity.this, "No internet connection...", 0).show();
                }
            }
        });
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (this.mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            this.mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            AllAdsKeyPlace.CloseActivityWithAds(this, "true");
        }
    }
}
