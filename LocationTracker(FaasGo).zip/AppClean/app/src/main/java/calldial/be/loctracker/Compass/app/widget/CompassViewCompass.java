package calldial.be.loctracker.Compass.app.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

import com.tomlonghurst.expandablehinttext.ConstantsKt;

import calldial.be.loctracker.Compass.util.AndroidUtilsCompass;
import calldial.be.loctracker.R;
import timber.log.Timber;

/* loaded from: classes.dex */
public class CompassViewCompass extends View {
    public static final float BIG_MARK_INNER_RADIUS = 0.34f;
    public static final float BIG_MARK_OUTER_RADIUS = 0.38f;
    public static final float DEGREE_RADIUS = 0.3f;
    public static final String DEGREE_SIGN = "°";
    public static final float DIRECTION_RADIUS = 0.215f;
    public static final float INNER_RADIUS = 0.24f;
    public static final float MAGNETIC_NAME_RADIUS = 0.414f;
    public static final float MAGNETIC_VAL_RADIUS = 0.4f;
    public static final float MAGNETIC_VIEW_RADIUS = 0.407f;
    public static final float MIDDLE_RADIUS = 0.325f;
    public static final float NORTH_MARK_INNER_RADIUS = 0.3f;
    public static final float NORTH_MARK_OUTER_RADIUS = 0.4f;
    public static final float OUTER_RADIUS = 0.43f;
    public static final float SMALL_MARK_INNER_RADIUS = 0.35f;
    public static final float SMALL_MARK_OUTER_RADIUS = 0.38f;
    private Point CENTER;
    private float WIDTH;
    private float azimuth;
    private Paint bigMarkPaint;
    private Paint currentDirectionTextPaint;
    private Paint degreeTextPaint;
    private Paint directionTextMainPaint;
    private Paint directionTextSlavePaint;
    private String e;
    private Paint innerCirclePaint;
    private String mT;
    private String magField;
    private Paint magneticBackgroundPaint;
    private float magneticField;
    private Paint magneticFieldPaint;
    private Paint magneticTextPaint;
    private Paint middleCirclePaint;
    private String n;
    private String ne;
    private Paint northMarkPaint;
    private Paint northMarkStaticPaint;
    private Paint northMarkTextPaint;
    private String nw;
    private Paint outerCirclePaint;
    private String s;
    private String se;
    private Paint smallMarkPaint;
    private String sw;
    private String w;
    private Path smallMarkPath = null;
    private Path bigMarkPath = null;
    private Path northMarkPath = null;
    private Path magneticPath = null;
    private Path magneticBackgroundPath = null;
    private Path staticNorthMarkPath = null;
    private Path northMarkPath2 = null;

    public CompassViewCompass(Context context) {
        super(context);
        init(context);
    }

    public CompassViewCompass(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(context);
    }

    public CompassViewCompass(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init(context);
    }

    private void init(Context context) {
        Typeface create = Typeface.create("sans-serif-light", 0);
        Typeface create2 = Typeface.create("sans-serif-medium", 0);
        Resources resources = context.getResources();
        this.n = resources.getString(R.string.n);
        this.e = resources.getString(R.string.e);
        this.s = resources.getString(R.string.s);
        this.w = resources.getString(R.string.w);
        this.ne = resources.getString(R.string.ne);
        this.se = resources.getString(R.string.se);
        this.sw = resources.getString(R.string.sw);
        this.nw = resources.getString(R.string.nw);
        this.mT = resources.getString(R.string.mt_val);
        this.magField = resources.getString(R.string.mag_field);
        int color = resources.getColor(R.color.md_indigo_300);
        int color2 = resources.getColor(R.color.md_indigo_400x);
        int color3 = resources.getColor(R.color.md_indigo_500x);
        int color4 = resources.getColor(R.color.md_indigo_800x);
        int color5 = resources.getColor(R.color.md_indigo_100);
        int color6 = resources.getColor(R.color.md_green_400);
        int color7 = resources.getColor(R.color.md_indigo_200);
        int color8 = resources.getColor(R.color.md_indigo_50);
        int color9 = resources.getColor(R.color.md_red_400);
        int color10 = resources.getColor(R.color.md_indigo_50);
        int color11 = resources.getColor(R.color.md_indigo_50);
        this.magneticPath = new Path();
        this.CENTER = new Point(0, 0);
        Paint paint = new Paint(1);
        this.outerCirclePaint = paint;
        paint.setColor(color);
        this.outerCirclePaint.setStyle(Paint.Style.STROKE);
        this.outerCirclePaint.setStrokeWidth(AndroidUtilsCompass.dpToPx(1));
        Paint paint2 = new Paint(1);
        this.middleCirclePaint = paint2;
        paint2.setColor(color2);
        this.middleCirclePaint.setStyle(Paint.Style.STROKE);
        this.middleCirclePaint.setStrokeWidth(AndroidUtilsCompass.dpToPx(42));
        Paint paint3 = new Paint(1);
        this.innerCirclePaint = paint3;
        paint3.setColor(color3);
        this.innerCirclePaint.setStyle(Paint.Style.STROKE);
        this.innerCirclePaint.setStrokeWidth(AndroidUtilsCompass.dpToPx(34));
        Paint paint4 = new Paint(1);
        this.magneticBackgroundPaint = paint4;
        paint4.setStyle(Paint.Style.STROKE);
        this.magneticBackgroundPaint.setStrokeCap(Paint.Cap.ROUND);
        this.magneticBackgroundPaint.setStrokeWidth(AndroidUtilsCompass.dpToPx(8));
        this.magneticBackgroundPaint.setColor(color4);
        Paint paint5 = new Paint(1);
        this.magneticTextPaint = paint5;
        paint5.setColor(color5);
        this.magneticTextPaint.setTextSize(AndroidUtilsCompass.dpToPx(10));
        this.magneticTextPaint.setTypeface(create);
        this.magneticTextPaint.setTextAlign(Paint.Align.CENTER);
        Paint paint6 = new Paint(1);
        this.magneticFieldPaint = paint6;
        paint6.setColor(color6);
        this.magneticFieldPaint.setStrokeWidth(AndroidUtilsCompass.dpToPx(8));
        this.magneticFieldPaint.setStyle(Paint.Style.STROKE);
        this.magneticFieldPaint.setStrokeCap(Paint.Cap.ROUND);
        Paint paint7 = new Paint(1);
        this.smallMarkPaint = paint7;
        paint7.setStrokeCap(Paint.Cap.ROUND);
        this.smallMarkPaint.setColor(color7);
        this.smallMarkPaint.setStyle(Paint.Style.STROKE);
        this.smallMarkPaint.setStrokeWidth(AndroidUtilsCompass.dpToPx(1));
        Paint paint8 = new Paint(1);
        this.bigMarkPaint = paint8;
        paint8.setStrokeCap(Paint.Cap.ROUND);
        this.bigMarkPaint.setColor(color8);
        this.bigMarkPaint.setStyle(Paint.Style.STROKE);
        this.bigMarkPaint.setStrokeWidth(AndroidUtilsCompass.dpToPx(2.0f));
        Paint paint9 = new Paint(1);
        this.northMarkStaticPaint = paint9;
        paint9.setStyle(Paint.Style.FILL);
        this.northMarkStaticPaint.setColor(color9);
        Paint paint10 = new Paint(1);
        this.northMarkPaint = paint10;
        paint10.setStrokeCap(Paint.Cap.ROUND);
        this.northMarkPaint.setColor(color9);
        this.northMarkPaint.setStyle(Paint.Style.STROKE);
        this.northMarkPaint.setStrokeWidth(AndroidUtilsCompass.dpToPx(4.0f));
        Paint paint11 = new Paint(1);
        this.northMarkTextPaint = paint11;
        paint11.setColor(color9);
        this.northMarkTextPaint.setTypeface(create2);
        this.northMarkTextPaint.setTextSize(AndroidUtilsCompass.dpToPx(28));
        this.northMarkTextPaint.setTextAlign(Paint.Align.CENTER);
        Paint paint12 = new Paint(1);
        this.degreeTextPaint = paint12;
        paint12.setTextSize(AndroidUtilsCompass.dpToPx(12));
        this.degreeTextPaint.setTypeface(create);
        this.degreeTextPaint.setColor(color10);
        this.degreeTextPaint.setTextAlign(Paint.Align.CENTER);
        Paint paint13 = new Paint(1);
        this.directionTextMainPaint = paint13;
        paint13.setColor(color10);
        this.directionTextMainPaint.setTextSize(AndroidUtilsCompass.dpToPx(26));
        this.directionTextMainPaint.setTypeface(create2);
        this.directionTextMainPaint.setTextAlign(Paint.Align.CENTER);
        Paint paint14 = new Paint(1);
        this.directionTextSlavePaint = paint14;
        paint14.setColor(color11);
        this.directionTextSlavePaint.setTextSize(AndroidUtilsCompass.dpToPx(14));
        this.directionTextSlavePaint.setTextAlign(Paint.Align.CENTER);
        Paint paint15 = new Paint(1);
        this.currentDirectionTextPaint = paint15;
        paint15.setColor(color10);
        this.currentDirectionTextPaint.setTextSize(AndroidUtilsCompass.dpToPx(30));
        this.currentDirectionTextPaint.setTextAlign(Paint.Align.CENTER);
    }

    @Override // android.view.View
    protected void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        int size = MeasureSpec.getSize(i);
        int size2 = MeasureSpec.getSize(i2);
        if (size > size2) {
            size = size2;
        }
        setMeasuredDimension(resolveSize(size, i), resolveSize(size, i2));
    }

    @Override // android.view.View
    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        initConstants();
        layoutSmallClockMarks();
        layoutBigClockMarks();
        layoutNorthMark();
        layoutStaticNorthMark();
        layoutMagnetic();
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Timber.v("onDraw", new Object[0]);
        canvas.drawCircle(this.CENTER.x, this.CENTER.y, this.WIDTH * 0.43f, this.outerCirclePaint);
        canvas.drawCircle(this.CENTER.x, this.CENTER.y, this.WIDTH * 0.325f, this.middleCirclePaint);
        canvas.drawCircle(this.CENTER.x, this.CENTER.y, this.WIDTH * 0.24f, this.innerCirclePaint);
        drawMagnetic(canvas);
        drawAzimuthValue(canvas);
        canvas.drawPath(this.staticNorthMarkPath, this.northMarkStaticPaint);
        canvas.save();
        canvas.rotate(-this.azimuth, this.CENTER.x, this.CENTER.y);
        canvas.drawPath(this.smallMarkPath, this.smallMarkPaint);
        canvas.drawPath(this.bigMarkPath, this.bigMarkPaint);
        canvas.drawPath(this.northMarkPath, this.northMarkPaint);
        canvas.drawPath(this.northMarkPath2, this.northMarkStaticPaint);
        float f = this.WIDTH * 0.3f;
        drawText(canvas, 300.0f, "30", f, this.degreeTextPaint);
        drawText(canvas, 330.0f, "60", f, this.degreeTextPaint);
        drawText(canvas, 360.0f, "90", f, this.degreeTextPaint);
        drawText(canvas, 30.0f, "120", f, this.degreeTextPaint);
        drawText(canvas, 60.0f, "150", f, this.degreeTextPaint);
        drawText(canvas, 90.0f, "180", f, this.degreeTextPaint);
        drawText(canvas, 120.0f, "210", f, this.degreeTextPaint);
        drawText(canvas, 150.0f, "240", f, this.degreeTextPaint);
        drawText(canvas, 180.0f, "270", f, this.degreeTextPaint);
        drawText(canvas, 210.0f, "300", f, this.degreeTextPaint);
        drawText(canvas, 240.0f, "330", f, this.degreeTextPaint);
        float f2 = this.WIDTH * 0.215f;
        drawText(canvas, 270.0f, this.n, f2, this.northMarkTextPaint);
        drawText(canvas, 0.0f, this.e, f2, this.directionTextMainPaint);
        drawText(canvas, 90.0f, this.s, f2, this.directionTextMainPaint);
        drawText(canvas, 180.0f, this.w, f2, this.directionTextMainPaint);
        drawText(canvas, 315.0f, this.ne, f2, this.directionTextSlavePaint);
        drawText(canvas, 45.0f, this.se, f2, this.directionTextSlavePaint);
        drawText(canvas, 135.0f, this.sw, f2, this.directionTextSlavePaint);
        drawText(canvas, 225.0f, this.nw, f2, this.directionTextSlavePaint);
        canvas.restore();
    }

    private void initConstants() {
        float width = getWidth();
        this.WIDTH = width;
        this.CENTER.set(((int) width) / 2, getHeight() / 2);
    }

    private void layoutSmallClockMarks() {
        if (this.smallMarkPath == null) {
            float f = this.WIDTH;
            float f2 = 0.35f * f;
            float f3 = f * 0.38f;
            this.smallMarkPath = new Path();
            float f4 = 0.0f;
            while (true) {
                double d = f4;
                if (d < 6.283185307179586d) {
                    float cos = (float) Math.cos(d);
                    float sin = (float) Math.sin(d);
                    this.smallMarkPath.moveTo((f2 * cos) + this.CENTER.x, (f2 * sin) + this.CENTER.y);
                    this.smallMarkPath.lineTo((cos * f3) + this.CENTER.x, (sin * f3) + this.CENTER.y);
                    f4 = (float) (d + Math.toRadians(2.5f));
                } else {
                    return;
                }
            }
        }
    }

    private void layoutBigClockMarks() {
        if (this.bigMarkPath == null) {
            float f = this.WIDTH;
            float f2 = 0.34f * f;
            float f3 = f * 0.38f;
            this.bigMarkPath = new Path();
            float f4 = 0.0f;
            while (true) {
                double d = f4;
                if (d < 6.283185307179586d) {
                    float cos = (float) Math.cos(d);
                    float sin = (float) Math.sin(d);
                    this.bigMarkPath.moveTo((f2 * cos) + this.CENTER.x, (f2 * sin) + this.CENTER.y);
                    this.bigMarkPath.lineTo((cos * f3) + this.CENTER.x, (sin * f3) + this.CENTER.y);
                    f4 = (float) (d + Math.toRadians(30.0f));
                } else {
                    return;
                }
            }
        }
    }

    private void layoutNorthMark() {
        if (this.northMarkPath == null) {
            this.northMarkPath = new Path();
            double radians = (float) Math.toRadians(270.0d);
            float cos = (float) Math.cos(radians);
            float sin = (float) Math.sin(radians);
            float f = this.WIDTH;
            float f2 = 0.3f * f;
            float f3 = f * 0.4f;
            this.northMarkPath.moveTo(this.CENTER.x + (f2 * cos), this.CENTER.y + (f2 * sin));
            this.northMarkPath.lineTo((cos * f3) + this.CENTER.x, (f3 * sin) + this.CENTER.y);
        }
        if (this.northMarkPath2 == null) {
            float dpToPx = AndroidUtilsCompass.dpToPx(12);
            float f4 = this.CENTER.x;
            float f5 = this.CENTER.y - (this.WIDTH * 0.38f);
            Path path = new Path();
            this.northMarkPath2 = path;
            float f6 = dpToPx / 2.0f;
            float f7 = f4 - f6;
            path.moveTo(f7, f5);
            this.northMarkPath2.lineTo(f6 + f4, f5);
            this.northMarkPath2.lineTo(f4, this.CENTER.y - (this.WIDTH * 0.41f));
            this.northMarkPath2.lineTo(f7, f5);
        }
    }

    private void layoutStaticNorthMark() {
        if (this.staticNorthMarkPath == null) {
            float f = this.CENTER.x;
            float dpToPx = AndroidUtilsCompass.dpToPx(12);
            float dpToPx2 = ((this.CENTER.y - (this.WIDTH * 0.43f)) + dpToPx) - AndroidUtilsCompass.dpToPx(2);
            Path path = new Path();
            this.staticNorthMarkPath = path;
            float f2 = dpToPx / 2.0f;
            float f3 = f - f2;
            float f4 = dpToPx2 - dpToPx;
            path.moveTo(f3, f4);
            this.staticNorthMarkPath.lineTo(f2 + f, f4);
            this.staticNorthMarkPath.lineTo(f, dpToPx2);
            this.staticNorthMarkPath.lineTo(f3, f4);
        }
    }

    private void layoutMagnetic() {
        if (this.magneticBackgroundPath == null) {
            float f = this.WIDTH * 0.407f;
            RectF rectF = new RectF(this.CENTER.x - f, this.CENTER.y - f, this.CENTER.x + f, this.CENTER.y + f);
            Path path = new Path();
            this.magneticBackgroundPath = path;
            path.addArc(rectF, 315.0f, 85.0f);
        }
    }

    private void drawMagnetic(Canvas canvas) {
        float f = this.WIDTH * 0.407f;
        RectF rectF = new RectF(this.CENTER.x - f, this.CENTER.y - f, this.CENTER.x + f, this.CENTER.y + f);
        canvas.drawPath(this.magneticBackgroundPath, this.magneticBackgroundPaint);
        float min = Math.min(1.0f, this.magneticField / 160) * 85;
        this.magneticPath.reset();
        this.magneticPath.addArc(rectF, ((float) ConstantsKt.DEFAULT_ANIMATION_MS) - min, min);
        canvas.drawPath(this.magneticPath, this.magneticFieldPaint);
        drawText(canvas, 307.0f, ((int) this.magneticField) + this.mT, this.WIDTH * 0.4f, this.magneticTextPaint);
        drawTextInverted(canvas, 53.0f, this.magField, this.WIDTH * 0.414f, this.magneticTextPaint);
    }

    private void drawAzimuthValue(Canvas canvas) {
        String str = ((int) this.azimuth) + "° " + getDirectionText(this.azimuth);
        Rect rect = new Rect();
        this.currentDirectionTextPaint.getTextBounds(str, 0, str.length(), rect);
        canvas.drawText(str, this.CENTER.x, this.CENTER.y + (rect.height() / 2.0f), this.currentDirectionTextPaint);
    }

    private void drawText(Canvas canvas, float f, String str, float f2, Paint paint) {
        canvas.save();
        double d = f;
        canvas.translate((((float) Math.cos(Math.toRadians(d))) * f2) + this.CENTER.x, (((float) Math.sin(Math.toRadians(d))) * f2) + this.CENTER.y);
        canvas.rotate(f + 90.0f);
        canvas.drawText(str, 0.0f, 0.0f, paint);
        canvas.restore();
    }

    private void drawTextInverted(Canvas canvas, float f, String str, float f2, Paint paint) {
        canvas.save();
        double d = f;
        canvas.translate((((float) Math.cos(Math.toRadians(d))) * f2) + this.CENTER.x, (((float) Math.sin(Math.toRadians(d))) * f2) + this.CENTER.y);
        canvas.rotate(f + 270.0f);
        canvas.drawText(str, 0.0f, 0.0f, paint);
        canvas.restore();
    }

    public void updateMagneticField(float f) {
        if (((int) this.magneticField) != ((int) f)) {
            this.magneticField = f;
            invalidate();
        }
    }

    public void updateAzimuth(float f) {
        if (((int) this.azimuth) != ((int) f)) {
            this.azimuth = f;
            invalidate();
        }
    }

    private String getDirectionText(float f) {
        if ((f >= 0.0f && f < 22.5f) || f > 337.5f) {
            return this.n;
        }
        if (f >= 22.5f && f < 67.5f) {
            return this.ne;
        }
        if (f >= 67.5f && f < 112.5f) {
            return this.e;
        }
        if (f >= 112.5f && f < 157.5f) {
            return this.se;
        }
        if (f >= 157.5f && f < 202.5f) {
            return this.s;
        }
        if (f >= 202.5f && f < 247.5f) {
            return this.sw;
        }
        if (f < 247.5f || f >= 292.5f) {
            return (f < 292.5f || f >= 337.5f) ? "" : this.nw;
        }
        return this.w;
    }
}
