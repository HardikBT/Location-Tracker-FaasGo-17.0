package calldial.be.loctracker.SimInfo;

import android.content.Intent;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.core.widget.NestedScrollView;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.appbar.AppBarLayout;

import calldial.be.loctracker.Common;
import calldial.be.loctracker.DashboardActivity;
import calldial.be.loctracker.MagicBold.AllAdsKeyPlace;
import calldial.be.loctracker.MagicBold.AppPrefrence;
import calldial.be.loctracker.MagicQG.QG;
import calldial.be.loctracker.MoreAdActivity;
import calldial.be.loctracker.R;

/* loaded from: classes.dex */
public class SimInfoSecondActivity extends AppCompatActivity {
    public static boolean IS_DOWN = true;
    public static boolean IS_UP = true;
    private static final int REQUEST_LOCATION_CODE = 1;
    AppBarLayout appbarlay_tool;
    Animation down_anim_toolbar;
    ImageView imgDrawerLines;
    ImageView iv_customer_care_number;
    ImageView iv_how_to_know_you_number;
    ImageView iv_how_to_recharge;
    ImageView iv_main_balance_enquiry;
    ImageView iv_message_balance_enquiry;
    LinearLayout iv_moreads;
    ImageView iv_net_balance_enquiry;
    String latitude;
    LocationManager locationManager;
    String longitude;
    private DrawerLayout mDrawerLayout;
    NestedScrollView nested_scroll;
    TextView tv_customer_care_number;
    TextView tv_how_to_know_you_number;
    TextView tv_how_to_recharge;
    TextView tv_main_balance_enquiry;
    TextView tv_message_balance_enquiry;
    TextView tv_net_balance_enquiry;
    Animation up_anim_toolbar;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override
    // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_sim_info_second);
        AllAdsKeyPlace.ShowInterstitialAdsOnCreate(this);
        AllAdsKeyPlace.ShowNativeAd(this, (ViewGroup) findViewById(R.id.nativeContainer));
        this.iv_moreads = (LinearLayout) findViewById(R.id.iv_moreads);
        if (Common.isNetworkConnected(this) && new AppPrefrence(getApplicationContext()).getQureka_ADS().equalsIgnoreCase("on")) {
            this.iv_moreads.setVisibility(0);
        }
        this.iv_moreads.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.SimInfo.SimInfoSecondActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                QG.openQGAlternate(SimInfoSecondActivity.this);
            }
        });
        this.mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        ImageView imageView = (ImageView) findViewById(R.id.imgDrawerLines);
        this.imgDrawerLines = imageView;
        Common.Animation(imageView);
        this.imgDrawerLines.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.SimInfo.SimInfoSecondActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (SimInfoSecondActivity.this.mDrawerLayout.isDrawerOpen(3)) {
                    SimInfoSecondActivity.this.mDrawerLayout.closeDrawer(5);
                } else {
                    SimInfoSecondActivity.this.mDrawerLayout.openDrawer(3);
                }
            }
        });
        findViewById(R.id.llhomeapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.SimInfo.SimInfoSecondActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                SimInfoSecondActivity.this.mDrawerLayout.closeDrawers();
                SimInfoSecondActivity.this.startActivity(new Intent(SimInfoSecondActivity.this, DashboardActivity.class));
            }
        });
        findViewById(R.id.llrateapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.SimInfo.SimInfoSecondActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                SimInfoSecondActivity.this.mDrawerLayout.closeDrawers();
                Common.showRateDialog(SimInfoSecondActivity.this);
            }
        });
        findViewById(R.id.llshareapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.SimInfo.SimInfoSecondActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                SimInfoSecondActivity.this.mDrawerLayout.closeDrawers();
                Common.ShareApp(SimInfoSecondActivity.this);
            }
        });
        findViewById(R.id.llpolicy__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.SimInfo.SimInfoSecondActivity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                SimInfoSecondActivity.this.mDrawerLayout.closeDrawers();
                Common.showPrivacyDialog(SimInfoSecondActivity.this);
            }
        });
        findViewById(R.id.llmoreapp__).setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.SimInfo.SimInfoSecondActivity.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                SimInfoSecondActivity.this.mDrawerLayout.closeDrawers();
                SimInfoSecondActivity.this.startActivity(new Intent(SimInfoSecondActivity.this, MoreAdActivity.class));
            }
        });
        this.tv_how_to_recharge = (TextView) findViewById(R.id.tv_how_to_recharge);
        this.tv_main_balance_enquiry = (TextView) findViewById(R.id.tv_main_balance_enquiry);
        this.tv_message_balance_enquiry = (TextView) findViewById(R.id.tv_message_balance_enquiry);
        this.tv_net_balance_enquiry = (TextView) findViewById(R.id.tv_net_balance_enquiry);
        this.tv_how_to_know_you_number = (TextView) findViewById(R.id.tv_how_to_know_you_number);
        this.tv_customer_care_number = (TextView) findViewById(R.id.tv_customer_care_number);
        this.iv_how_to_recharge = (ImageView) findViewById(R.id.iv_how_to_recharge);
        this.iv_main_balance_enquiry = (ImageView) findViewById(R.id.iv_main_balance_enquiry);
        this.iv_message_balance_enquiry = (ImageView) findViewById(R.id.iv_message_balance_enquiry);
        this.iv_net_balance_enquiry = (ImageView) findViewById(R.id.iv_net_balance_enquiry);
        this.iv_how_to_know_you_number = (ImageView) findViewById(R.id.iv_how_to_know_you_number);
        this.iv_customer_care_number = (ImageView) findViewById(R.id.iv_customer_care_number);
        Common.Animation(this.iv_how_to_recharge);
        Common.Animation(this.iv_main_balance_enquiry);
        Common.Animation(this.iv_message_balance_enquiry);
        Common.Animation(this.iv_net_balance_enquiry);
        Common.Animation(this.iv_how_to_know_you_number);
        Common.Animation(this.iv_customer_care_number);
        this.appbarlay_tool = (AppBarLayout) findViewById(R.id.appbarlay_tool);
        this.nested_scroll = (NestedScrollView) findViewById(R.id.nested_scroll);
        this.down_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.down_anim_toolbar);
        this.up_anim_toolbar = AnimationUtils.loadAnimation(this, R.anim.up_anim_toolbar);
        NestedScrollView nestedScrollView = this.nested_scroll;
        if (nestedScrollView != null) {
            nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() { // from class: calldial.be.loctracker.SimInfo.SimInfoSecondActivity.8
                @Override // androidx.core.widget.NestedScrollView.OnScrollChangeListener
                public void onScrollChange(NestedScrollView nestedScrollView2, int i, int i2, int i3, int i4) {
                    if (i2 > i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling DOWN");
                        if (SimInfoSecondActivity.IS_UP) {
                            SimInfoSecondActivity.this.appbarlay_tool.startAnimation(SimInfoSecondActivity.this.up_anim_toolbar);
                            SimInfoSecondActivity.IS_UP = false;
                            SimInfoSecondActivity.IS_DOWN = true;
                        }
                    }
                    if (i2 < i4) {
                        Log.i("NETED_SCROLL_VIEW", "Scrolling UP");
                        if (SimInfoSecondActivity.IS_DOWN) {
                            SimInfoSecondActivity.this.appbarlay_tool.startAnimation(SimInfoSecondActivity.this.down_anim_toolbar);
                            SimInfoSecondActivity.IS_DOWN = false;
                            SimInfoSecondActivity.IS_UP = true;
                        }
                    }
                    if (i2 == 0) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to TOP SCROLL");
                    }
                    if (i2 == nestedScrollView2.getMeasuredHeight() - nestedScrollView2.getChildAt(0).getMeasuredHeight()) {
                        Log.i("NETED_SCROLL_VIEW", "Reach to BOTTOM SCROLL");
                    }
                }
            });
        }
        Bundle extras = getIntent().getExtras();
        final String string = extras.getString("HOW_TO_RECHARGE");
        final String string2 = extras.getString("MAIN_BALANCE_ENQUIRY");
        final String string3 = extras.getString("MESSAGE_BALANCE_ENQUIRY");
        final String string4 = extras.getString("NET_BALANCE_ENQUIRY");
        final String string5 = extras.getString("HOW_TO_KNOW_YOUR_NUMBER");
        final String string6 = extras.getString("CUSTOMER_CARE_NUMBER");
        this.tv_how_to_recharge.setText(string);
        this.tv_main_balance_enquiry.setText(string2);
        this.tv_message_balance_enquiry.setText(string3);
        this.tv_net_balance_enquiry.setText(string4);
        this.tv_how_to_know_you_number.setText(string5);
        this.tv_customer_care_number.setText(string6);
        this.iv_how_to_recharge.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.SimInfo.SimInfoSecondActivity.9
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                SimInfoSecondActivity.this.startActivity(new Intent("android.intent.action.DIAL", Uri.parse("tel:" + string)));
            }
        });
        this.iv_main_balance_enquiry.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.SimInfo.SimInfoSecondActivity.10
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                SimInfoSecondActivity.this.startActivity(new Intent("android.intent.action.DIAL", Uri.parse("tel:" + string2)));
            }
        });
        this.iv_message_balance_enquiry.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.SimInfo.SimInfoSecondActivity.11
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                SimInfoSecondActivity.this.startActivity(new Intent("android.intent.action.DIAL", Uri.parse("tel:" + string3)));
            }
        });
        this.iv_net_balance_enquiry.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.SimInfo.SimInfoSecondActivity.12
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                SimInfoSecondActivity.this.startActivity(new Intent("android.intent.action.DIAL", Uri.parse("tel:" + string4)));
            }
        });
        this.iv_how_to_know_you_number.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.SimInfo.SimInfoSecondActivity.13
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                SimInfoSecondActivity.this.startActivity(new Intent("android.intent.action.DIAL", Uri.parse("tel:" + string5)));
            }
        });
        this.iv_customer_care_number.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.SimInfo.SimInfoSecondActivity.14
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                SimInfoSecondActivity.this.startActivity(new Intent("android.intent.action.DIAL", Uri.parse("tel:" + string6)));
            }
        });
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (this.mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            this.mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            AllAdsKeyPlace.CloseActivityWithAds(this, "true");
        }
    }
}
