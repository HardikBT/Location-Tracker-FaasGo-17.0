package calldial.be.loctracker.Compass.app.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.util.TypedValue;

import calldial.be.loctracker.Compass.util.AndroidUtilsCompass;
import calldial.be.loctracker.R;

/* loaded from: classes.dex */
public class AccuracyDrawerSimpleCompass implements ViewDrawerCompass<Integer> {
    private Point CENTER;
    private float HEIGHT;
    private String accHigh;
    private String accLow;
    private String accMedium;
    private String accName;
    private String accUnreliable;
    private String accValue;
    private Paint accuracyBackgroundPaint;
    private Paint accuracyFieldPaint;
    private Path accuracyPath;
    private Paint accuracyTextPaint;
    private static final float THICKNESS = AndroidUtilsCompass.dpToPx(4);
    private static final float PADDING = AndroidUtilsCompass.dpToPx(18);
    private static final float TEXT_PADDING = AndroidUtilsCompass.dpToPx(8);
    private static final float INDICATOR_WIDTH = AndroidUtilsCompass.dpToPx(90);
    private static final float TEXT_HEIGHT = AndroidUtilsCompass.dpToPx(12);
    private Path accuracyBackgroundPath = null;
    private int accuracy = 0;

    public AccuracyDrawerSimpleCompass(Context context) {
        int i;
        int i2;
        int i3;
        Typeface create = Typeface.create("sans-serif-light", 0);
        Resources resources = context.getResources();
        this.accName = resources.getString(R.string.accuracy);
        this.accValue = resources.getString(R.string.accuracy_unreliable);
        this.accLow = context.getResources().getString(R.string.accuracy_low);
        this.accMedium = context.getResources().getString(R.string.accuracy_medium);
        this.accHigh = context.getResources().getString(R.string.accuracy_high);
        this.accUnreliable = context.getResources().getString(R.string.accuracy_unreliable);
        TypedValue typedValue = new TypedValue();
        Resources.Theme theme = context.getTheme();
        if (theme.resolveAttribute(R.attr.indicatorBackgroundColor, typedValue, true)) {
            i = typedValue.data;
        } else {
            i = resources.getColor(R.color.md_indigo_800x);
        }
        if (theme.resolveAttribute(R.attr.indicatorTextColor, typedValue, true)) {
            i2 = typedValue.data;
        } else {
            i2 = resources.getColor(R.color.md_indigo_100);
        }
        if (theme.resolveAttribute(R.attr.indicatorFieldColor, typedValue, true)) {
            i3 = typedValue.data;
        } else {
            i3 = resources.getColor(R.color.md_green_400);
        }
        this.accuracyPath = new Path();
        this.CENTER = new Point(0, 0);
        Paint paint = new Paint(1);
        this.accuracyBackgroundPaint = paint;
        paint.setStyle(Paint.Style.STROKE);
        this.accuracyBackgroundPaint.setStrokeCap(Paint.Cap.ROUND);
        Paint paint2 = this.accuracyBackgroundPaint;
        float f = THICKNESS;
        paint2.setStrokeWidth(f);
        this.accuracyBackgroundPaint.setColor(i);
        Paint paint3 = new Paint(1);
        this.accuracyTextPaint = paint3;
        paint3.setColor(i2);
        this.accuracyTextPaint.setTextSize(TEXT_HEIGHT);
        this.accuracyTextPaint.setTypeface(create);
        this.accuracyTextPaint.setTextAlign(Paint.Align.CENTER);
        Paint paint4 = new Paint(1);
        this.accuracyFieldPaint = paint4;
        paint4.setColor(i3);
        this.accuracyFieldPaint.setStrokeWidth(f);
        this.accuracyFieldPaint.setStyle(Paint.Style.STROKE);
        this.accuracyFieldPaint.setStrokeCap(Paint.Cap.ROUND);
    }

    @Override // calldial.be.loctracker.Compass.app.widget.ViewDrawerCompass
    public void layout(int i, int i2) {
        initConstants(i, i2);
        layoutAccuracy();
    }

    @Override // calldial.be.loctracker.Compass.app.widget.ViewDrawerCompass
    public void draw(Canvas canvas) {
        drawAccuracy(canvas);
    }

    public void update(Integer num) {
        if (this.accuracy != num.intValue()) {
            int intValue = num.intValue();
            this.accuracy = intValue;
            if (intValue == 1) {
                this.accValue = this.accLow;
            } else if (intValue == 2) {
                this.accValue = this.accMedium;
            } else if (intValue != 3) {
                this.accValue = this.accUnreliable;
            } else {
                this.accValue = this.accHigh;
            }
        }
    }

    private void initConstants(int i, int i2) {
        this.HEIGHT = i2;
        this.CENTER.set(i / 2, i2 / 2);
    }

    private void layoutAccuracy() {
        if (this.accuracyBackgroundPath == null) {
            Path path = new Path();
            this.accuracyBackgroundPath = path;
            float f = INDICATOR_WIDTH;
            float f2 = this.CENTER.x + (f / 2.0f);
            float f3 = this.HEIGHT;
            float f4 = PADDING;
            path.moveTo(f2, f3 - f4);
            this.accuracyBackgroundPath.lineTo(this.CENTER.x - (f / 2.0f), this.HEIGHT - f4);
        }
    }

    private void drawAccuracy(Canvas canvas) {
        canvas.drawPath(this.accuracyBackgroundPath, this.accuracyBackgroundPaint);
        float min = Math.min(1.0f, (this.accuracy * 20) / 60);
        float f = INDICATOR_WIDTH;
        this.accuracyPath.reset();
        Path path = new Path();
        this.accuracyPath = path;
        float f2 = this.CENTER.x + (f / 2.0f);
        float f3 = this.HEIGHT;
        float f4 = PADDING;
        path.moveTo(f2, f3 - f4);
        this.accuracyPath.lineTo((this.CENTER.x + (f / 2.0f)) - (min * f), this.HEIGHT - f4);
        canvas.drawPath(this.accuracyPath, this.accuracyFieldPaint);
        Rect rect = new Rect();
        Paint paint = this.accuracyTextPaint;
        String str = this.accValue;
        paint.getTextBounds(str, 0, str.length(), rect);
        String str2 = this.accValue;
        float width = (this.CENTER.x - (f / 2.0f)) - (rect.width() / 2.0f);
        float f5 = TEXT_PADDING;
        canvas.drawText(str2, width - f5, this.HEIGHT - f4, this.accuracyTextPaint);
        Paint paint2 = this.accuracyTextPaint;
        String str3 = this.accName;
        paint2.getTextBounds(str3, 0, str3.length(), rect);
        canvas.drawText(this.accName, this.CENTER.x + (f / 2.0f) + (rect.width() / 2.0f) + f5, this.HEIGHT - f4, this.accuracyTextPaint);
    }
}
