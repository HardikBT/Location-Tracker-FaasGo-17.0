package calldial.be.loctracker.Compass.app.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;

/* loaded from: classes.dex */
public class MagneticFieldViewCompass extends View {
    private ViewDrawerCompass<Float> drawer;
    private float magneticField;

    public MagneticFieldViewCompass(Context context) {
        super(context);
        init(context);
    }

    public MagneticFieldViewCompass(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(context);
    }

    public MagneticFieldViewCompass(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init(context);
    }

    private void init(Context context) {
        this.drawer = new MagneticFieldDrawerCompass(context);
    }

    @Override // android.view.View
    protected void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        int size = MeasureSpec.getSize(i);
        int size2 = MeasureSpec.getSize(i2);
        if (size > size2) {
            size = size2;
        }
        setMeasuredDimension(resolveSize(size, i), resolveSize(size, i2));
    }

    @Override // android.view.View
    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        this.drawer.layout(getWidth(), getHeight());
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.drawer.draw(canvas);
    }

    public void updateMagneticField(float f) {
        if (((int) this.magneticField) != ((int) f)) {
            this.magneticField = f;
            this.drawer.update(Float.valueOf(f));
            invalidate();
        }
    }
}
