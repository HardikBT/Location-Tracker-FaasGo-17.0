package calldial.be.loctracker.Weather.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/* loaded from: classes.dex */
public class RainWeather {
    @SerializedName("3h")
    @Expose
    private float _3h;

    public float get3h() {
        return this._3h;
    }

    public void set3h(float f) {
        this._3h = f;
    }
}
