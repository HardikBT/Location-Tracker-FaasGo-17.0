package calldial.be.loctracker.Weather.activities;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.facebook.internal.ServerProtocol;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import calldial.be.loctracker.Common;
import calldial.be.loctracker.MagicBold.AllAdsKeyPlace;
import calldial.be.loctracker.R;
import calldial.be.loctracker.Weather.adapters.CardAdapterWeather;
import calldial.be.loctracker.Weather.models.DataObjectWeather;
import calldial.be.loctracker.Weather.models.ForecastWeather;
import calldial.be.loctracker.Weather.utilities.ConstantsWeather;
import calldial.be.loctracker.Weather.utilities.UtilityWeather;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/* loaded from: classes.dex */
public class ForecastActivityWeather extends AppCompatActivity {
    private static final String TAG = "ForecastActivityWeather";
    private static long back_pressed;
    StringBuilder addressStringBuilder;
    CardAdapterWeather cardAdapter;
    CardAdapterWeather cardAdapter2;
    CardAdapterWeather cardAdapter3;
    List<String> days;
    List<List<DataObjectWeather>> daysList;
    Set<String> distinctDays;
    Geocoder geocoder;
    TabHost host;
    ImageView imageViewWeatherIcon;
    double latitute;
    ConstraintLayout layout;
    Location location;
    LocationManager locationManager;
    double longitude;
    ProgressBar progressBar;
    ProgressDialog progressDialog;
    RecyclerView recyclerViewLater;
    RecyclerView recyclerViewToday;
    RecyclerView recyclerViewTomorrow;
    Toolbar toolbar;
    TextView tvTodayDescription;
    TextView tvTodayHumidity;
    TextView tvTodayPressure;
    TextView tvTodayTemperature;
    TextView tvTodayWind;
    List<DataObjectWeather> weatherList;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_forecast_weather);
        AllAdsKeyPlace.ShowInterstitialAdsOnCreate(this);
        AllAdsKeyPlace.ShowNativeBannerAd(this, (ViewGroup) findViewById(R.id.nativeContainer1));
        ConstantsWeather.TEMP_UNIT = " " + getResources().getString(R.string.temp_unit_weather);
        initMember();
        initUi();
        detectLocation();
        TabHost tabHost = (TabHost) findViewById(R.id.tabHostT);
        this.host = tabHost;
        tabHost.setup();
        new Date().getDay();
        TabHost.TabSpec newTabSpec = this.host.newTabSpec("Today");
        newTabSpec.setContent(R.id.tab1);
        newTabSpec.setIndicator("Today");
        this.host.addTab(newTabSpec);
        TabHost.TabSpec newTabSpec2 = this.host.newTabSpec("Tomorrow");
        newTabSpec2.setContent(R.id.tab2);
        newTabSpec2.setIndicator("Tomorrow");
        this.host.addTab(newTabSpec2);
        TabHost.TabSpec newTabSpec3 = this.host.newTabSpec("Later");
        newTabSpec3.setContent(R.id.tab3);
        newTabSpec3.setIndicator("Later");
        this.host.addTab(newTabSpec3);
        this.recyclerViewToday = (RecyclerView) findViewById(R.id.my_recycler_view);
        this.recyclerViewTomorrow = (RecyclerView) findViewById(R.id.my_recycler_view2);
        this.recyclerViewLater = (RecyclerView) findViewById(R.id.my_recycler_view3);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        LinearLayoutManager linearLayoutManager2 = new LinearLayoutManager(this);
        LinearLayoutManager linearLayoutManager3 = new LinearLayoutManager(this);
        this.recyclerViewToday.setLayoutManager(linearLayoutManager);
        this.recyclerViewToday.setItemAnimator(new DefaultItemAnimator());
        this.recyclerViewTomorrow.setLayoutManager(linearLayoutManager2);
        this.recyclerViewTomorrow.setItemAnimator(new DefaultItemAnimator());
        this.recyclerViewLater.setLayoutManager(linearLayoutManager3);
        this.recyclerViewLater.setItemAnimator(new DefaultItemAnimator());
        getWeather(this.addressStringBuilder);
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        AllAdsKeyPlace.CloseActivityWithAds(this, "true");
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onStart() {
        super.onStart();
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onPause() {
        super.onPause();
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onResume() {
        super.onResume();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onDestroy() {
        super.onDestroy();
    }

    private void detectLocation() {
        LocationListener locationListener = new LocationListener() { // from class: calldial.be.loctracker.Weather.activities.ForecastActivityWeather.1
            @Override // android.location.LocationListener
            public void onProviderEnabled(String str) {
            }

            @Override // android.location.LocationListener
            public void onStatusChanged(String str, int i, Bundle bundle) {
            }

            @Override // android.location.LocationListener
            public void onLocationChanged(Location location) {
                ForecastActivityWeather.this.latitute = location.getLatitude();
                ForecastActivityWeather.this.longitude = location.getLongitude();
            }

            @Override // android.location.LocationListener
            public void onProviderDisabled(String str) {
                Toast.makeText(ForecastActivityWeather.this, "Connect to network", 0).show();
            }
        };
        if (ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0) {
            this.location = this.locationManager.getLastKnownLocation("network");
            this.locationManager.requestLocationUpdates("network", 0L, 0.0f, locationListener);
        }
        Location location = this.location;
        if (location != null) {
            this.latitute = location.getLatitude();
            this.longitude = this.location.getLongitude();
        }
        try {
            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
            this.geocoder = geocoder;
            List<Address> fromLocation = geocoder.getFromLocation(this.latitute, this.longitude, 1);
            this.addressStringBuilder = new StringBuilder();
            if (fromLocation.size() > 0) {
                Address address = fromLocation.get(0);
                for (int i = 0; i <= address.getMaxAddressLineIndex(); i++) {
                    address.getAddressLine(i);
                    this.addressStringBuilder.append(address.getLocality());
                }
            }
        } catch (Exception e) {
            String str = TAG;
            Log.e(str, "Exception: " + e.getMessage());
        }
    }

    @Override // android.app.Activity
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar_menus, menu);
        return true;
    }

    @Override // android.app.Activity
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.action_rate_us /* 2131361871 */:
                showRateUsDialog();
                return true;
            case R.id.action_search /* 2131361872 */:
                searchByCityName();
                return true;
            default:
                return super.onOptionsItemSelected(menuItem);
        }
    }

    private void searchByCityName() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.search_title_weather));
        final EditText editText = new EditText(this);
        editText.setInputType(1);
        editText.setMaxLines(1);
        editText.setSingleLine(true);
        builder.setView(editText);
        builder.setPositiveButton(R.string.ok_weather, new DialogInterface.OnClickListener() { // from class: calldial.be.loctracker.Weather.activities.ForecastActivityWeather.2
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
                String obj = editText.getText().toString();
                if (!obj.isEmpty()) {
                    ForecastActivityWeather.this.fetchUpdateOnSearched(obj);
                }
            }
        });
        builder.setNegativeButton(R.string.cancel_weather, new DialogInterface.OnClickListener() { // from class: calldial.be.loctracker.Weather.activities.ForecastActivityWeather.3
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        builder.show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void fetchUpdateOnSearched(String str) {
        StringBuilder sb = new StringBuilder();
        sb.append(str);
        getWeather(sb);
    }

    private void showRateUsDialog() {
        Common.showRateDialog(this);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String getDate(Long l) {
        return new SimpleDateFormat("dd").format(new Date(l.longValue()));
    }

    private void getWeather(StringBuilder sb) {
        this.progressDialog.show();
        UtilityWeather.getApis().getWeatherForecastData(sb, ConstantsWeather.API_KEY, ConstantsWeather.UNITS).enqueue(new Callback<ForecastWeather>() { // from class: calldial.be.loctracker.Weather.activities.ForecastActivityWeather.4
            /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
            /* JADX WARN: Code restructure failed: missing block: B:70:0x02d6, code lost:
                if (r1.equals("01n") == false) goto L_0x0203;
             */
            @Override // retrofit2.Callback
            /*
                Code decompiled incorrectly, please refer to instructions dump.
            */
            public void onResponse(Call<ForecastWeather> call, Response<ForecastWeather> response) {
                ForecastActivityWeather.this.progressDialog.dismiss();
                if (response.isSuccessful()) {
                    String str = ForecastActivityWeather.TAG;
                    Log.i(str, "onResponse: " + response.isSuccessful());
                    ForecastActivityWeather.this.weatherList = response.body().getDataObjectList();
                    ForecastActivityWeather.this.distinctDays = new LinkedHashSet();
                    for (DataObjectWeather dataObjectWeather : ForecastActivityWeather.this.weatherList) {
                        ForecastActivityWeather.this.distinctDays.add(ForecastActivityWeather.this.getDate(Long.valueOf(dataObjectWeather.getDt() * 1000)));
                    }
                    Log.i("DISTINCTSIZE", ForecastActivityWeather.this.distinctDays.size() + "");
                    ForecastActivityWeather.this.days = new ArrayList();
                    ForecastActivityWeather.this.days.addAll(ForecastActivityWeather.this.distinctDays);
                    for (String str2 : ForecastActivityWeather.this.days) {
                        ArrayList arrayList = new ArrayList();
                        Log.i("DAY", str2);
                        for (DataObjectWeather dataObjectWeather2 : ForecastActivityWeather.this.weatherList) {
                            Log.i("ELEMENT", ForecastActivityWeather.this.getDate(Long.valueOf(dataObjectWeather2.getDt() * 1000)));
                            if (ForecastActivityWeather.this.getDate(Long.valueOf(dataObjectWeather2.getDt() * 1000)).equals(str2)) {
                                Log.i("ADDEDDD", ForecastActivityWeather.this.getDate(Long.valueOf(dataObjectWeather2.getDt() * 1000)));
                                arrayList.add(dataObjectWeather2);
                            }
                        }
                        ForecastActivityWeather.this.daysList.add(arrayList);
                    }
                    ForecastActivityWeather.this.daysList.get(0).remove(0);
                    Log.i("DAYSLISTSIZE", ForecastActivityWeather.this.daysList.size() + "");
                    ForecastActivityWeather forecastActivityWeather = ForecastActivityWeather.this;
                    forecastActivityWeather.cardAdapter = new CardAdapterWeather(forecastActivityWeather.daysList.get(0));
                    ForecastActivityWeather.this.recyclerViewToday.setAdapter(ForecastActivityWeather.this.cardAdapter);
                    ForecastActivityWeather forecastActivityWeather2 = ForecastActivityWeather.this;
                    char c = 1;
                    forecastActivityWeather2.cardAdapter2 = new CardAdapterWeather(forecastActivityWeather2.daysList.get(1));
                    ForecastActivityWeather.this.recyclerViewTomorrow.setAdapter(ForecastActivityWeather.this.cardAdapter2);
                    ForecastActivityWeather forecastActivityWeather3 = ForecastActivityWeather.this;
                    forecastActivityWeather3.cardAdapter3 = new CardAdapterWeather(forecastActivityWeather3.daysList.get(ForecastActivityWeather.this.daysList.size() - 1));
                    ForecastActivityWeather.this.recyclerViewLater.setAdapter(ForecastActivityWeather.this.cardAdapter3);
                    Toolbar toolbar = ForecastActivityWeather.this.toolbar;
                    toolbar.setTitle(response.body().getCity().getName() + ", " + response.body().getCity().getCountry());
                    String icon = ForecastActivityWeather.this.weatherList.get(0).getWeather().get(0).getIcon();
                    icon.hashCode();
                    switch (icon.hashCode()) {
                        case 47747:
                            if (icon.equals("01d")) {
                                c = 0;
                                break;
                            }
                            c = 65535;
                            break;
                        case 47757:
                            break;
                        case 47778:
                            if (icon.equals("02d")) {
                                c = 2;
                                break;
                            }
                            c = 65535;
                            break;
                        case 47788:
                            if (icon.equals("02n")) {
                                c = 3;
                                break;
                            }
                            c = 65535;
                            break;
                        case 47809:
                            if (icon.equals("03d")) {
                                c = 4;
                                break;
                            }
                            c = 65535;
                            break;
                        case 47819:
                            if (icon.equals("03n")) {
                                c = 5;
                                break;
                            }
                            c = 65535;
                            break;
                        case 47840:
                            if (icon.equals("04d")) {
                                c = 6;
                                break;
                            }
                            c = 65535;
                            break;
                        case 47850:
                            if (icon.equals("04n")) {
                                c = 7;
                                break;
                            }
                            c = 65535;
                            break;
                        case 47995:
                            if (icon.equals("09d")) {
                                c = '\b';
                                break;
                            }
                            c = 65535;
                            break;
                        case 48005:
                            if (icon.equals("09n")) {
                                c = '\t';
                                break;
                            }
                            c = 65535;
                            break;
                        case 48677:
                            if (icon.equals("10d")) {
                                c = '\n';
                                break;
                            }
                            c = 65535;
                            break;
                        case 48687:
                            if (icon.equals("10n")) {
                                c = 11;
                                break;
                            }
                            c = 65535;
                            break;
                        case 48708:
                            if (icon.equals("11d")) {
                                c = '\f';
                                break;
                            }
                            c = 65535;
                            break;
                        case 48718:
                            if (icon.equals("11n")) {
                                c = '\r';
                                break;
                            }
                            c = 65535;
                            break;
                        case 48770:
                            if (icon.equals("13d")) {
                                c = 14;
                                break;
                            }
                            c = 65535;
                            break;
                        case 48780:
                            if (icon.equals("13n")) {
                                c = 15;
                                break;
                            }
                            c = 65535;
                            break;
                        case 48832:
                            if (icon.equals("15d")) {
                                c = 16;
                                break;
                            }
                            c = 65535;
                            break;
                        case 48842:
                            if (icon.equals("15n")) {
                                c = 17;
                                break;
                            }
                            c = 65535;
                            break;
                        default:
                            c = 65535;
                            break;
                    }
                    switch (c) {
                        case 0:
                            ForecastActivityWeather.this.imageViewWeatherIcon.setImageResource(R.drawable.ic_weather_clear_sky);
                            ForecastActivityWeather.this.toolbar.setBackgroundResource(R.color.color_clear_and_sunny);
                            ForecastActivityWeather.this.layout.setBackgroundColor(ForecastActivityWeather.this.getResources().getColor(R.color.color_clear_and_sunny));
                            break;
                        case 1:
                            ForecastActivityWeather.this.imageViewWeatherIcon.setImageResource(R.drawable.ic_weather_clear_sky);
                            ForecastActivityWeather.this.toolbar.setBackgroundResource(R.color.color_clear_and_sunny);
                            ForecastActivityWeather.this.layout.setBackgroundColor(ForecastActivityWeather.this.getResources().getColor(R.color.color_clear_and_sunny));
                            break;
                        case 2:
                            ForecastActivityWeather.this.imageViewWeatherIcon.setImageResource(R.drawable.ic_weather_few_cloud);
                            ForecastActivityWeather.this.toolbar.setBackgroundResource(R.color.color_partly_cloudy);
                            ForecastActivityWeather.this.layout.setBackgroundColor(ForecastActivityWeather.this.getResources().getColor(R.color.color_partly_cloudy));
                            break;
                        case 3:
                            ForecastActivityWeather.this.imageViewWeatherIcon.setImageResource(R.drawable.ic_weather_few_cloud);
                            ForecastActivityWeather.this.toolbar.setBackgroundResource(R.color.color_partly_cloudy);
                            ForecastActivityWeather.this.layout.setBackgroundColor(ForecastActivityWeather.this.getResources().getColor(R.color.color_partly_cloudy));
                            break;
                        case 4:
                            ForecastActivityWeather.this.imageViewWeatherIcon.setImageResource(R.drawable.ic_weather_scattered_clouds);
                            ForecastActivityWeather.this.toolbar.setBackgroundResource(R.color.color_gusty_winds);
                            ForecastActivityWeather.this.layout.setBackgroundColor(ForecastActivityWeather.this.getResources().getColor(R.color.color_gusty_winds));
                            break;
                        case 5:
                            ForecastActivityWeather.this.imageViewWeatherIcon.setImageResource(R.drawable.ic_weather_scattered_clouds);
                            ForecastActivityWeather.this.toolbar.setBackgroundResource(R.color.color_gusty_winds);
                            ForecastActivityWeather.this.layout.setBackgroundColor(ForecastActivityWeather.this.getResources().getColor(R.color.color_gusty_winds));
                            break;
                        case 6:
                            ForecastActivityWeather.this.imageViewWeatherIcon.setImageResource(R.drawable.ic_weather_broken_clouds);
                            ForecastActivityWeather.this.toolbar.setBackgroundResource(R.color.color_cloudy_overnight);
                            ForecastActivityWeather.this.layout.setBackgroundColor(ForecastActivityWeather.this.getResources().getColor(R.color.color_cloudy_overnight));
                            break;
                        case 7:
                            ForecastActivityWeather.this.imageViewWeatherIcon.setImageResource(R.drawable.ic_weather_broken_clouds);
                            ForecastActivityWeather.this.toolbar.setBackgroundResource(R.color.color_cloudy_overnight);
                            ForecastActivityWeather.this.layout.setBackgroundColor(ForecastActivityWeather.this.getResources().getColor(R.color.color_cloudy_overnight));
                            break;
                        case '\b':
                            ForecastActivityWeather.this.imageViewWeatherIcon.setImageResource(R.drawable.ic_weather_shower_rain);
                            ForecastActivityWeather.this.toolbar.setBackgroundResource(R.color.color_hail_stroms);
                            ForecastActivityWeather.this.layout.setBackgroundColor(ForecastActivityWeather.this.getResources().getColor(R.color.color_hail_stroms));
                            break;
                        case '\t':
                            ForecastActivityWeather.this.imageViewWeatherIcon.setImageResource(R.drawable.ic_weather_shower_rain);
                            ForecastActivityWeather.this.toolbar.setBackgroundResource(R.color.color_hail_stroms);
                            ForecastActivityWeather.this.layout.setBackgroundColor(ForecastActivityWeather.this.getResources().getColor(R.color.color_hail_stroms));
                            break;
                        case '\n':
                            ForecastActivityWeather.this.imageViewWeatherIcon.setImageResource(R.drawable.ic_weather_rain);
                            ForecastActivityWeather.this.toolbar.setBackgroundResource(R.color.color_heavy_rain);
                            ForecastActivityWeather.this.layout.setBackgroundColor(ForecastActivityWeather.this.getResources().getColor(R.color.color_heavy_rain));
                            break;
                        case 11:
                            ForecastActivityWeather.this.imageViewWeatherIcon.setImageResource(R.drawable.ic_weather_rain);
                            ForecastActivityWeather.this.toolbar.setBackgroundResource(R.color.color_heavy_rain);
                            ForecastActivityWeather.this.layout.setBackgroundColor(ForecastActivityWeather.this.getResources().getColor(R.color.color_heavy_rain));
                            break;
                        case '\f':
                            ForecastActivityWeather.this.imageViewWeatherIcon.setImageResource(R.drawable.ic_weather_thunderstorm);
                            ForecastActivityWeather.this.toolbar.setBackgroundResource(R.color.color_thunderstroms);
                            ForecastActivityWeather.this.layout.setBackgroundColor(ForecastActivityWeather.this.getResources().getColor(R.color.color_thunderstroms));
                            break;
                        case '\r':
                            ForecastActivityWeather.this.imageViewWeatherIcon.setImageResource(R.drawable.ic_weather_thunderstorm);
                            ForecastActivityWeather.this.toolbar.setBackgroundResource(R.color.color_thunderstroms);
                            ForecastActivityWeather.this.layout.setBackgroundColor(ForecastActivityWeather.this.getResources().getColor(R.color.color_thunderstroms));
                            break;
                        case 14:
                            ForecastActivityWeather.this.imageViewWeatherIcon.setImageResource(R.drawable.ic_weather_snow);
                            ForecastActivityWeather.this.toolbar.setBackgroundResource(R.color.color_snow);
                            ForecastActivityWeather.this.layout.setBackgroundColor(ForecastActivityWeather.this.getResources().getColor(R.color.color_snow));
                            break;
                        case 15:
                            ForecastActivityWeather.this.imageViewWeatherIcon.setImageResource(R.drawable.ic_weather_snow);
                            ForecastActivityWeather.this.toolbar.setBackgroundResource(R.color.color_snow);
                            ForecastActivityWeather.this.layout.setBackgroundColor(ForecastActivityWeather.this.getResources().getColor(R.color.color_snow));
                            break;
                        case 16:
                            ForecastActivityWeather.this.imageViewWeatherIcon.setImageResource(R.drawable.ic_weather_mist);
                            ForecastActivityWeather.this.toolbar.setBackgroundResource(R.color.color_mix_snow_and_rain);
                            ForecastActivityWeather.this.layout.setBackgroundColor(ForecastActivityWeather.this.getResources().getColor(R.color.color_mix_snow_and_rain));
                            break;
                        case 17:
                            ForecastActivityWeather.this.imageViewWeatherIcon.setImageResource(R.drawable.ic_weather_mist);
                            ForecastActivityWeather.this.toolbar.setBackgroundResource(R.color.color_mix_snow_and_rain);
                            ForecastActivityWeather.this.layout.setBackgroundColor(ForecastActivityWeather.this.getResources().getColor(R.color.color_mix_snow_and_rain));
                            break;
                    }
                    TextView textView = ForecastActivityWeather.this.tvTodayTemperature;
                    textView.setText(ForecastActivityWeather.this.weatherList.get(0).getMain().getTemp() + " " + ForecastActivityWeather.this.getString(R.string.temp_unit_weather));
                    ForecastActivityWeather.this.tvTodayDescription.setText(ForecastActivityWeather.this.weatherList.get(0).getWeather().get(0).getDescription());
                    TextView textView2 = ForecastActivityWeather.this.tvTodayWind;
                    textView2.setText(ForecastActivityWeather.this.getString(R.string.wind_lable) + " " + ForecastActivityWeather.this.weatherList.get(0).getWind().getSpeed() + " " + ForecastActivityWeather.this.getString(R.string.wind_unit));
                    TextView textView3 = ForecastActivityWeather.this.tvTodayPressure;
                    textView3.setText(ForecastActivityWeather.this.getString(R.string.pressure_lable) + " " + ForecastActivityWeather.this.weatherList.get(0).getMain().getPressure() + " " + ForecastActivityWeather.this.getString(R.string.pressure_unit));
                    TextView textView4 = ForecastActivityWeather.this.tvTodayHumidity;
                    textView4.setText(ForecastActivityWeather.this.getString(R.string.humidity_lable) + " " + ForecastActivityWeather.this.weatherList.get(0).getMain().getHumidity() + " " + ForecastActivityWeather.this.getString(R.string.humidity_unit));
                }
            }

            @Override // retrofit2.Callback
            public void onFailure(Call<ForecastWeather> call, Throwable th) {
                ForecastActivityWeather.this.progressDialog.dismiss();
                String str = ForecastActivityWeather.TAG;
                Log.e(str, "onFailure: " + th.getMessage());
                ForecastActivityWeather forecastActivityWeather = ForecastActivityWeather.this;
                Toast.makeText(forecastActivityWeather, "" + th.getMessage().toString(), 0).show();
            }
        });
    }

    private void initUi() {
        ProgressDialog progressDialog = new ProgressDialog(this);
        this.progressDialog = progressDialog;
        progressDialog.setMessage(getString(R.string.progress));
        Toolbar toolbar = (Toolbar) findViewById(R.id.app_toolbar);
        this.toolbar = toolbar;
        setSupportActionBar(toolbar);
        this.imageViewWeatherIcon = (ImageView) findViewById(R.id.imageViewWeather);
        this.tvTodayTemperature = (TextView) findViewById(R.id.todayTemperature);
        this.tvTodayDescription = (TextView) findViewById(R.id.todayDescription);
        this.tvTodayWind = (TextView) findViewById(R.id.todayWind);
        this.tvTodayPressure = (TextView) findViewById(R.id.todayPressure);
        this.tvTodayHumidity = (TextView) findViewById(R.id.todayHumidity);
        this.layout = (ConstraintLayout) findViewById(R.id.layoutWeather);
    }

    private void initMember() {
        this.locationManager = (LocationManager) getSystemService("location");
        this.weatherList = new ArrayList();
        this.daysList = new ArrayList();
    }
}
