package calldial.be.loctracker.Weather.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/* loaded from: classes.dex */
public class SysWeather {
    @SerializedName("pod")
    @Expose
    private String pod;

    public String getPod() {
        return this.pod;
    }

    public void setPod(String str) {
        this.pod = str;
    }
}
