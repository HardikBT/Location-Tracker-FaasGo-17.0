package calldial.be.loctracker.Compass;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import calldial.be.loctracker.Compass.data.PrefsCompass;
import calldial.be.loctracker.R;

/* loaded from: classes.dex */
public class ColorMapCompass {
    private static ColorMapCompass singleton;
    private int appThemeResource = 0;
    private List<OnThemeColorChangeListener> onThemeColorChangeListeners = new ArrayList();
    private PrefsCompass prefs;
    private int selected;

    /* loaded from: classes.dex */
    public interface OnThemeColorChangeListener {
        void onThemeColorChange(int i);
    }

    public static ColorMapCompass getInstance(PrefsCompass prefsCompass) {
        if (singleton == null) {
            singleton = new ColorMapCompass(prefsCompass);
        }
        return singleton;
    }

    private ColorMapCompass(PrefsCompass prefsCompass) {
        this.prefs = prefsCompass;
        int themeColor = prefsCompass.getThemeColor();
        this.selected = themeColor;
        init(themeColor);
    }

    private void init(int i) {
        if (i < 0 || i > 9) {
            i = new Random().nextInt(8);
        }
        switch (i) {
            case 0:
                this.appThemeResource = R.style.AppTheme;
                return;
            case 1:
                this.appThemeResource = R.style.AppTheme_Black;
                return;
            case 2:
                this.appThemeResource = R.style.AppTheme_Grey;
                return;
            case 3:
                this.appThemeResource = R.style.AppTheme_Brown;
                return;
            case 4:
                this.appThemeResource = R.style.AppTheme_Green;
                return;
            case 5:
                this.appThemeResource = R.style.AppTheme_Red;
                return;
            case 6:
                this.appThemeResource = R.style.AppTheme_Pink;
                return;
            case 7:
                this.appThemeResource = R.style.AppTheme_Purple;
                return;
            case 8:
                this.appThemeResource = R.style.AppTheme_Blue;
                return;
            default:
                this.appThemeResource = R.style.AppTheme;
                return;
        }
    }

    public void updateColorMap(int i) {
        int i2 = this.selected;
        this.selected = i;
        if (i2 != i) {
            this.prefs.setAppThemeColor(i);
            init(this.selected);
            onThemeColorChange(this.selected);
        }
    }

    public int getSelected() {
        return this.selected;
    }

    public int getAppThemeResource() {
        return this.appThemeResource;
    }

    public int[] getColorResources() {
        return new int[]{R.color.colorPrimaryCompass, R.color.md_black_1000, R.color.md_grey_800x, R.color.md_brown_600, R.color.md_green_600, R.color.md_red_500, R.color.md_pink_500, R.color.md_deep_purple_500, R.color.blue_6};
    }

    public void addOnThemeColorChangeListener(OnThemeColorChangeListener onThemeColorChangeListener) {
        this.onThemeColorChangeListeners.add(onThemeColorChangeListener);
    }

    public void removeOnThemeColorChangeListener(OnThemeColorChangeListener onThemeColorChangeListener) {
        this.onThemeColorChangeListeners.remove(onThemeColorChangeListener);
    }

    public void onThemeColorChange(int i) {
        for (int i2 = 0; i2 < this.onThemeColorChangeListeners.size(); i2++) {
            this.onThemeColorChangeListeners.get(i2).onThemeColorChange(i);
        }
    }
}
