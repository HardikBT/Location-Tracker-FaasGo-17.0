package calldial.be.loctracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import calldial.be.loctracker.MagicBold.AllAdsKeyPlace;
import calldial.be.loctracker.MagicBold.AppPrefrence;

/* loaded from: classes.dex */
public class PrivacyPolicyActivity extends AppCompatActivity {
    Button btn_agree;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_privacy_policy);
        if (getIntent().getBooleanExtra("my_boolean_key", false)) {
            AllAdsKeyPlace.ShowInterstitialAdsOnCreate(this);
        }
        AllAdsKeyPlace.ShowNativeBannerAd(this, (ViewGroup) findViewById(R.id.nativeContainer));
        Button button = (Button) findViewById(R.id.btn_agree);
        this.btn_agree = button;
        Common.Animation(button);
        this.btn_agree.setOnClickListener(new View.OnClickListener() { // from class: calldial.be.loctracker.PrivacyPolicyActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (new AppPrefrence(PrivacyPolicyActivity.this.getApplicationContext()).getQureka_ADS().equalsIgnoreCase("on")) {
                    PrivacyPolicyActivity.this.startActivity(new Intent(PrivacyPolicyActivity.this, DashboardActivity.class).putExtra("my_boolean_key", true));
                    PrivacyPolicyActivity.this.finish();
                    return;
                }
                PrivacyPolicyActivity.this.startActivity(new Intent(PrivacyPolicyActivity.this, FirstActivity.class).putExtra("my_boolean_key", true));
                PrivacyPolicyActivity.this.finish();
            }
        });
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (new AppPrefrence(getApplicationContext()).getQureka_ADS().equalsIgnoreCase("on")) {
            startActivity(new Intent(this, DashboardActivity.class).putExtra("my_boolean_key", false));
            finish();
            return;
        }
        startActivity(new Intent(this, FirstActivity.class).putExtra("my_boolean_key", false));
        finish();
    }
}
